export function winLossClass(value: number | null | undefined): string {
  if (typeof value !== "number" || !Number.isFinite(value) || value === 0) {
    return "win-loss-neutral";
  }
  return value > 0 ? "win-loss-positive" : "win-loss-negative";
}
