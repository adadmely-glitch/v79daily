import { z } from "zod";

export const NOTIFICATION_PAGE_SIZE = 30;
// cacheKey partitions browser query caches; it never selects the server-side recipient.
const cacheKey = z.number().int().positive().optional();
export const notificationCacheSchema = z.object({ cacheKey }).strict().optional();
export const notificationFeedSchema = z.object({ cacheKey, unreadOnly: z.boolean().optional() }).strict().optional();
export const markNotificationsReadSchema = z.object({
  eventKeys: z.array(z.string().max(80).regex(
    /^(?:(?:notice|credit)-[1-9]\d{0,9}|withdrawal-[1-9]\d{0,9}-(?:pending|approved|rejected))$/,
    "Thông báo không hợp lệ. Vui lòng làm mới danh sách.",
  )).min(1).max(NOTIFICATION_PAGE_SIZE),
}).strict();
