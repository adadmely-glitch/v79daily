import { useState, type FormEvent } from "react";
import { LoaderCircle, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { walletInput, type WalletNetwork } from "@shared/wallet";
import PayoutIcon from "@/components/PayoutIcon";
import "@/styles/wallet.css";

export default function UsdtWalletInfo() {
  const utils = trpc.useUtils();
  const wallets = trpc.agent.walletAccounts.useQuery(undefined, { refetchOnWindowFocus: false });
  const [network, setNetwork] = useState<WalletNetwork>("TRC20");
  const [address, setAddress] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const addWallet = trpc.agent.addWalletAccount.useMutation({
    onSuccess: (_result, input) => {
      setAddress("");
      setError("");
      setMessage(`Đã thêm ví USDT (${input.network}) vào hồ sơ của bạn.`);
      // A failed list refresh must not imply that a successful save failed.
      void utils.agent.walletAccounts.invalidate().catch(() => undefined);
    },
    onError: (cause) => setError(cause.message),
  });

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (addWallet.isPending) return;
    setError(""); setMessage("");
    const result = walletInput.safeParse({ network, address });
    if (!result.success) {
      setError(result.error.issues[0]?.message ?? "Kiểm tra lại thông tin ví.");
      return;
    }
    addWallet.mutate(result.data);
  }

  return (
    <section className="usdt-wallet-card" aria-labelledby="usdt-wallet-title">
      <div className="usdt-wallet-heading">
        <PayoutIcon type="usdt" />
        <h2 id="usdt-wallet-title">VÍ ẢO USDT</h2>
      </div>
      <form className="usdt-wallet-form" onSubmit={submit} autoComplete="off">
        <label htmlFor="usdt-wallet-network"><span>Loại ví</span>
          <select id="usdt-wallet-network" value={network} disabled={addWallet.isPending} onChange={(event) => { setNetwork(event.target.value as WalletNetwork); setError(""); setMessage(""); }}>
            <option value="TRC20">USDT (TRC20)</option>
            <option value="ERC20">USDT (ERC20)</option>
          </select>
        </label>
        <label htmlFor="usdt-wallet-address"><span>Địa chỉ ví</span>
          <input id="usdt-wallet-address" required maxLength={64} spellCheck={false} autoCapitalize="none" autoCorrect="off" disabled={addWallet.isPending} value={address} onChange={(event) => { setAddress(event.target.value); setError(""); setMessage(""); }} placeholder="Nhập địa chỉ ví" />
        </label>
        <button className="bank-add-button" type="submit" disabled={addWallet.isPending || !address.trim()}>
          {addWallet.isPending ? <LoaderCircle className="auth-spin" size={16} /> : <Plus size={16} />} {addWallet.isPending ? "Đang thêm…" : "Thêm"}
        </button>
      </form>
      {error && <p className="usdt-wallet-error" role="alert">{error}</p>}
      {message && <p className="usdt-wallet-success" role="status">{message}</p>}
      {wallets.isError && <p className="usdt-wallet-error" role="alert">Không thể tải danh sách ví. <button type="button" onClick={() => void wallets.refetch()}>Tải lại</button></p>}
      <div className="usdt-wallet-table-wrap"><table className="usdt-wallet-table">
        <thead><tr><th>Loại ví</th><th>Địa chỉ ví</th></tr></thead>
        <tbody>
          {wallets.isLoading ? <tr><td colSpan={2} className="usdt-wallet-empty">Đang tải ví…</td></tr>
            : wallets.data?.length ? wallets.data.map((wallet) => <tr key={wallet.id}><td><span className="usdt-wallet-network">{wallet.asset} ({wallet.network})</span></td><td><code>{wallet.address}</code></td></tr>)
            : !wallets.isError ? <tr><td colSpan={2} className="usdt-wallet-empty">Chưa có ví USDT. Chọn loại ví và nhập địa chỉ để thêm.</td></tr> : null}
        </tbody>
      </table></div>
    </section>
  );
}
