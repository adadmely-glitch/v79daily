# Kế hoạch triển khai V79 ĐẠI LÝ

## Thiết kế
- **Design movement:** Bảng điều khiển đối tác kiểu enterprise gọn gàng, lấy cảm hứng từ cổng quản trị web cổ điển nhưng được làm mới bằng khoảng trắng, thẻ bo nhẹ và typography rõ.
- **Core principles:** Dữ liệu đọc nhanh; phân biệt trạng thái rõ; mọi thao tác quản trị có dấu vết; không giả lập thành công cho giao dịch thật.
- **Color philosophy:** Tím điện/hồng san hô giữ nhận diện màn hình đăng nhập; nền trắng/xám sương giúp bảng dữ liệu dễ rà soát; xanh lam/xanh lá dành cho trạng thái đã duyệt, màu hổ phách cho chờ xử lý và đỏ cho từ chối/khóa.
- **Layout paradigm:** Cổng đại lý dùng thanh điều hướng trên và các thẻ tổng quan; admin dùng thanh điều hướng riêng, bộ lọc cạnh tiêu đề và bảng dữ liệu rộng, có chế độ cuộn trên điện thoại.
- **Signature elements:** Dải chéo tím–san hô ở khu đăng nhập; logo V79 ảnh người dùng cung cấp; pill trạng thái và mã thao tác dễ quét.
- **Interaction philosophy:** Hành động tài chính yêu cầu dữ liệu hợp lệ, lý do và phản hồi trạng thái; quyền truy cập được xác thực ở server, không chỉ ẩn nút trên giao diện.
- **Animation:** Chuyển cảnh/hover ngắn, hỗ trợ `prefers-reduced-motion`; không dùng chuyển động làm chậm việc đọc hay phê duyệt.
- **Typography system:** Inter với fallback hệ thống; số dư dùng chữ số tabular; tiêu đề có cấp bậc rõ, nhãn form dễ đọc.
- **Brand essence:** Cổng quản trị đối tác V79, rõ ràng và có kiểm soát; tính cách chính xác, nhanh, đáng tin.
- **Brand voice:** Microcopy ngắn, mô tả kết quả thực; ví dụ “Đang chờ duyệt” và “Đã ghi nhận khoản cộng số dư”.
- **Wordmark & logo:** Dùng ảnh logo V79 do người dùng gửi; header /dashboard bỏ nhãn chữ “ĐẠI LÝ” theo Preview, giữ ảnh/link/aria và nhận diện ở các trang khác. Chu kỳ nằm trên nhãn TÀI KHOẢN ĐẠI LÝ, đếm từng giây tới 00:00 ngày 01/12/2026 giờ Việt Nam; Preview b3 gỡ text nhãn và đặt timer 12px, giữ live dot/aria/tooltip. Chỉ một đồng hồ, không âm hoặc tự chuyển kỳ sau.
- **Signature brand color:** Tím V79 `#6846E8`, dùng làm màu nhấn riêng cho điều hướng và CTA.

## Triển khai và cấu trúc
Dùng starter React 19 + TypeScript + Vite / Express / tRPC / Drizzle hiện có. Người dùng đã xác nhận bật `server: true` và database quản lý; đây là capability bật một chiều. Express phục vụ API và static assets trong container, MySQL quản lý giữ hồ sơ; endpoint sức khỏe `/api/health`. Bản publish dùng hybrid routes: `/api/*` về server trước, các trang còn lại về static SPA.

Mọi số tiền trong giao diện quản trị và đại lý thống nhất bằng **điểm**, tỷ giá **1 điểm = 1,000 VND**. Ô nhập hỗ trợ dấu phẩy phân cách hàng nghìn và tối đa ba chữ số thập phân (0.001 điểm = 1 VND), làm rõ VND quy đổi trước khi lưu/tạo đơn. Helper dùng chung tại `shared/money.ts` chuyển chuỗi điểm sang số nguyên VND bằng phép toán chính xác, từ chối giá trị sai/vượt giới hạn; các API và cột `*Vnd` giữ nguyên đơn vị VND để tương thích client cũ và không thay đổi giá trị dữ liệu hiện có. Báo cáo và số dư chỉ đổi cách hiển thị, không đổi cách tính, scope hay phân quyền. Form Admin theo tháng có Khuyến mãi/Tổng cược/Hoàn trả; Tổng thắng thua là chỉ đọc, tính bằng Rút − Nạp − Khuyến mãi − Hoàn trả và âm hiển thị đỏ; không có ô Cược hợp lệ.

Menu mũi tên tài khoản đại lý giữ họ tên/email/Đăng xuất và thêm Thông báo, Đổi mật khẩu. Thông báo trong ứng dụng lấy tin Admin gửi cùng cập nhật số dư và trạng thái đơn rút của chính đại lý; có trạng thái trống/tải/lỗi, không giả lập thông báo hay tự khẳng định chi trả. Bảng agency_notifications lưu thông báoAdmin với tiêu đề/nội dung/người gửi/thời gian và scope đại lý cụ thể hoặc toàn bộ; Admin có tab gửi/xem lịch sử, gửi toàn bộ phải xác nhận phạm vi. Form đổi mật khẩu ở dialog có focus trap, nhãn rõ, mật khẩu cũ/mới/nhập lại và nút Đổi; mật khẩu mới dài8–128ký tự, phải khớp xác nhận và khác mật khẩu cũ. Server xác định tài khoản từ session, kiểm mật khẩu cũ bằng scrypt, khóa credentials trong transaction, giới hạn8lần sai/15phút, ghi audit không chứa mật khẩu/hash. Admin có nútĐổi mật khẩu riêng cho mỗi đại lý, nhập mới/nhập lại/lý do, không cần biết mật khẩu cũ; chỉ Admin được gọi API, không đổi mật khẩuOAuth và không mở khóa hồ sơ. Đặt lại mật khẩu tăng phiên bản, thu hồi toàn bộ phiên đại lý và reset throttle; Admin không xem lại mật khẩu/hash. Cột password_version bổ sung mặc định0 giữ phiên đại lý cũ tương thích; tự đổi thành công tăng phiên bản và cấp lại cookie cho phiên hiện tại, vô hiệu hóa phiên cũ ở các thiết bị khác. Manus OAuth Admin không đổi qua form này.

Chuông thông báo có badge số chưa đọc và nút mở trực tiếp dialog; menu tài khoản dùng cùng số đếm, focus trả về đúng nút đã mở. Bảng `agency_notification_reads` có receipt duy nhất theo agencyId/eventKey, không sửa/xóa tin gốc. Key tin Admin/cộng số dư theo ID; key đơn rút gồm ID/trạng thái để chờ duyệt đã đọc không làm mất tin duyệt/từ chối mới. Count dùng LEFT JOIN receipt của đúng đại lý và đếm tất cả sự kiện, không bị giới hạn feed 30 mục; API feed giữ dạng mảng/ID cũ, eventKey/readAt/isRead và lọc unreadOnly tùy chọn. Cache key theo user.id chỉ là hint cách ly cache, server luôn xác định agency từ session; dialog remount theo user.id khi đổi tài khoản. API đánh dấu kiểm quyền đối tượng và trạng thái hiện tại, khóa profile/đơn rút đang đọc và upsert idempotent. Danh sách rút gọn chỉ gồm nút tiêu đề có dấu chưa đọc; bấm tiêu đề mở nội dung/ngày giờ/số điểm của đúng mục, bấm lại đóng và chỉ mở một mục mỗi lần. Mở chi tiết mới gửi một eventKey để đánh dấu đọc; không tự đọc cả trang khi tải/Làm mới/lọc. Snapshot danh sách giữ nguyên để đọc, cache recent cập nhật trạng thái và cache unread-only loại riêng mục vừa đọc; cập nhật count sau thành công. Lỗi đọc có phản hồi/thử lại, không báo đã đọc khi lưu thất bại. Nút Xem tin chưa đọc/Làm mới chỉ tải danh sách, không ghi receipt. Refetch count mỗi 30 giây và khi focus, không dùng localStorage hoặc trạng thái chung làm người khác mất thông báo. Thay đổi lần này chỉ ở giao diện, không migration hoặc thay quyền; kiểm thử bằng fixture riêng, không đọc hộ thông báo thật.

Khu admin tách tại `/admin/login` và `/admin`, không có liên kết trong màn hình/menu đại lý; cả route và API đều kiểm role phía server. Manus OAuth **chỉ dùng ở `/admin/login`** và callback chỉ cấp session/đi tới admin cho tài khoản có role `admin`. Trang `/` dành cho đại lý chỉ có Tên đăng nhập + Mật khẩu và nút đăng ký. Form đăng ký yêu cầu Tên đăng nhập, Số điện thoại, Họ tên, Gmail nhập tay, Mật khẩu và Xác nhận mật khẩu; Gmail là thông tin liên hệ chưa xác minh qua email. Mật khẩu chỉ lưu dạng hash `scrypt` có salt trong bảng credentials riêng, không nằm trong bản ghi hồ sơ/API. Hồ sơ mới ở trạng thái chờ duyệt; không có tài khoản hoặc nhánh đăng nhập mẫu.

Vai trò admin dùng trường `users.role` hiện có và chỉ được cấp bằng bootstrap email được cấu hình qua input bảo mật `V79_SUPERADMIN_EMAIL` (hiện môi trường không cung cấp `OWNER_OPEN_ID`); email chỉ được so khớp server-side với tài khoản Manus OAuth đã đăng nhập. Sau bootstrap, role lưu trong DB. Đại lý chỉ dùng password flow; OAuth `user` không có quyền admin và không thể gửi form đại lý bằng phiên OAuth. Admin có thể xem/duyệt/từ chối hồ sơ; khóa/mở tài khoản; cập nhật liên kết giới thiệu từng đại lý; cộng số dư bằng bút toán dương append-only có lý do; duyệt/từ chối lệnh rút mà không tự chuyển tiền; và xem nhật ký.

Hồ sơ đại lý, thông tin ngân hàng, lệnh rút, sổ cộng số dư và audit log lưu trong database với tRPC procedures được bảo vệ ở server. Lệnh rút phải có số tiền dương trong phạm vi số dư khả dụng; các lệnh chưa bị từ chối được giữ chỗ khi tính số dư khả dụng để không tạo lệnh vượt số dư. Admin duyệt/từ chối chỉ đổi trạng thái; không có tích hợp chi trả ngân hàng. Dữ liệu bắt đầu trống, không seed dữ liệu demo; migration chỉ thêm bảng/cột mới vào schema khởi tạo.

Admin tạo và cập nhật hồ sơ từng hội viên gắn với đại lý; đại lý chỉ xem/tìm trong danh sách của mình theo tên và ngày tham gia. Preview a025 đổi eyebrow thành DANH SÁCH HỘI VIÊN và gỡ paragraph mô tả, giữ bộ lọc/state. Admin nhập Nạp/Rút không có ô ngày giờ; server tự đóng dấu thời điểm. Chỉ số cược/khuyến mãi/hoàn trả/thắng thua thuộc hội viên/tháng. Các loại báo cáo thay hai chế độ cũ bằng một bảng duy nhất đúng bảy cột theo thứ tự: Tên đăng nhập, Nạp tiền, Rút tiền, Khuyến mãi, Hoàn trả, Tổng cược, Tổng thắng thua; tháng bắt buộc, username tùy chọn, tiền hiển thị dạng số điểm không kèm chữ “điểm”. Hoàn trả lấy `refund_vnd` của tháng và bằng 0 nếu chưa có dòng; nạp/rút/điều chỉnh, cược/khuyến mãi/hoàn trả được tổng hợp độc lập, không nhân dòng. Tổng thắng thua lấy công thức `Rút − Nạp − Khuyến mãi − Hoàn trả`, không dùng giá trị net lưu cũ. Không thêm cược hợp lệ, cược thực, hoàn tiền trùng nghĩa, lợi nhuận ròng hoặc chênh lệch. API hỗ trợ loại monthly mặc định, giữ hai loại cũ cho client đã mở trước rollout, UI mới chỉ dùng monthly. Mọi cập nhật Admin được audit; không kết nối hay bịa số liệu nền tảng ngoài.

Hiệu suất hoạt động đại lý có Tháng báo cáo mặc định tháng Việt Nam hiện tại và 8 thẻ: Tổng hội viên, Tổng hội viên hợp lệ, Hội viên mới, Hội viên mới hợp lệ, Tổng thắng thua, Tổng khuyến mãi, Tổng nạp, Tổng rút. Tổng hội viên là toàn bộ hội viên đúng đại lý ở mọi tháng; mới có joined_at trong biên tháng Việt Nam. Bảng member_monthly_validity lưu dấu Admin theo memberId/monthKey duy nhất; thiếu bản ghi là chưa hợp lệ, không suy ra trạng thái lịch sử từ cờ toàn cục. Admin checkbox ở chế độ tháng đọc/ghi tháng đã chọn và audit tháng, khóa hội viên/upsert; chế độ lũy kế không cho ghi nhầm tháng. Cờ cũ giữ nguyên để tương thích API không truyền tháng. Bốn tổng tiền performance cộng nguyên chính xác các dòng từ cùng helper mà bảng báo cáo monthly dùng, gồm điều chỉnh, tiền lịch sử không bị loại theo ngày tham gia. Cache key có user.id chỉ cách ly cache; server luôn lấy quyền từ session. Query tháng không đổi overview/referral/số dư hiện tại; tháng giữ khi chuyển mục, trống/sai/tải/lỗi không fallback số cũ. Migration chỉ thêm bảng/khóa, không sao chép cờ cũ, seed hoặc chỉnh tiền thật.

Theo yêu cầu làm gọn, tám thẻ giữ đúng thứ tự và hiển thị hai ô mỗi hàng (bốn hàng) ở mọi kích thước, gồm mobile. CSS riêng có ưu tiên hơn media query một cột cũ; mobile giảm padding/icon/chữ và dành nguyên chiều ngang thẻ cho con số, cho phép xuống dòng thay vì cắt dữ liệu.

Số dư khả dụng chuyển từ thẻ bên phải vào thanh trên, trước chuông và sau menu ở mobile. Lấy số dư hiện tại từ overview, hiển thị điểm đầy đủ/placeholder khi chưa tải, không chịu bộ lọc tháng; không lặp thẻ hoặc để cột trống. Theo Preview b3 gỡ .agent-performance-note và đưa ngữ cảnh trạng thái hợp lệ tháng đã chọn vào tooltip thẻ.

Form thêm hội viên trong Admin chỉ nhập tên đăng nhập và ngày tham gia tùy chọn sau khi chọn đại lý; bỏ họ tên/SĐT. Backend giữ tương thích trường cũ nhưng cho phép bỏ trống, dùng chuỗi rỗng/null thay vì tự tạo danh tính; cập nhật chỉ username không xóa thông tin cũ. Bảng hội viên gồm Đại lý, Tên đăng nhập, Tổng nạp, Tổng rút, Tổng cược, Khuyến mãi, Hoàn trả, Tổng thắng thua, Ngày tham gia (chỉ ngày), Hội viên hợp lệ, Thao tác; cụm hành động giữ đủ chức năng nhưng thu gọn. Tổng khuyến mãi cộng promotion_vnd lũy kế từng hội viên từ dữ liệu tháng, mặc định 0; dùng cùng truy vấn nhóm cược, không nối giao dịch gây nhân số liệu. Hiển thị điểm qua helper hiện có và giữ bộ lọc/tìm kiếm.

Admin chọn Theo tháng, Hội viên tham gia trong tháng hoặc Lũy kế tất cả tháng. Theo tháng dùng tháng Việt Nam và giữ cả hội viên cũ để xem hoạt động; chỉ chế độ tham gia mới lọc joined_at. Giao dịch dùng biên ngày giờ đầu/tháng kế tiếp và cược/khuyến mãi dùng month_key; chưa chọn tháng thì không fallback lũy kế. Nút Sửa tổng tháng điền sẵn bốn tổng của đúng hội viên và tháng, nhập điểm/lý do, xác nhận trước lưu. Nạp/rút sửa bằng sổ điều chỉnh append-only theo memberId/monthKey, không thay lịch sử giao dịch gốc; cược/khuyến mãi/hoàn trả cập nhật dòng tháng; Tổng thắng thua tính lại bằng Rút − Nạp − Khuyến mãi − Hoàn trả, không dùng giá trị net cũ. Các truy vấn Admin/đại lý dùng chung phép cộng điều chỉnh theo tháng hoặc lũy kế. Khóa hội viên để tuần tự hóa ghi giao dịch/cược/chỉnh tổng, so expected trước khi lưu để tránh ghi đè dữ liệu vừa thay đổi; audit ghi trước/sau, lý do/người sửa. Không tác động số dư hoa hồng, đơn rút hoặc chuyển tiền.

Form Ghi dữ liệu nạp/rút gộp hai ô Số tiền nạp và Số tiền rút cho cùng hội viên; không hiển thị trường Ngày giờ, server tự đóng dấu thời điểm hiện tại giờ Việt Nam; nhập một hoặc cả hai và lưu một lần. Ô trống/0 bỏ qua, ít nhất một khoản dương; các giao dịch và audit lưu cùng transaction với khóa hội viên. Không biến tiền thành ghi chú; API giao dịch đơn cũ vẫn tương thích. Giao diện giữ form chỉ số cược riêng và dùng helper điểm/VND hiện có.

Tổng quan và Đại lý Admin dùng chung Tháng báo cáo; API hiệu suất nhận tháng tùy chọn để tương thích client cũ. Nạp/rút/cược/cược hợp lệ/thắng thua lọc theo tháng Việt Nam được chọn, cùng sổ điều chỉnh báo cáo; số hội viên/hồ sơ/trạng thái và số dư khả dụng vẫn là hiện tại, được ghi rõ. Không chọn tháng thì không hiển thị hiệu suất một tháng khác. Danh sách hồ sơ dùng cho đăng ký, gửi thông báo và chọn đại lý được truy vấn riêng, không bị mất khi thay tháng hiệu suất.

Khuyến mãi và Hoàn trả trong báo cáo bảy cột dùng `promotion_vnd`/`refund_vnd` đã lưu riêng theo hội viên/tháng, độc lập với cược hợp lệ cũ; thiếu dòng tháng trả 0. Admin nhập số điểm trong form Ghi dữ liệu theo tháng; quy đổi qua helper sang VND, bỏ trống giữ dữ liệu cũ và nhập 0 tường minh có thể thay giá trị cũ. API vẫn nhận request cũ không có khuyến mãi/hoàn trả. Giữ audit/khóa/guard VND và filter tháng/username; các số tiền được cộng độc lập, không tác động số dư hoa hồng.

Development và published dùng chung database; không ghi dữ liệu thử vào đó. Lưu ý migration và mọi ghi dữ liệu development tác động cùng DB production. Kiểm tra bằng type/build, code paths và Preview; không tạo seed/đơn rút giả. Giữ `manus-routes.json` đồng bộ với `/`, `/dashboard`, `/admin/login`, `/admin`.

Mục Rút Hoa Hồng bổ sung component Ví ảo USDT, chọn mạng TRC20/ERC20 và lưu địa chỉ bằng nút Thêm. Bảng ví tách khỏi ngân hàng, thuộc đại lý lấy từ session; dùng khóa UTF-8 hex chuẩn hóa để chặn trùng theo đại lý/mạng mà không gộp các địa chỉ TRC20 khác hoa/thường, đồng thời giữ khóa ASCII trước đó. Server kiểm tra profile còn hoạt động trong transaction; theo yêu cầu mới chỉ cần địa chỉ không trống trong giới hạn lưu trữ 64 ký tự, không kiểm tra tiền tố/độ dài cố định/checksum hoặc quyền sở hữu on-chain. Audit chỉ chứa mạng/loại và phần đuôi địa chỉ. Giao diện hiển thị danh sách, pending/lỗi/thành công và giữ form ngân hàng độc lập.

Theo yêu cầu bổ sung, chọn nơi nhận đơn rút cho phép ngân hàng hoặc ví USDT đã thêm của chính đại lý. Đơn mới có snapshot loại nơi nhận/mạng/địa chỉ ví hoặc họ tên/STK/ngân hàng, người nhận ví lấy tên đại lý đã đăng ký; đơn ngân hàng cũ giữ loại bank mặc định. API tương thích bankAccountId cũ, thêm walletAccountId và bắt buộc đúng một lựa chọn, kiểm tra quyền sở hữu và số dư dưới khóa profile. Vẫn lưu số điểm quy đổi VND (1 điểm = 1,000 VND), không tự suy ra số USDT hoặc tỷ giá. Admin xem rõ nơi nhận, duyệt/từ chối bằng luồng cũ và tự thanh toán bên ngoài; không gửi tài sản, không đánh dấu đã chuyển. Preview wpe_0b5b64b049bce0b846f25e4e chỉ gỡ dòng ghi chú quy đổi dưới form, không thay đơn vị hay kiểm tra số dư.

## Cấu trúc chính
- `client/src/pages/Login.tsx`: form username/password và đăng ký đại lý, không có lối xem thử; `client/src/pages/AdminLogin.tsx`: Manus OAuth chỉ dành cho admin ở route riêng.
- `client/src/pages/Dashboard.tsx`: cổng đại lý thật; lấy hồ sơ, số dư, liên kết và lệnh rút qua tRPC.
- `client/src/pages/Admin.tsx`: khu admin được bảo vệ, quản lý hồ sơ, đại lý, liên kết, số dư, lệnh rút, hội viên và hiệu suất.
- `client/src/components/AgentAccountDialogs.tsx` và `server/routers/account.ts`: dialogThông báo/Đổi mật khẩu và API tài khoản chỉ thuộc đại lý hiện tại; session version được ký và kiểm tra ở SDK.
- `client/src/components/MemberList.tsx` và `BankWithdrawalInfo.tsx`: bảng hội viên có lọc; thông tin nhận hoa hồng, tạo lệnh và lịch sử lấy từ DB.
- `client/src/_core/hooks/useAuth.ts`, `client/src/lib/trpc.ts`, `server/_core/oauth.ts`, `context.ts`, `sdk.ts`, `cookies.ts`: phiên Manus cho admin, phiên password cho đại lý, client/server context và cookie an toàn.
- `server/routers.ts` và `server/routers/*.ts`: router đăng ký, agent, member và admin; middleware admin dùng role từ DB.
- `server/db.ts` và `server/db/*.ts`: truy vấn Drizzle, giao dịch nguyên tử, append audit.
- `drizzle/schema.ts`, `drizzle/*.sql`, `drizzle/meta/`: bảng `users`, agency profiles, password credentials riêng, ngân hàng, hội viên, lệnh rút, ledger và audit; migration định hướng bổ sung.
- `Dockerfile`, `client/public/manus-routes.json`, `app.config.ts`: build container/hybrid, khai báo `/`, `/dashboard`, `/admin/login`, `/admin` và metadata logo V79.

## Làm rõ bảng báo cáo
Bảng báo cáo tháng dùng đường kẻ ô 1px xanh xám cho cả hàng/cột và khung ngoài, tiêu đề nền xanh nhạt/chữ đậm, hàng nền trắng xen xanh rất nhạt. Cỡ chữ 12px và số tiền căn phải giúp đối chiếu từng hội viên. CSS giới hạn trong `.agent-monthly-report`, không thay cấu trúc bảy cột, dữ liệu hoặc các bảng khác. Giữ vùng cuộn ngang nội bộ trên điện thoại và màu thắng/thua theo dấu.

Theo yêu cầu mới, Hoàn trả đứng ngay sau Khuyến mãi; Tổng cược đặt tiếp theo Hoàn trả, lấy `totalBetsVnd` từ cùng helper `getMemberPeriodTotals` (tổng `amount_vnd` theo hội viên/tháng, gồm dữ liệu Admin sửa tổng tháng). `totalRefundVnd` lấy độc lập từ `refund_vnd` của tháng. API hiệu suất và biểu đồ Tổng Quan cùng tháng cũng cung cấp tổng Hoàn trả từ helper này; không thêm endpoint/migration hoặc suy ra tiền từ cột khác.

Mức rút tối thiểu dùng helper chung cho frontend/backend: ngân hàng 200 điểm và ví USDT 1,000 điểm, quy đổi bằng VND_PER_POINT. Xác định theo loại nơi nhận, kiểm tra tại form và server trước tạo đơn; giữ kiểm tra số dư, scope, snapshots và không suy ra số USDT/tỷ giá. Không tác động đơn cũ hoặc tự thanh toán.

Preview 2f13626b gỡ riêng h2 Hiệu suất hoạt động, giữ eyebrow/bộ chọn tháng và tám thẻ; không để phần tử heading rỗng. Tổng nạp/rút ở Tổng Quan tiếp tục cộng độc lập tất cả dòng từ cùng helper báo cáo tháng, kể cả điều chỉnh và hội viên cũ; bộ lọc username chỉ thuộc bảng. Hai truy vấn tự làm mới mỗi 30 giây và lấy cùng tháng do dashboard giữ, không tạo phép trừ nạp-rút hoặc trường nhập tổng thủ công.

`changeActivityMonth` cập nhật cả hai state tháng khi người dùng đổi tháng ở Tổng Quan hoặc Các loại báo cáo, tránh chuyển mục hiển thị tổng của tháng khác. Giữ mặc định Tổng Quan là tháng Việt Nam hiện tại và báo cáo chưa chọn tháng ở lần đầu; khi đã chọn/đổi/xóa tháng ở một mục thì mục còn lại đồng bộ, không fallback dữ liệu cũ.

Preview 70889f78 lặp lại việc gỡ h2 ở Tổng Quan (không tạo thao tác kép). Trong chính sách, chỉ thay li đầu phần thưởng hội viên mới bằng điều kiện nạp 3 ngày khác nhau theo nguyên văn yêu cầu; gỡ paragraph thư ngỏ nhưng giữ logo/nhãn và cấu trúc chính sách. Không đổi ghi chú hợp lệ ở mục hoa hồng, các dòng map/bảng, mức thưởng hoặc dấu Admin theo tháng.

Chữ Tổng Quan trong breadcrumb chuyển thành button nhẹ cùng kiểu chữ, gọi setActiveNav(HOME) và đóng menu mobile, không thay URL/reload hoặc reset tháng. Hỗ trợ bàn phím và focus-visible, giữ nhãn mục hiện tại và bộ lọc đã đồng bộ giữa báo cáo/Tổng Quan.

Báo cáo tháng dùng formatVndAsPointNumber để hiển thị số điểm không có hậu tố, gỡ dòng đơn vị phía trên theo yêu cầu bỏ chữ điểm, không thay dữ liệu VND. Màu dương trong .agent-monthly-report được override xanh dương #2563eb với specificity cao hơn CSS chung; số âm giữ đỏ, zero giữ trung tính. Không đổi màu/đơn vị các thẻ Tổng Quan, Admin hay form rút.

Preview d3d4f686 chỉ thêm margin-right 15px cho số dư header và màu #f56e00 cho b hiển thị số dư, dùng CSS thay vì hardcode con số ảnh. Giữ nhãn, dữ liệu hiện tại/formatter, vị trí trước chuông và responsive; các margin khác có giá trị “px” không hợp lệ không thay đổi. Ba mục gỡ heading/thư ngỏ/sửa ghi chú hội viên mới lặp batch đã áp dụng, giữ nguyên trạng thái cuối.

## Biểu đồ hoạt động cuối Tổng Quan
Tái sử dụng Recharts có sẵn và thêm AgentActivityChart sau 8 thẻ, trước footer, cùng component/query tháng AgentPerformance để không gọi endpoint hai lần. Backend performance bổ sung totalBetsVnd từ cùng helper báo cáo, cộng số nguyên chính xác; không migration. Biểu đồ 4 cột theo thứ tự Nạp/Rút/Cược/Thắng thua, xanh lá/cam/tím/xanh dương, kèm chú giải giá trị và tooltip.
Trục điểm tuyến tính, mốc gốc 0, 5,000, 10,000, 30,000, 50,000, 100,000 (khoảng cách trên trục phản ánh khoảng số, không giả bằng nhau). Giữ tối thiểu dải0–100,000; dữ liệu âm mở phần dưới0, vượt100,000 mở trục và ghi chú. Khi dải quá rộng, giảm nhãn trục gần nhau để tránh chồng, vẫn ghi đủ sáu mốc tham chiếu bên dưới. Formatter nhãn/tooltip giữ nguyên VND nguyên an toàn và đổi điểm chính xác; phép chia chỉ cho tọa độ biểu đồ. Không tạo cột 0 giả khi chưa tải/lỗi/tháng trống. CSS giữ dashboard gọn, responsive; bảng số liệu hỗ trợ screen reader. shared/activity-chart.ts sở hữu màu/mốc/hàm tạo dữ liệu và trục để test độc lập.

## Thống kê khách và sắp xếp trong Admin
Hội viên & báo cáo thêm hai chỉ số khi chọn đại lý: khách tổng nạp>0 và khách isValid=1 theo kỳ/tháng API. Observer admin.members cho thống kê dùng agencyId + month (không joinedInMonth/tìm username), dùng lại cùng cache/request với bảng trong phạm vi Theo tháng/Lũy kế; chế độ chỉ hội viên tham gia trong tháng vẫn lấy tổng toàn đại lý ở chỉ số. Không thêm endpoint/schema; invalidate members hiện có cập nhật cả bảng/thống kê. Hiển thị kỳ rõ và giữ semantics cờ isValid mà API trả trong lũy kế. Khi loading/lỗi/không đủ scope hiển thị placeholder.
shared/admin-member-view.ts sở hữu đếm ID duy nhất và sort số nạp ascending/descending không mutate dữ liệu cache; client chỉ sort các dòng đang hiển thị, số đếm không bị ảnh hưởng bởi search. Điều khiển sắp xếp ở nhóm bộ lọc, mặc định giữ thứ tự cũ. Các editor, chọn tháng và quyền ghi giữ nguyên.

## Tổng Quan rút gọn sau khi có biểu đồ
Yêu cầu mới nhất thay bố cục8thẻ: chỉ giữ4thẻ hội viên, 2ô/hàng, gỡ4thẻ tài chính theo ảnh. Dữ liệu tiền tập trung ở biểu đồ5cột Nạp/Rút/Cược/Thắng thua/Khuyến mãi; thêm totalPromotionVnd vào ACTIVITY_SERIES với màu hồng riêng #ec4899. API đã có tổng khuyến mãi nên không thêm query/server field. Nhãn trục X hai từ xuống2dòng và cột tự co để đủ5cột trên mobile; chú giải5mục, mốc/trục/tooltip/dữ liệu tháng giữ nguyên. Không thay phần Admin đếm/sort hoặc số dư.

## Preview nhãn và chú thích màu
Hai nhãn giới thiệu dùng màu chính xác của batch7d389e88: QR #4c00ff chỉ nhãn QR thật (không fallback), liên kết #4000ff chỉ span nhãn. Bỏ đoạn Mốc điểm phụ; mốc trục số và thuật toán adaptive giữ nguyên. Chú thích màu thắng/thua thay đoạn thông báo zero, màu #00bbfa, xuất hiện khi biểu đồ có dữ liệu (kể cả zero). Bar/chấm chú giải Thắng thua lấy màu theo dấu VND: dương #2563eb, âm #dc2626, zero #64748b; bốn chuỗi khác giữ bảng màu. Không sửa giá trị, API hoặc state; scope CSS và helper hiển thị riêng biểu đồ.

## Hiệu suất trong mục Đại lý Admin
Bổ sung ba trường vào admin.agencies: monthPromotionVnd (SUM promotionVnd theo tháng), monthDepositorCount (số memberId duy nhất có tổng nạp tháng + depositDelta tháng >0), monthValidMemberCount (dấu hợp lệ1 đúng tháng). Các aggregate độc lập theo agency/member tránh nhân tiền khi có nhiều giao dịch; không N+1 theo đại lý. memberCount và số dư/hồ sơ vẫn hiện tại. Cột Hiệu suất của Quản lý đại lý hiển thị thêm Số hội viên nạp/Hội viên hợp lệ và Khuyến mãi bằng điểm; field thiếu trong cache/rollout hiển thị —, dùng cùng tháng đang chọn, không thêm form hay đổi quyền.

## Rút gọn dòng cược trong quản lý đại lý
Theo ảnh mới, ô Hiệu suất của Quản lý đại lý chỉ hiển thị Tổng cược, gỡ dòng Cược hợp lệ. Giữ dữ liệu/API cược hợp lệ phục vụ nghiệp vụ và các view khác; không thay số liệu Tổng cược hoặc các chỉ số vừa thêm.

## Tìm kiếm trong tab Đại lý
Ô Tìm đại lý lọc directory đã được Admin API cấp quyền, theo username/fullName; normalize hoa/thường, dấu tiếng Việt/đ và @username. Không thêm query hay lọc các tab khác. Chỉ dùng danh sách filtered trong Quản lý đại lý, vẫn tra hiệu suất theo ID và giữ tháng. Badge thể hiện số khớp/tổng, trạng thái không khớp riêng; xóa query trở lại danh sách đầy đủ. shared/admin-agency-search.ts chứa helper thuần không mutate để kiểm tra normalize/khớp tên.

## Ảnh CSKH cho nút liên hệ Telegram
Thay Send SVG bằng ảnh CSKH người dùng cung cấp, giữ toàn bộ tỷ lệ vuông và nội dung; resize/encode WebP qua Pillow chỉ để giảm dung lượng, không semantic edit. Lưu ảnh bằng project storage và dùng /manus-storage URL. Nút giữ góc phải dưới hiện tại, tab mới/rel/aria/focus/safe-area/z-index; khung vuông gọn thay vòng tròn cũ để không cắt chữ, desktop/mobile co phù hợp. Không đổi URL Telegram hoặc thêm tính năng liên hệ.

## Batch Preview 97274ad8
Trong breakpoint mobile ≤640px, thu nút ảnh CSKH còn 60px vuông; giữ kích thước desktop, anchor/link/tab mới/safe-area/focus và object-fit contain. Giá trị radius `px` trong Preview là CSS không hợp lệ nên dùng 0px có chủ đích để thể hiện ảnh vuông trọn vẹn, không đưa giá trị lỗi vào source. Riêng eyebrow trong tiêu đề Tổng Quan đổi chữ thành “TỔNG HỢP DỮ LIỆU” và #00bfff bằng selector `.agent-section-title .agent-eyebrow`; các eyebrow khác không đổi.

## Quản lý hội viên và sửa giao dịch nạp/rút
Không DELETE cứng hồ sơ hội viên: Admin đánh dấu lưu trữ bằng deletedAt, ẩn khỏi danh sách/báo cáo hoạt động, giữ toàn bộ giao dịch/báo cáo/audit và cho khôi phục qua bộ lọc lưu trữ. Transaction history được tải theo hội viên và tháng đã chọn; Admin có thể sửa duy nhất amountVnd của giao dịch, không đổi loại/ngày giờ/hội viên. Mutation xác nhận/khóa transaction, audit giá trị trước-sau, quy đổi điểm/VND chính xác và tính lại Tổng thắng thua tháng theo công thức đã thống nhất. Tất cả API chỉ Admin OAuth, truy vấn memberId/transactionId được kiểm tra cùng member và mọi thử nghiệm dùng mock/fixture.

## Định danh hội viên toàn hệ thống
Username hội viên unique ở cấp toàn DB thay vì tổ hợp agencyId/username; archived username tiếp tục được giữ chỗ để không tạo xung đột lịch sử hoặc giao dịch. Server pre-check cho thông báo dễ hiểu; unique index là lớp bảo vệ cuối khi có request cạnh tranh. Trước migration chỉ đọc phát hiện trùng hiện hữu; không tự đổi username.

## Hiệu suất Admin tổng hợp khuyến mãi và hoàn trả
Bảng tổng quan Admin giữ cột Tổng cược tháng, bỏ cột Tổng cược hợp lệ tháng và thay bằng cột Khuyến mãi + Hoàn trả. API nhóm riêng promotionVnd/refundVnd theo tháng và đại lý, dùng aggregate không nhân dòng; cột gộp chỉ cộng hai chỉ số, không thay đổi Tổng cược ở trang hội viên.

Ở bảng Hiệu suất đại lý của Tổng quan Admin, xếp username đại lý (chữ lớn) lên trước và họ tên (chữ nhỏ) xuống dưới; chỉ đổi thứ tự/thị giác, không đổi dữ liệu.

## Thông báo đại lý chờ duyệt
Trong trạng thái hồ sơ đang chờ duyệt, thay lời giải thích mặc định bằng CTA chính xác “VUI LÒNG LIÊN HỆ TELEGRAM ĐẠI LÝ @DAILYV79 ĐỂ DUYỆT HỒ SƠ”; handle @DAILYV79 mở Telegram an toàn. Dùng màu xanh dương và nhấp nháy nhẹ, tắt chuyển động theo prefers-reduced-motion.

## Quy ước dấu Thắng/Thua (cập nhật mới nhất)
Dùng công thức `Rút − Nạp − Khuyến mãi − Hoàn trả`; ví dụ Nạp 300, Rút 200, Khuyến mãi 20 ⇒ −120. Hiển thị dấu âm rõ ràng và màu đỏ; áp dụng cùng helper ở form Admin và dữ liệu API/tháng.

## Cột thắng/thua bảng hội viên Admin
Bảng hội viên & báo cáo thêm Hoàn trả và Tổng thắng thua theo kỳ/tháng đang lọc, đặt cạnh các cột tiền. Nhãn “Khuyến mãi” không có tiền tố “Tổng”; Ngày tham gia chỉ hiện ngày. Thắng/thua tính từ cùng totals helper bằng công thức mới và format/màu signed dùng chung; hành động giữ đủ chức năng nhưng nén gọn theo ảnh.


## Ảnh trong thông báo Admin
Cho phép đính kèm tối đa một ảnh mỗi thông báo, có preview/clear trước khi gửi. Dùng tRPC Admin-protected upload handler đọc file đã giới hạn kích thước và kiểm tra magic bytes/type; tạo object key duy nhất, ghi key cùng thông báo/audit trong transaction SQL ngắn rồi mới PUT ảnh ngoài transaction. Như vậy SQL rollback xảy ra trước upload, còn kết quả PUT không chắc chắn vẫn có key được tham chiếu trong DB; UI báo không gửi lại để tránh thông báo trùng. Dùng migration additive và giới hạn thời gian cho các lần gọi Storage. Storage key và presigned URL luôn chỉ ở server. Khi Admin xem lịch sử hoặc đại lý mở chi tiết, endpoint phải kiểm quyền/agency scope, lấy ảnh qua signed URL phía server với timeout, kiểm Content-Length và đọc streaming có giới hạn cứng 5 MiB, xác nhận magic bytes/MIME rồi trả dữ liệu ảnh không-cache cho client; không đưa public object path/key vào HTML. Gửi ảnh cùng tiêu đề/nội dung/đối tượng trong mutation hiện có; giữ khả năng đọc/đánh dấu đọc và rendering lịch sử cũ không ảnh.

## Màu và dấu thắng/thua trên biểu đồ Đại lý
Series Thắng thua theo signed value: số âm giữ dấu trừ, đỏ `#dc2626`; số dương không thêm dấu `+`, xanh lá `#16a34a`; zero trung tính. Đồng bộ bar/chấm, tooltip và chú giải; formatter tiền điểm giữ dấu âm thật, không thay đổi nguồn/tính toán/API.


## Form Nạp/Rút tự đóng dấu thời gian
Trong form Admin chọn Lịch sử nạp/rút, không render input Ngày giờ; server tự ghi thời điểm hiện tại cho từng khoản theo giờ Việt Nam. Payload không nhận thời gian do client chỉ định, giữ các trường tiền/loại/hội viên, điều chỉnh và audit hiện có; lịch sử hiển thị timestamp đã lưu.


## Batch Preview Admin bf4fd5f5
Trong `/admin`, giữ dòng đơn vị “Đơn vị số tiền: điểm · 1 điểm = 1,000 VND” và bỏ phần “· Dấu phẩy phân cách hàng nghìn.”; trong `.admin-safety-note`, xóa nội dung span được chọn theo Preview, giữ cấu trúc cha và icon, không thay đổi logic phê duyệt/rút tiền.
