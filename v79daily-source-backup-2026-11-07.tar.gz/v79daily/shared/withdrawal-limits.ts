import { VND_PER_POINT, formatVnd, formatVndAsPoints } from "./money";

export type WithdrawalDestination = "bank" | "usdt";

export const MIN_BANK_WITHDRAWAL_POINTS = 200;
export const MIN_USDT_WITHDRAWAL_POINTS = 1_000;
export const MIN_BANK_WITHDRAWAL_VND = MIN_BANK_WITHDRAWAL_POINTS * VND_PER_POINT;
export const MIN_USDT_WITHDRAWAL_VND = MIN_USDT_WITHDRAWAL_POINTS * VND_PER_POINT;

export function withdrawalMinimumVnd(destination: WithdrawalDestination): number {
  return destination === "bank" ? MIN_BANK_WITHDRAWAL_VND : MIN_USDT_WITHDRAWAL_VND;
}

export function formatWithdrawalMinimum(destination: WithdrawalDestination): string {
  const amountVnd = withdrawalMinimumVnd(destination);
  return `${formatVndAsPoints(amountVnd)} (${formatVnd(amountVnd)})`;
}

export function withdrawalMinimumMessage(destination: WithdrawalDestination): string {
  const label = destination === "bank" ? "ngân hàng" : "ví USDT";
  return `Số tiền rút tối thiểu cho ${label} là ${formatWithdrawalMinimum(destination)}.`;
}
