function normalizeSearchText(value: string): string {
  return value
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/đ/g, "d");
}

/** Return matching agencies in source order without mutating the input rows. */
export function filterAdminAgencies<
  T extends { username: string; fullName: string },
>(rows: readonly T[], query: string): T[] {
  const normalizedQuery = normalizeSearchText(query);
  if (normalizedQuery === "") return rows.slice();

  const usernameQuery = normalizedQuery.startsWith("@")
    ? normalizedQuery.slice(1)
    : normalizedQuery;

  return rows.filter((row) => {
    const usernameMatches =
      usernameQuery.length > 0 &&
      normalizeSearchText(row.username).includes(usernameQuery);
    const fullNameMatches = normalizeSearchText(row.fullName).includes(
      normalizedQuery,
    );
    return usernameMatches || fullNameMatches;
  });
}
