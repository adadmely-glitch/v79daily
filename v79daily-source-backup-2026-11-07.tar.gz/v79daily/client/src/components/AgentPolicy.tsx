import {
  AlertCircle,
  Clock3,
  Coins,
  FileText,
  WalletCards,
} from "lucide-react";
import { V79_LOGO_SRC } from "@/brand";

const commissionTiers = [
  { profit: "1+", members: "3+", rate: "35%" },
  { profit: "", members: "5+", rate: "45%" },
  { profit: "100,000+", members: "10+", rate: "50%" },
  { profit: "1,000,000+", members: "20+", rate: "55%" },
  { profit: "5,000,000+", members: "30+", rate: "60%" },
];

export default function AgentPolicy() {
  return (
    <section className="policy-page" aria-labelledby="policy-title">
      <div className="policy-page-heading">
        <div>
          <h1 id="policy-title">Chính Sách Đại Lý</h1>
        </div>
        <div className="policy-unit"><Coins size={16} /><span>Đơn vị: <b>điểm</b></span><i /> <span>1 điểm = <b>1,000 VND</b></span></div>
      </div>

      <div className="policy-letter">
        <img className="policy-letter-mark" src={V79_LOGO_SRC} alt="V79" />
        <div>
          <span className="policy-small-heading">THƯ NGỎ</span>
        </div>
      </div>

      <section className="policy-section" aria-labelledby="commission-policy-title">
        <div className="policy-section-heading">
          <div className="policy-banner-heading"><h2 id="commission-policy-title"><img className="policy-title-banner" src="/manus-storage/pasted_file_vCHWTS_image_26b224dd.png" width="464" height="53" alt="Hoa Hồng Đại Lý" /></h2><p>Mức áp dụng theo lợi nhuận ròng và số hội viên hợp lệ trong tháng.</p></div>
        </div>

        <div className="policy-table-wrap">
          <table className="policy-table">
            <thead><tr><th>Lợi nhuận ròng (điểm)</th><th>Thành viên hợp lệ</th><th>Tỷ lệ hoa hồng</th></tr></thead>
            <tbody>{commissionTiers.map((tier) => <tr key={`${tier.members}-${tier.rate}`}><td>{tier.profit}</td><td>{tier.members}</td><td><span className="policy-rate-pill">{tier.rate}</span></td></tr>)}</tbody>
          </table>
        </div>

        <div className="policy-formula-grid">
          <article className="formula-card"><span className="formula-index">01</span><div><b>Lợi nhuận ròng</b><p>Tổng thắng thua − tổng hoàn trả − tổng khuyến mãi − chi phí nền tảng.</p></div></article>
          <article className="formula-card"><span className="formula-index">02</span><div><b>Chi phí nền tảng</b><p>Tổng thắng thua × 10%. Nếu đại lý trong tháng không có lợi nhuận âm thì không tính chi phí nền tảng.</p></div></article>
          <article className="formula-card"><span className="formula-index">03</span><div><b>Hoa hồng</b><p>Lợi nhuận ròng × tỷ lệ hoa hồng.</p></div></article>
        </div>
        <div className="policy-examples">
          <p><b>Ví dụ 1.</b> Lợi nhuận ròng 2,000,000 điểm, 5 hội viên hợp lệ: 2,000,000 × 45% = <b>900,000 điểm</b> (900 triệu VND).</p>
        </div>
        <ul className="policy-bullet-list">
          <li>Số hội viên hợp lệ tối thiểu trong tháng để nhận hoa hồng là 3.</li>
          <li>Nếu trong tháng đại lý không đạt được hai điều kiện nêu trên thì không được tính hoa hồng tháng đó.</li>
          <li>Hội viên hợp lệ trong tháng cần nạp tiền ≥ 1,000 điểm và cược hợp lệ ≥ 3,000 điểm; việc phê duyệt dựa trên đánh giá tổng hợp IP, tính hoạt động và tính nạp lại.</li>
        </ul>
        <div className="policy-notice policy-notice-amber"><AlertCircle size={17} /><div><b>Lưu ý về từ khóa và sản phẩm</b><p>Đại lý Google SEO/ADS chạy từ khóa nội bộ của công ty (ví dụ: link mới V79, link V79, Đăng nhập V79...) áp dụng mức hoa hồng cố định 15%. Nếu phát hiện SEO các từ khóa liên quan đến các web trong VAP, mức 15% cũng được áp dụng. Chương trình không áp dụng với sản phẩm xổ số.</p></div></div>
      </section>

      <section className="policy-section policy-bonus-section" aria-labelledby="new-member-bonus-title">
        <div className="policy-section-heading">
          <div className="policy-banner-heading"><h2 id="new-member-bonus-title"><img className="policy-title-banner" src="/manus-storage/pasted_file_orhaLe_image_6ed661f6.png" width="464" height="53" alt="Tiền Thưởng Phát Triển Hội Viên Mới" /></h2></div>
        </div>
        <div className="policy-table-wrap">
          <table className="policy-table bonus-table">
            <thead><tr><th>Đối tượng</th><th>Hội viên mới hợp lệ</th><th>Tiền thưởng</th><th>Tỉ lệ hoa hồng</th></tr></thead>
            <tbody><tr><td>Tất cả đại lý hợp tác</td><td>1+</td><td><span className="policy-rate-pill policy-blue-pill">200 điểm / hội viên</span></td><td>Không giới hạn</td></tr></tbody>
          </table>
        </div>
        <div className="policy-examples"><p><b>Ví dụ.</b> 10 hội viên mới hợp lệ trong tháng: 10 × 200 = <b>2,000 điểm</b> (2 triệu VND).</p></div>
        <ul className="policy-bullet-list">
          <li>Hội viên mới hợp lệ là hội viên nạp đầu trong tháng, tích lũy nạp tiền ≥ 1,000 điểm và cược hợp lệ ≥ 3,000 điểm , số ngày nạp tiền 3 ngày khác nhau</li>
          <li>Đại lý Google SEO/ADS chạy từ khóa nội bộ của công ty không tham gia chương trình thưởng hội viên mới.</li>
          <li>Chương trình không áp dụng với sản phẩm xổ số.</li>
        </ul>
      </section>

      <section className="policy-section" aria-labelledby="payout-title">
        <div className="policy-section-heading">
          <div className="policy-banner-heading"><h2 id="payout-title"><img className="policy-title-banner" src="/manus-storage/pasted_file_q766dC_image_e4600746.png" width="464" height="53" alt="Cách Thức Phát Hoa Hồng Và Tiền Thưởng" /></h2></div>
        </div>
        <div className="policy-info-grid">
          <article className="policy-info-card"><Clock3 size={18} /><div><b>Thời gian phát</b><p>Hoa hồng và tiền thưởng hội viên mới được phát trước ngày 10 mỗi tháng.</p></div></article>
          <article className="policy-info-card"><WalletCards size={18} /><div><b>Nhận tiền &amp; rút tiền</b><p>Khoản thưởng được thanh toán trực tiếp vào ví số dư trong tài khoản đại lý. Sau khi hệ thống kết toán, đại lý có thể tạo lệnh rút qua tài khoản ngân hàng hoặc ví điện tử đã liên kết.</p></div></article>
        </div>
        <div className="policy-notice policy-notice-purple"><FileText size={17} /><p>Nếu trong ba tháng liên tiếp, đại lý không đạt 3 khách mới hợp lệ mỗi tháng, công ty sẽ điều chỉnh tỷ lệ hoa hồng xuống 20%. Tỷ lệ tự động khôi phục về mức bình thường khi đại lý đạt 3 thành viên mới đủ điều kiện trong bất kỳ tháng nào sau đó.</p></div>
      </section>

      <section className="policy-section policy-terms-section" aria-labelledby="terms-title">
        <div className="policy-section-heading">
          <div className="policy-banner-heading"><h2 id="terms-title"><img className="policy-title-banner" src="/manus-storage/pasted_file_PRwxbd_image_9027a4f0.png" width="464" height="53" alt="Tính Toán Hoa Hồng Và Điều Khoản" /></h2></div>
        </div>
        <ul className="policy-terms-list">
          <li><span>01</span><p>Công thức tính hoa hồng: lợi nhuận ròng × tỷ lệ hoa hồng.</p></li>
          <li><span>02</span><p>Nếu đại lý có lợi nhuận dương thì sẽ trừ vào lợi nhuận các tháng sau cho tới khi hết lợi nhuận dương.</p></li>
          <li><span>03</span><p>Hội viên lạm dụng, nhiều tài khoản, chạy chỉ tiêu hoặc làm giả số liệu sẽ không được tính là hội viên hợp lệ.</p></li>
          <li><span>04</span><p>Thành viên không được tạo tài khoản game của mình dưới link đại lý của mình. Nếu vi phạm, tài khoản đó sẽ bị kéo khỏi đường link đại lý; nếu nghiêm trọng, hợp tác có thể bị chấm dứt.</p></li>
          <li><span>05</span><p>Công ty có quyền đơn phương chấm dứt hợp tác nếu phát hiện đại lý có hành vi lạm dụng để trục lợi hoa hồng không chính đáng.</p></li>
          <li><span>06</span><p>Nếu phát sinh vấn đề không đồng nhất trong cách hiểu về chương trình, công ty bảo lưu quyết định cuối cùng trong mọi trường hợp.</p></li>
        </ul>
      </section>

    </section>
  );
}
