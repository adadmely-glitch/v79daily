import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import AdminPayoutDestination from "../client/src/components/AdminPayoutDestination";

function render(kind: "bank" | "usdt", value: string | null | undefined) {
  return renderToStaticMarkup(createElement(AdminPayoutDestination, { kind, value, withdrawalId: 42 }));
}

describe("Admin recipient destination", () => {
  it("shows the full bank account number with leading zeroes and a dedicated copy label", () => {
    const html = render("bank", "0000123456789");
    expect(html).toContain("0000123456789");
    expect(html).toContain("STK ngân hàng");
    expect(html).toContain('aria-label="Sao chép STK đơn #42"');
    expect(html).toContain('type="button"');
  });

  it("shows a complete wallet address without lowercase conversion or ellipsis", () => {
    const address = "0x" + "AbCd".repeat(10);
    const html = render("usdt", address);
    expect(html).toContain(address);
    expect(html).not.toContain(address.toLowerCase());
    expect(html).toContain("Địa chỉ ví USDT");
    expect(html).toContain('aria-label="Sao chép địa chỉ ví đơn #42"');
  });

  it("escapes a freely entered address instead of treating it as HTML", () => {
    const html = render("usdt", "<script>alert(1)</script>");
    expect(html).not.toContain("<script>");
    expect(html).toContain("&lt;script&gt;");
  });

  it.each([null, undefined, "", "   "])("shows an explicit warning and no copy button for missing destination %s", (value) => {
    const html = render("usdt", value);
    expect(html).toContain("Chưa có địa chỉ ví trên đơn này");
    expect(html).not.toContain("admin-payout-copy");
    expect(html).not.toContain("admin-payout-value");
  });
});
