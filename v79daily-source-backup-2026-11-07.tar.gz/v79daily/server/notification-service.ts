import { TRPCError } from "@trpc/server";
import { and, count, desc, eq, inArray, isNull, or, sql, type SQL } from "drizzle-orm";
import { z } from "zod";
import { NOTIFICATION_PAGE_SIZE } from "@shared/notifications";
import { agencyNotificationReads, agencyNotifications, agencyProfiles, balanceCredits, withdrawalRequests } from "../drizzle/schema";
import type { getDb } from "./db";
import { safeVndTotal } from "./reporting-utils";
import { storageGetSignedUrl } from "./storage";

type Database = NonNullable<Awaited<ReturnType<typeof getDb>>>;
export const MAX_NOTIFICATION_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_NOTIFICATION_IMAGE_BASE64_LENGTH = 4 * Math.ceil(MAX_NOTIFICATION_IMAGE_BYTES / 3);
const notificationImageInputSchema = z.object({
  contentType: z.enum(["image/png", "image/jpeg", "image/webp"]),
  data: z.string().min(4).max(MAX_NOTIFICATION_IMAGE_BASE64_LENGTH).regex(/^[A-Za-z0-9+/]*={0,2}$/),
}).strict();
export type NotificationImageInput = z.infer<typeof notificationImageInputSchema>;
const notificationImageKeyPattern = /^agency-notifications\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_[0-9a-f]{8}\.(png|jpg|webp)$/;

export function notificationImageContentType(imageKey: string | null | undefined) {
  if (!imageKey) return null;
  const match = notificationImageKeyPattern.exec(imageKey);
  if (!match) return null;
  if (match[1] === "png") return "image/png" as const;
  if (match[1] === "jpg") return "image/jpeg" as const;
  return "image/webp" as const;
}

async function readBoundedImageBytes(response: Response): Promise<Buffer> {
  const contentLength = response.headers.get("content-length");
  if (contentLength !== null) {
    const declaredLength = Number(contentLength);
    if (!Number.isSafeInteger(declaredLength) || declaredLength < 0 || declaredLength > MAX_NOTIFICATION_IMAGE_BYTES) {
      throw new Error("Stored notification image exceeds the allowed size");
    }
  }
  const reader = response.body?.getReader();
  if (!reader) throw new Error("Storage returned no image body");
  const chunks: Uint8Array[] = [];
  let totalBytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      totalBytes += value.byteLength;
      if (totalBytes > MAX_NOTIFICATION_IMAGE_BYTES) {
        await reader.cancel().catch(() => undefined);
        throw new Error("Stored notification image exceeds the allowed size");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk)), totalBytes);
}

export async function readNotificationImage(imageKey: string | null | undefined) {
  const contentType = notificationImageContentType(imageKey);
  if (!contentType || !imageKey) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy ảnh thông báo." });
  try {
    const signedUrl = await storageGetSignedUrl(imageKey);
    const response = await fetch(signedUrl, { signal: AbortSignal.timeout(15_000) });
    if (!response.ok) throw new Error("Storage image request failed");
    const bytes = await readBoundedImageBytes(response);
    if (bytes.length === 0 || bytes.length > MAX_NOTIFICATION_IMAGE_BYTES || !imageSignature(contentType, bytes)) {
      throw new Error("Stored notification image is invalid");
    }
    return { contentType, data: bytes.toString("base64") };
  } catch {
    throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Không thể tải ảnh thông báo lúc này." });
  }
}

function imageSignature(contentType: NotificationImageInput["contentType"], bytes: Buffer) {
  if (contentType === "image/png") return bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (contentType === "image/jpeg") return bytes.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]));
  return bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP";
}

export function decodeNotificationImage(input: NotificationImageInput | undefined) {
  if (!input) return null;
  const parsed = notificationImageInputSchema.safeParse(input);
  if (!parsed.success || parsed.data.data.length % 4 !== 0) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Ảnh thông báo không hợp lệ. Chỉ nhận PNG, JPEG hoặc WebP." });
  }
  const { contentType, data } = parsed.data;
  let bytes: Buffer;
  try {
    bytes = Buffer.from(data, "base64");
  } catch {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Ảnh thông báo không hợp lệ. Chỉ nhận PNG, JPEG hoặc WebP." });
  }
  if (bytes.length === 0 || bytes.length > MAX_NOTIFICATION_IMAGE_BYTES || bytes.toString("base64") !== data || !imageSignature(contentType, bytes)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Ảnh thông báo không hợp lệ. Chỉ nhận PNG, JPEG hoặc WebP." });
  }
  const extension = contentType === "image/jpeg" ? "jpg" : contentType.slice("image/".length);
  return { bytes, contentType, extension };
}

const noticeKey = sql<string>`concat('notice-', ${agencyNotifications.id})`;
const creditKey = sql<string>`concat('credit-', ${balanceCredits.id})`;
const withdrawalKey = sql<string>`concat('withdrawal-', ${withdrawalRequests.id}, '-', ${withdrawalRequests.status})`;
const statusText = { pending: "đang chờ duyệt", approved: "đã được quản trị viên duyệt", rejected: "đã bị từ chối" };

function readJoin(agencyId: number, eventKey: SQL<string>) {
  return and(eq(agencyNotificationReads.agencyId, agencyId), eq(agencyNotificationReads.eventKey, eventKey));
}
function noticeScope(agencyId: number) {
  return or(eq(agencyNotifications.agencyId, agencyId), isNull(agencyNotifications.agencyId));
}

export async function getNotificationFeed(db: Database, agencyId: number, unreadOnly: boolean) {
  const unreadFilter = unreadOnly ? isNull(agencyNotificationReads.id) : undefined;
  const [notices, credits, withdrawals] = await Promise.all([
    db.select({ id: agencyNotifications.id, title: agencyNotifications.title, body: agencyNotifications.body, imageKey: agencyNotifications.imageKey, createdAt: agencyNotifications.createdAt, readAt: agencyNotificationReads.readAt })
      .from(agencyNotifications).leftJoin(agencyNotificationReads, readJoin(agencyId, noticeKey))
      .where(and(noticeScope(agencyId), unreadFilter)).orderBy(desc(agencyNotifications.createdAt)).limit(NOTIFICATION_PAGE_SIZE),
    db.select({ id: balanceCredits.id, amountVnd: balanceCredits.amountVnd, reason: balanceCredits.reason, createdAt: balanceCredits.createdAt, readAt: agencyNotificationReads.readAt })
      .from(balanceCredits).leftJoin(agencyNotificationReads, readJoin(agencyId, creditKey))
      .where(and(eq(balanceCredits.agencyId, agencyId), unreadFilter)).orderBy(desc(balanceCredits.createdAt)).limit(NOTIFICATION_PAGE_SIZE),
    db.select({ id: withdrawalRequests.id, amountVnd: withdrawalRequests.amountVnd, status: withdrawalRequests.status, requestedAt: withdrawalRequests.requestedAt, reviewedAt: withdrawalRequests.reviewedAt, readAt: agencyNotificationReads.readAt })
      .from(withdrawalRequests).leftJoin(agencyNotificationReads, readJoin(agencyId, withdrawalKey))
      .where(and(eq(withdrawalRequests.agencyId, agencyId), unreadFilter))
      .orderBy(desc(sql`coalesce(${withdrawalRequests.reviewedAt}, ${withdrawalRequests.requestedAt})`)).limit(NOTIFICATION_PAGE_SIZE),
  ]);
  return [
    ...notices.map((entry) => ({ id: `notice-${entry.id}`, eventKey: `notice-${entry.id}`, kind: "admin" as const, title: entry.title, message: entry.body, imageAvailable: Boolean(notificationImageContentType(entry.imageKey)), amountVnd: null, createdAt: entry.createdAt, readAt: entry.readAt ?? null, isRead: Boolean(entry.readAt) })),
    ...credits.map((entry) => ({ id: `credit-${entry.id}`, eventKey: `credit-${entry.id}`, kind: "credit" as const, title: "Đã cộng số dư", message: entry.reason, imageAvailable: false, amountVnd: safeVndTotal(entry.amountVnd), createdAt: entry.createdAt, readAt: entry.readAt ?? null, isRead: Boolean(entry.readAt) })),
    ...withdrawals.map((entry) => ({ id: `withdrawal-${entry.id}`, eventKey: `withdrawal-${entry.id}-${entry.status}`, kind: "withdrawal" as const, title: `Yêu cầu rút #${entry.id}`, message: `Yêu cầu rút của bạn ${statusText[entry.status]}.`, imageAvailable: false, amountVnd: safeVndTotal(entry.amountVnd), createdAt: entry.reviewedAt ?? entry.requestedAt, readAt: entry.readAt ?? null, isRead: Boolean(entry.readAt) })),
  ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, NOTIFICATION_PAGE_SIZE);
}

export async function getNotificationUnreadCount(db: Database, agencyId: number) {
  const unread = isNull(agencyNotificationReads.id);
  const results = await Promise.all([
    db.select({ count: count() }).from(agencyNotifications).leftJoin(agencyNotificationReads, readJoin(agencyId, noticeKey)).where(and(noticeScope(agencyId), unread)),
    db.select({ count: count() }).from(balanceCredits).leftJoin(agencyNotificationReads, readJoin(agencyId, creditKey)).where(and(eq(balanceCredits.agencyId, agencyId), unread)),
    db.select({ count: count() }).from(withdrawalRequests).leftJoin(agencyNotificationReads, readJoin(agencyId, withdrawalKey)).where(and(eq(withdrawalRequests.agencyId, agencyId), unread)),
  ]);
  const counts = results.map((rows) => Number(rows[0]?.count ?? 0));
  const total = counts.reduce((sum, value) => sum + value, 0);
  if (counts.some((value) => !Number.isSafeInteger(value) || value < 0) || !Number.isSafeInteger(total)) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Chưa thể xác định số thông báo chưa đọc." });
  }
  return { count: total };
}

export async function markNotificationKeysRead(db: Database, agencyId: number, userId: number, eventKeys: string[]) {
  const keys = [...new Set(eventKeys)];
  const idsFor = (kind: string) => [...new Set(keys.filter((key) => key.startsWith(`${kind}-`)).map((key) => Number(key.split("-")[1])))];
  return db.transaction(async (tx) => {
    const [profile] = await tx.select({ id: agencyProfiles.id, status: agencyProfiles.status }).from(agencyProfiles)
      .where(and(eq(agencyProfiles.id, agencyId), eq(agencyProfiles.userId, userId))).limit(1).for("update");
    if (!profile || profile.status !== "approved") throw new TRPCError({ code: "FORBIDDEN", message: "Tài khoản đại lý chưa được duyệt hoặc đang khóa." });
    const noticeIds = idsFor("notice"), creditIds = idsFor("credit"), withdrawalIds = idsFor("withdrawal");
    const notices = noticeIds.length ? await tx.select({ id: agencyNotifications.id }).from(agencyNotifications)
      .where(and(noticeScope(agencyId), inArray(agencyNotifications.id, noticeIds))) : [];
    const credits = creditIds.length ? await tx.select({ id: balanceCredits.id }).from(balanceCredits)
      .where(and(eq(balanceCredits.agencyId, agencyId), inArray(balanceCredits.id, creditIds))) : [];
    const withdrawals = withdrawalIds.length ? await tx.select({ id: withdrawalRequests.id, status: withdrawalRequests.status }).from(withdrawalRequests)
      .where(and(eq(withdrawalRequests.agencyId, agencyId), inArray(withdrawalRequests.id, withdrawalIds))).for("update") : [];
    if (notices.length !== noticeIds.length || credits.length !== creditIds.length || withdrawals.length !== withdrawalIds.length) {
      throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy thông báo của đại lý này." });
    }
    const allowed = new Set([
      ...notices.map((row) => `notice-${row.id}`), ...credits.map((row) => `credit-${row.id}`),
      ...withdrawals.map((row) => `withdrawal-${row.id}-${row.status}`),
    ]);
    if (keys.some((key) => !allowed.has(key))) {
      throw new TRPCError({ code: "CONFLICT", message: "Thông báo vừa thay đổi. Vui lòng làm mới danh sách." });
    }
    await tx.insert(agencyNotificationReads).values(keys.map((eventKey) => ({ agencyId, eventKey })))
      .onDuplicateKeyUpdate({ set: { readAt: sql`${agencyNotificationReads.readAt}` } });
    return { markedKeys: keys };
  });
}
