import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { reportsRouter } from "./routers/reports";
import { agentRouter } from "./routers/agent";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
const dialect = new MySqlDialect();
function context(): TrpcContext {
  return { user: { id: 42, openId: "test", email: null, name: "Test", loginMethod: "password", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}
function fakeDb(resultSets: unknown[][]) {
  const queries: Array<{ fields: Record<string, unknown>; filters: SQL[]; joins: SQL[]; grouped: boolean }> = [];
  const db = { select: vi.fn((fields: Record<string, unknown> = {}) => {
    const result = resultSets.shift() ?? [];
    const entry = { fields, filters: [] as SQL[], joins: [] as SQL[], grouped: false };
    queries.push(entry);
    const chain: any = {
      from: () => chain, where: (filter: SQL) => { entry.filters.push(filter); return chain; },
      innerJoin: (_table: unknown, filter: SQL) => { entry.joins.push(filter); return chain; },
      groupBy: () => { entry.grouped = true; return chain; }, orderBy: () => chain, limit: () => chain,
      then: (resolve: (rows: unknown[]) => unknown) => Promise.resolve(result).then(resolve),
    };
    return chain;
  }) };
  mock.getDb.mockResolvedValue(db);
  return queries;
}
const sqlQuery = (query: SQL) => dialect.sqlToQuery(query);
const members = [{ memberId: 1, username: "old01" }, { memberId: 2, username: "new02" }, { memberId: 3, username: "zero03" }];
function fixture(): unknown[][] {
  return [
    [{ id: 8, status: "approved" }], members,
    [{ memberId: 1, total: "1000000" }, { memberId: 2, total: "200000" }],
    [{ memberId: 1, total: "200000" }, { memberId: 2, total: "300000" }],
    [{ memberId: 1, total: "999000", promotionTotal: "5000", refundTotal: "2000" }, { memberId: 2, total: "999000", promotionTotal: "7000", refundTotal: "3000" }],
    [{ memberId: 1, depositDeltaVnd: "-100000", withdrawalDeltaVnd: "25000" }],
  ];
}
beforeEach(() => vi.clearAllMocks());

describe("unified seven-column monthly agency reports", () => {
  it("defaults to the new report and keeps every scoped member, corrections, independent promotion and signed win/loss", async () => {
    const queries = fakeDb(fixture());
    const result = await reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" });
    expect(result).toEqual({ kind: "monthly", month: "2026-10", rows: [
      { memberId: 1, username: "old01", totalDepositVnd: 900000, totalWithdrawalVnd: 225000, promotionVnd: 5000, totalRefundVnd: 2000, totalBetsVnd: 999000, netWinLossVnd: -682000 },
      { memberId: 2, username: "new02", totalDepositVnd: 200000, totalWithdrawalVnd: 300000, promotionVnd: 7000, totalRefundVnd: 3000, totalBetsVnd: 999000, netWinLossVnd: 90000 },
      { memberId: 3, username: "zero03", totalDepositVnd: 0, totalWithdrawalVnd: 0, promotionVnd: 0, totalRefundVnd: 0, totalBetsVnd: 0, netWinLossVnd: 0 },
    ] });
    expect(sqlQuery(queries[0].filters[0]).params).toEqual([42]);
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8]);
    expect(sqlQuery(queries[1].filters[0]).sql).not.toContain("joined_at");
    for (const query of queries.slice(2)) {
      expect(query.joins).toHaveLength(0); expect(query.grouped).toBe(true);
      expect(sqlQuery(query.filters[0]).params).toEqual(expect.arrayContaining([1, 2, 3]));
    }
    const deposit = sqlQuery(queries[2].filters[0]);
    expect(deposit.sql).toContain("`occurred_at` >= ?"); expect(deposit.sql).toContain("`occurred_at` < ?");
    expect(deposit.params.slice(4).map((v: any) => new Date(v).toISOString())).toEqual(["2026-09-30T17:00:00.000Z", "2026-10-31T17:00:00.000Z"]);
    expect(sqlQuery(queries[5].filters[0]).params).toEqual([1, 2, 3, "2026-10"]);
    expect(Object.keys(queries[4].fields).sort()).toEqual(["memberId", "promotionTotal", "refundTotal", "total"]);
  });

  it("uses exact trimmed optional username within the agency and skips empty aggregates", async () => {
    const queries = fakeDb([[{ id: 8, status: "approved" }], []]);
    expect(await reportsRouter.createCaller(context()).agentMonthly({ kind: "monthly", month: "2026-10", username: "  member01  ", cacheKey: 999 })).toEqual({ kind: "monthly", month: "2026-10", rows: [] });
    expect(queries).toHaveLength(2);
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8, "member01"]);
  });

  it("does not restrict all members for a blank username", async () => {
    const queries = fakeDb([[{ id: 8, status: "approved" }], []]);
    await reportsRouter.createCaller(context()).agentMonthly({ month: "2026-12", username: "  " });
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8]);
  });

  it.each(["pending", "locked", "rejected"])("blocks a %s agency before member queries", async (status) => {
    const queries = fakeDb([[{ id: 8, status }]]);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(queries).toHaveLength(1);
  });

  it("requires auth, valid mandatory month and refuses supplied agency scope", async () => {
    await expect(reportsRouter.createCaller({ ...context(), user: null }).agentMonthly({ month: "2026-10" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    for (const input of [{ month: "" }, { month: "2026-13" }, {}, { month: "2026-10", agencyId: 99 }, { month: "2026-10", cacheKey: -1 }]) {
      await expect(reportsRouter.createCaller(context()).agentMonthly(input as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    }
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it.each([2, 3, 4, 5])("rejects unsafe totals from source query %s", async (index) => {
    const rows = fixture();
    rows[index] = index === 4 ? [{ memberId: 1, total: "0", promotionTotal: "9007199254740993" }]
      : index === 5 ? [{ memberId: 1, depositDeltaVnd: "9007199254740993", withdrawalDeltaVnd: "0" }]
      : [{ memberId: 1, total: "9007199254740993" }];
    fakeDb(rows);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it.each([2, 3, 4, 5])("rejects unsafe totals from source query %s", async (index) => {
    const rows = fixture();
    rows[index] = index === 4 ? [{ memberId: 1, total: "0", promotionTotal: "9007199254740993" }]
      : index === 5 ? [{ memberId: 1, depositDeltaVnd: "9007199254740993", withdrawalDeltaVnd: "0" }]
      : [{ memberId: 1, total: "9007199254740993" }];
    fakeDb(rows);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("returns independently updated month wager totals and refuses unsafe stored wagers", async () => {
    const rows = fixture();
    rows[4] = [{ memberId: 1, total: "600000", promotionTotal: "7000" }, { memberId: 2, total: "1234", promotionTotal: "0" }];
    fakeDb(rows);
    const result = await reportsRouter.createCaller(context()).agentMonthly({ month: "2026-11" });
    expect(result.rows[0]).toMatchObject({ totalBetsVnd: 600000, promotionVnd: 7000 });
    expect(result.rows[1]).toMatchObject({ totalBetsVnd: 1234, promotionVnd: 0 });
    const unsafe = fixture();
    unsafe[4] = [{ memberId: 1, total: "9007199254740993", promotionTotal: "0" }];
    fakeDb(unsafe);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("keeps overview deposits and withdrawals as all-member totals even after filtering a report username", async () => {
    const filteredRows = fixture();
    filteredRows[1] = [members[0]];
    const filteredQueries = fakeDb(filteredRows);
    const filtered = await reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10", username: "old01" });
    expect(sqlQuery(filteredQueries[1].filters[0]).params).toEqual([8, "old01"]);
    expect(filtered.rows).toHaveLength(1);

    fakeDb(fixture());
    const all = await reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" });
    if (all.kind !== "monthly" || filtered.kind !== "monthly") throw new Error("Expected unified report");
    const overviewRows = fixture();
    overviewRows[1] = members.map((member) => ({ id: member.memberId, joinedAt: new Date("2026-01-01") }));
    overviewRows.push([]);
    const queries = fakeDb(overviewRows);
    const overview = await agentRouter.createCaller(context()).performance({ month: "2026-10" });
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8]);
    expect(overview.totalDepositVnd).toBe(all.rows.reduce((sum, row) => sum + row.totalDepositVnd, 0));
    expect(overview.totalWithdrawalVnd).toBe(all.rows.reduce((sum, row) => sum + row.totalWithdrawalVnd, 0));
    expect(overview.totalDepositVnd).toBeGreaterThan(filtered.rows[0].totalDepositVnd);
    expect(overview.totalWithdrawalVnd).toBeGreaterThan(filtered.rows[0].totalWithdrawalVnd);
  });

  it("sums monthly 500 + 200 point deposits and independently sums withdrawals and promotions", async () => {
    const rows = fixture();
    rows[1] = members.map((member) => ({ id: member.memberId, joinedAt: new Date("2026-01-01") }));
    rows[2] = [{ memberId: 1, total: String(500 * 1000) }, { memberId: 2, total: String(200 * 1000) }];
    rows[3] = [{ memberId: 1, total: String(120 * 1000) }, { memberId: 2, total: String(80 * 1000) }];
    rows[4] = [{ memberId: 1, total: "0", promotionTotal: String(20 * 1000) }, { memberId: 2, total: "0", promotionTotal: String(10 * 1000) }];
    rows[5] = [];
    rows.push([]);
    fakeDb(rows);
    const result = await agentRouter.createCaller(context()).performance({ month: "2026-10" });
    expect(result.totalDepositVnd).toBe(700 * 1000);
    expect(result.totalWithdrawalVnd).toBe((120 + 80) * 1000);
    expect(result.totalPromotionVnd).toBe((20 + 10) * 1000);
  });

  it("matches performance money to the sum of the unfiltered report for the same month", async () => {
    fakeDb(fixture());
    const report = await reportsRouter.createCaller(context()).agentMonthly({ month: "2026-10" });
    if (report.kind !== "monthly") throw new Error("Expected unified report");
    const rows = fixture();
    rows[1] = members.map((member) => ({ id: member.memberId, joinedAt: new Date("2026-01-01") }));
    rows.push([{ memberId: 1, isValid: 1 }]);
    fakeDb(rows);
    const performance = await agentRouter.createCaller(context()).performance({ month: "2026-10" });
    expect(performance.totalDepositVnd).toBe(report.rows.reduce((sum, row) => sum + row.totalDepositVnd, 0));
    expect(performance.totalWithdrawalVnd).toBe(report.rows.reduce((sum, row) => sum + row.totalWithdrawalVnd, 0));
    expect(performance.totalBetsVnd).toBe(report.rows.reduce((sum, row) => sum + row.totalBetsVnd, 0));
    expect(performance.totalPromotionVnd).toBe(report.rows.reduce((sum, row) => sum + row.promotionVnd, 0));
    expect(performance.totalWinLossVnd).toBe(report.rows.reduce((sum, row) => sum + row.netWinLossVnd, 0));
  });
});
