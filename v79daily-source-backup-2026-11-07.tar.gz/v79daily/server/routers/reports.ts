import { TRPCError } from "@trpc/server";
import { and, eq, gte, isNull, lt, sql, sum } from "drizzle-orm";
import { z } from "zod";
import { agencyProfiles, memberAccounts, memberMonthlyBets, memberTransactions } from "../../drizzle/schema";
import { getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";
import { safeVndTotal } from "../reporting-utils";
import { reportMonthSchema, vietnamMonthBounds } from "../../shared/monthly-report";
import { addExactVnd, getMemberMonthlyReportTotals, getTransactionAdjustments } from "../member-report-totals";

const reportInput = z.object({
  kind: z.enum(["monthly", "transactions", "bets"]).default("monthly"),
  month: reportMonthSchema,
  username: z.string().trim().max(64).optional(),
  cacheKey: z.number().int().positive().optional(),
}).strict();

export const reportsRouter = router({
  agentMonthly: protectedProcedure.input(reportInput).query(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    const [profile] = await db.select({ id: agencyProfiles.id, status: agencyProfiles.status })
      .from(agencyProfiles).where(eq(agencyProfiles.userId, ctx.user.id)).limit(1);
    if (!profile || profile.status !== "approved") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Hồ sơ đại lý chưa được duyệt hoặc đang khóa." });
    }
    const username = input.username?.trim();

    if (input.kind === "monthly") {
      const filters = [eq(memberAccounts.agencyId, profile.id), isNull(memberAccounts.deletedAt)];
      if (username) filters.push(eq(memberAccounts.username, username));
      const members = await db.select({ memberId: memberAccounts.id, username: memberAccounts.username })
        .from(memberAccounts).where(and(...filters)).orderBy(memberAccounts.username);
      const totals = await getMemberMonthlyReportTotals(db, members.map((member) => member.memberId), input.month);
      return {
        kind: "monthly" as const,
        month: input.month,
        rows: members.map((member) => ({
          ...member,
          totalDepositVnd: totals.get(member.memberId)?.totalDepositVnd ?? 0,
          totalWithdrawalVnd: totals.get(member.memberId)?.totalWithdrawalVnd ?? 0,
          promotionVnd: totals.get(member.memberId)?.promotionVnd ?? 0,
          totalRefundVnd: totals.get(member.memberId)?.totalRefundVnd ?? 0,
          totalBetsVnd: totals.get(member.memberId)?.totalBetsVnd ?? 0,
          netWinLossVnd: totals.get(member.memberId)?.netWinLossVnd ?? 0,
        })),
      };
    }

    if (input.kind === "transactions") {
      const { start, end } = vietnamMonthBounds(input.month);
      const filters = [eq(memberAccounts.agencyId, profile.id), isNull(memberAccounts.deletedAt)];
      if (username) filters.push(eq(memberAccounts.username, username));
      const rows = await db.select({
        memberId: memberAccounts.id,
        username: memberAccounts.username,
        totalDepositVnd: sum(sql`CASE WHEN ${memberTransactions.kind} = 'deposit' THEN ${memberTransactions.amountVnd} ELSE 0 END`),
        totalWithdrawalVnd: sum(sql`CASE WHEN ${memberTransactions.kind} = 'withdrawal' THEN ${memberTransactions.amountVnd} ELSE 0 END`),
      }).from(memberAccounts)
        .leftJoin(memberTransactions, and(
          eq(memberTransactions.memberId, memberAccounts.id),
          gte(memberTransactions.occurredAt, start),
          lt(memberTransactions.occurredAt, end),
        ))
        .where(and(...filters))
        .groupBy(memberAccounts.id, memberAccounts.username)
        .orderBy(memberAccounts.username);
      const adjustments = await getTransactionAdjustments(db, rows.map((row) => row.memberId), input.month);
      return {
        kind: "transactions" as const,
        month: input.month,
        rows: rows.map((row) => {
          const totalDepositVnd = addExactVnd(safeVndTotal(row.totalDepositVnd), adjustments.get(row.memberId)?.depositDeltaVnd ?? 0);
          const totalWithdrawalVnd = addExactVnd(safeVndTotal(row.totalWithdrawalVnd), adjustments.get(row.memberId)?.withdrawalDeltaVnd ?? 0);
          return {
            memberId: row.memberId,
            username: row.username,
            totalDepositVnd,
            totalWithdrawalVnd,
            differenceVnd: safeVndTotal(totalDepositVnd - totalWithdrawalVnd),
          };
        }),
      };
    }

    const filters = [eq(memberAccounts.agencyId, profile.id), isNull(memberAccounts.deletedAt), eq(memberMonthlyBets.monthKey, input.month)];
    if (username) filters.push(eq(memberAccounts.username, username));
    const rows = await db.select({
      memberId: memberAccounts.id,
      username: memberAccounts.username,
      amountVnd: memberMonthlyBets.amountVnd,
      validBetVnd: memberMonthlyBets.validBetVnd,
      promotionVnd: memberMonthlyBets.promotionVnd,
      updatedAt: memberMonthlyBets.updatedAt,
    }).from(memberMonthlyBets)
      .innerJoin(memberAccounts, eq(memberMonthlyBets.memberId, memberAccounts.id))
      .where(and(...filters)).orderBy(memberAccounts.username);
    const monthlyTotals = await getMemberMonthlyReportTotals(db, rows.map((row) => row.memberId), input.month);
    return { kind: "bets" as const, month: input.month, rows: rows.map((row) => ({
      ...row,
      amountVnd: safeVndTotal(row.amountVnd),
      validBetVnd: safeVndTotal(row.validBetVnd),
      promotionVnd: safeVndTotal(row.promotionVnd),
      netWinLossVnd: monthlyTotals.get(row.memberId)?.netWinLossVnd ?? 0,
    })) };
  }),
});
