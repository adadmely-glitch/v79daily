import React from "react";

export default function NotificationUnreadBadge({ count }: { count?: number }) {
  if (!Number.isSafeInteger(count) || !count || count < 0) return null;
  return <span className="agent-notification-count" aria-hidden="true">{count > 99 ? "99+" : count}</span>;
}
