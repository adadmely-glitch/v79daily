import { describe, expect, it } from "vitest";
import { filterAdminAgencies } from "../shared/admin-agency-search";

type Agency = {
  id: number;
  username: string;
  fullName: string;
};

const rows: readonly Agency[] = [
  { id: 1, username: "nguyen.an", fullName: "Nguyễn Ánh" },
  { id: 2, username: "tranbinh", fullName: "Trần Bình" },
  { id: 3, username: "do.minh", fullName: "Đỗ Minh" },
  { id: 4, username: "lelan", fullName: "Lê Lan" },
];

describe("filterAdminAgencies", () => {
  it("matches username and full name case-insensitively, preserving source order", () => {
    expect(filterAdminAgencies(rows, "  TRAN  ")).toEqual([rows[1]]);
    expect(filterAdminAgencies(rows, "lan")).toEqual([rows[3]]);

    const matchingRows = [
      rows[2],
      { id: 5, username: "do.other", fullName: "Another Agency" },
      { id: 6, username: "do.final", fullName: "Final Agency" },
    ] as const;
    expect(filterAdminAgencies(matchingRows, "do")).toEqual([
      rows[2],
      matchingRows[1],
      matchingRows[2],
    ]);
  });

  it("folds Vietnamese accents and Đ/đ when matching", () => {
    expect(filterAdminAgencies(rows, "nguyen anh")).toEqual([rows[0]]);
    expect(filterAdminAgencies(rows, "DO MINH")).toEqual([rows[2]]);
    expect(filterAdminAgencies(rows, "đỗ")).toEqual([rows[2]]);
  });

  it("accepts a leading @ for username searches", () => {
    expect(filterAdminAgencies(rows, " @NGUYEN ")).toEqual([rows[0]]);
    expect(filterAdminAgencies(rows, "@do.")).toEqual([rows[2]]);
  });

  it("returns a new copy for an empty query", () => {
    const result = filterAdminAgencies(rows, " \t  ");

    expect(result).toEqual(rows);
    expect(result).not.toBe(rows);
  });

  it("returns an empty array when nothing matches", () => {
    expect(filterAdminAgencies(rows, "not-found")).toEqual([]);
  });

  it("does not mutate input rows or their order", () => {
    const source = rows.slice();
    const snapshot = structuredClone(source);

    expect(filterAdminAgencies(source, "agency")).toEqual([]);
    expect(source).toEqual(snapshot);
    expect(source).toEqual(rows);
  });
});
