import { TRPCError } from "@trpc/server";

/** Reject unsafe aggregates rather than silently rounding financial data. */
export function safeVndTotal(value: string | number | null | undefined): number {
  const result = Number(value ?? 0);
  if (!Number.isSafeInteger(result)) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Tổng tiền vượt phạm vi xử lý chính xác. Vui lòng liên hệ quản trị viên." });
  }
  return result;
}

/** datetime-local values represent Vietnamese civil time, never server local time. */
export function parseVietnamDateTime(value: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) return null;
  const parsed = new Date(`${value}:00+07:00`);
  if (Number.isNaN(parsed.getTime())) return null;
  const civilTime = new Date(parsed.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 16);
  return civilTime === value ? parsed : null;
}
