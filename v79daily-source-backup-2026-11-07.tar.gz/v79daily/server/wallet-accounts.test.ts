import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { walletAddressKey, walletInput } from "../shared/wallet";
import { agentRouter } from "./routers/agent";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
const TRC = "T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb";
const ERC = "0x" + "a".repeat(40);
const dialect = new MySqlDialect();

function context(): TrpcContext {
  return { user: { id: 42, openId: "qa", name: "QA", email: null, role: "user", loginMethod: "password", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { headers: {} } as any, res: {} as any };
}
function fakeDb(results: unknown[][]) {
  const queries: Array<{ fields: Record<string, unknown>; filters: SQL[]; locked: boolean }> = [];
  const inserts: any[] = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const rows = results.shift() ?? [];
      const entry = { fields, filters: [] as SQL[], locked: false }; queries.push(entry);
      const chain: any = { from: () => chain, where: (filter: SQL) => { entry.filters.push(filter); return chain; },
        limit: () => chain, orderBy: () => chain, for: () => { entry.locked = true; return chain; },
        then: (resolve: any) => Promise.resolve(rows).then(resolve) };
      return chain;
    }),
    insert: vi.fn(() => ({ values: (value: unknown) => { inserts.push(value); return { $returningId: async () => [{ id: 999 }], then: (resolve: any) => Promise.resolve(undefined).then(resolve) }; } })),
    transaction: vi.fn(async (fn: any) => fn(db)),
  };
  mock.getDb.mockResolvedValue(db);
  return { db, queries, inserts };
}
beforeEach(() => vi.clearAllMocks());

describe("USDT address validation", () => {
  it("accepts expected TRC20/ERC20 shapes and trims input", () => {
    expect(walletInput.parse({ network: "TRC20", address: ` ${TRC} ` }).address).toBe(TRC);
    expect(walletInput.parse({ network: "ERC20", address: ERC }).address).toBe(ERC);
  });
  it("accepts manually entered addresses without network prefix/length/checksum restrictions", () => {
    for (const value of [{ network: "ERC20", address: TRC }, { network: "TRC20", address: ERC }, { network: "TRC20", address: "T" + "0".repeat(33) }, { network: "ERC20", address: "0x123" }, { network: "TRC20", address: "dia-chi-vi-cua-toi" }]) {
      expect(walletInput.safeParse(value).success).toBe(true);
    }
  });
  it("only requires a nonempty address within storage capacity and a selected supported network", () => {
    expect(walletInput.safeParse({ network: "TRC20", address: "   " }).success).toBe(false);
    expect(walletInput.safeParse({ network: "ERC20", address: "x".repeat(65) }).success).toBe(false);
    expect(walletInput.safeParse({ network: "BEP20", address: "dia-chi-vi" }).success).toBe(false);
  });
  it("does not accept a client-selected agency or a different asset", () => {
    expect(walletInput.safeParse({ network: "ERC20", address: ERC, agencyId: 99 }).success).toBe(false);
    expect(walletInput.safeParse({ network: "ERC20", address: ERC, asset: "BTC" }).success).toBe(false);
  });
  it("keeps free-form UTF-8 keys collision-free and within expanded storage", () => {
    expect(walletAddressKey("TRC20", "😀")).not.toBe(walletAddressKey("TRC20", "😁"));
    expect(walletAddressKey("TRC20", "ệ".repeat(64)).length).toBeLessThanOrEqual(512);
    expect(walletAddressKey("TRC20", "a".repeat(64))).toHaveLength(128);
  });
  it("deduplicates ERC20 case variants but does not merge TRC20 case-sensitive identities", () => {
    expect(walletAddressKey("ERC20", ERC)).toBe(walletAddressKey("ERC20", "0x" + "A".repeat(40)));
    expect(walletAddressKey("TRC20", TRC)).not.toBe(walletAddressKey("TRC20", TRC.toLowerCase()));
    expect(walletAddressKey("ERC20", ERC)).toHaveLength(84);
  });
});

describe("agency USDT wallet API", () => {
  it("blocks guests and tampered agency IDs before database access", async () => {
    await expect(agentRouter.createCaller({ ...context(), user: null }).walletAccounts()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(agentRouter.createCaller(context()).addWalletAccount({ network: "ERC20", address: ERC, agencyId: 99 } as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it.each(["pending", "locked", "rejected"])("blocks a %s agency", async (status) => {
    const { inserts } = fakeDb([[{ id: 8, status }]]);
    await expect(agentRouter.createCaller(context()).addWalletAccount({ network: "ERC20", address: ERC })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(inserts).toHaveLength(0);
  });
  it("lists only this agency and omits the internal duplicate key", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }], []]);
    await agentRouter.createCaller(context()).walletAccounts();
    expect(dialect.sqlToQuery(queries[0].filters[0]).params).toEqual([42]);
    expect(dialect.sqlToQuery(queries[1].filters[0]).params).toEqual([8]);
    expect(Object.keys(queries[1].fields).sort()).toEqual(["address", "asset", "createdAt", "id", "network"]);
  });
  it.each(["TRC20", "ERC20"] as const)("saves a %s wallet only under the locked current agency and masked audit", async (network) => {
    const address = network === "TRC20" ? TRC : ERC;
    const { queries, inserts, db } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], []]);
    expect(await agentRouter.createCaller(context()).addWalletAccount({ network, address })).toEqual({ id: 999 });
    expect(queries[1].locked).toBe(true);
    expect(dialect.sqlToQuery(queries[2].filters[0]).params).toEqual([8, network, walletAddressKey(network, address)]);
    expect(inserts[0]).toMatchObject({ agencyId: 8, asset: "USDT", network, address, addressKey: walletAddressKey(network, address) });
    expect(inserts[1]).toMatchObject({ actorUserId: 42, action: "agency.wallet_account_added", entityId: 999 });
    expect(JSON.parse(inserts[1].details)).toEqual({ agencyId: 8, asset: "USDT", network, addressLast6: address.slice(-6) });
    expect(inserts[1].details).not.toContain(address);
    expect(inserts).toHaveLength(2); expect(db.transaction).toHaveBeenCalledOnce();
  });
  it("rechecks profile status under the row lock before saving", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "locked" }]]);
    await expect(agentRouter.createCaller(context()).addWalletAccount({ network: "ERC20", address: ERC })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(inserts).toHaveLength(0);
  });
  it("rejects a duplicate without creating another wallet or audit", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], [{ id: 99 }]]);
    await expect(agentRouter.createCaller(context()).addWalletAccount({ network: "ERC20", address: ERC })).rejects.toMatchObject({ code: "CONFLICT" });
    expect(inserts).toHaveLength(0);
  });
  it("saves an arbitrary address exactly as entered after trimming, without a prefix rule", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], []]);
    await agentRouter.createCaller(context()).addWalletAccount({ network: "TRC20", address: " dia-chi-vi-cua-toi " });
    expect(inserts[0]).toMatchObject({ address: "dia-chi-vi-cua-toi", addressKey: walletAddressKey("TRC20", "dia-chi-vi-cua-toi") });
  });
});
