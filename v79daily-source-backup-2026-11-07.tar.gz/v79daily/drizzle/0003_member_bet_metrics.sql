ALTER TABLE `member_monthly_bets` ADD `valid_bet_vnd` bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `member_monthly_bets` ADD `net_win_loss_vnd` bigint DEFAULT 0 NOT NULL;