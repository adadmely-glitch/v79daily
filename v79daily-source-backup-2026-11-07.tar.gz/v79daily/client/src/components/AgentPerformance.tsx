import { UsersRound } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { reportMonthSchema } from "@shared/monthly-report";
import AgentActivityChart from "./AgentActivityChart";

type Props = {
  month: string;
  onMonthChange: (month: string) => void;
  cacheKey?: number;
};

export default function AgentPerformance({ month, onMonthChange, cacheKey }: Props) {
  const validMonth = reportMonthSchema.safeParse(month).success;
  const performance = trpc.agent.performance.useQuery({ month, cacheKey }, {
    enabled: validMonth && Boolean(cacheKey),
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });
  const data = validMonth && performance.isSuccess && performance.data.activityMonth === month
    ? performance.data : undefined;
  const metrics = [
    { id: "members", label: "Tổng hội viên", value: data?.memberCount, color: "purple" },
    { id: "valid", label: "Tổng hội viên hợp lệ", value: data?.validMemberCount, color: "gold" },
    { id: "new", label: "Hội viên mới", value: data?.newMemberCount, color: "blue" },
    { id: "newValid", label: "Hội viên mới hợp lệ", value: data?.newValidMemberCount, color: "gold" },
  ];

  return (
    <>
      <section className="agent-metrics-section">
        <div className="agent-section-title">
          <div><span className="agent-eyebrow">TỔNG HỢP DỮ LIỆU</span></div>
          <label className="agent-performance-month">
            <span>Tháng báo cáo</span>
            <input type="month" required aria-label="Tháng hiệu suất đại lý" value={month}
              onChange={(event) => onMonthChange(event.target.value)} />
          </label>
        </div>
        {!validMonth && <p className="agent-performance-feedback" role="status">Chọn tháng để xem hiệu suất.</p>}
        {validMonth && performance.isLoading && <p className="agent-performance-feedback" role="status">Đang tải hiệu suất…</p>}
        {validMonth && performance.isError && <p className="agent-performance-feedback agent-performance-error" role="alert">
          Không thể tải hiệu suất tháng này. <button type="button" onClick={() => void performance.refetch()}>Thử lại</button>
        </p>}
        <div className="agent-metric-grid agent-performance-grid">
          {metrics.map(({ id, label, value, color }) => (
            <article key={id} title={id === "valid" || id === "newValid" ? `Hợp lệ theo đánh dấu của Admin cho tháng ${month}` : id === "members" ? "Tất cả hội viên thuộc đại lý, không phụ thuộc tháng tham gia" : undefined}>
              <span className={`agent-metric-icon metric-${color}`}><UsersRound size={17} /></span><small>{label}</small>
              <b>{typeof value === "number" ? value : "—"}</b>
            </article>
          ))}
        </div>
      </section>
      <AgentActivityChart month={month} data={data} isLoading={validMonth && performance.isLoading} isError={validMonth && performance.isError} />
    </>
  );
}
