import { useId } from "react";
import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ACTIVITY_SERIES, activityChartAxis, createActivityChartRows, formatActivityAxisPoint, getActivityChartColor, type ActivityChartRow, type ActivityTotals } from "@shared/activity-chart";
import { pointMoney } from "@shared/money";
import { reportMonthSchema } from "@shared/monthly-report";

type Props = {
  month: string;
  data?: Partial<ActivityTotals>;
  isLoading: boolean;
  isError: boolean;
};

function ActivityCategoryTick({ x = 0, y = 0, payload }: { x?: number; y?: number; payload?: { value?: string } }) {
  const words = String(payload?.value ?? "").split(" ");
  return <text className="recharts-cartesian-axis-tick-value" x={x} y={y} textAnchor="middle" fill="#64748b" fontSize={10}>
    {words.map((word, index) => <tspan key={index} x={x} dy={12}>{word}{index < words.length - 1 ? " " : ""}</tspan>)}
  </text>;
}

export default function AgentActivityChart({ month, data, isLoading, isError }: Props) {
  const id = useId();
  const validMonth = reportMonthSchema.safeParse(month).success;
  const ready = validMonth && !isError && data && ACTIVITY_SERIES.every((series) => Number.isSafeInteger(data[series.key]));
  const rows = ready ? createActivityChartRows(data as ActivityTotals) : [];
  const axis = activityChartAxis(rows);

  return (
    <section className="agent-panel agent-activity-chart" aria-labelledby={`${id}-title`} aria-busy={isLoading}>
      <div className="agent-chart-heading">
        <h2 id={`${id}-title`}>Nạp · Rút · Cược · Thắng thua · Khuyến mãi · Hoàn trả</h2>
        <span>{validMonth ? `Tháng ${month.slice(5)}/${month.slice(0, 4)}` : "Chưa chọn tháng"} · điểm</span>
      </div>
      {!ready ? <p className="agent-chart-feedback" aria-live="polite">
        {!validMonth ? "Chọn tháng để xem biểu đồ." : isError ? "Chưa tải được biểu đồ tháng này. Thử lại ở phần thống kê phía trên." : isLoading ? "Đang tải biểu đồ…" : "Đang chờ số liệu tháng đã chọn…"}
      </p> : <>
        <div className="agent-chart-canvas">
          <ResponsiveContainer width="100%" height="100%" minWidth={0}>
            <BarChart data={rows} margin={{ top: 18, right: 12, left: 0, bottom: 8 }} accessibilityLayer>
              <CartesianGrid vertical={false} stroke="#e2e8f0" strokeDasharray="3 3" />
              <XAxis dataKey="label" height={42} tickLine={false} axisLine={false} tick={<ActivityCategoryTick />} interval={0} />
              <YAxis type="number" scale="linear" domain={axis.domain} ticks={axis.ticks} tickFormatter={formatActivityAxisPoint}
                width={68} tickLine={false} axisLine={false} tick={{ fill: "#64748b", fontSize: 10 }} interval={0} allowDataOverflow />
              <ReferenceLine y={0} stroke="#64748b" strokeWidth={1.5} />
              <Tooltip cursor={{ fill: "#f1f5f9" }} content={({ active, payload }) => {
                const row = payload?.[0]?.payload as ActivityChartRow | undefined;
                const valueStyle = row?.key === "totalWinLossVnd" ? { color: getActivityChartColor(row) } : undefined;
                return active && row ? <div className="agent-chart-tooltip"><strong>{row.label}</strong><span style={valueStyle}>{pointMoney.format(row.valueVnd)}</span></div> : null;
              }} />
              <Bar dataKey="points" maxBarSize={42} radius={[4, 4, 0, 0]} isAnimationActive={false}>
                {rows.map((row) => <Cell key={row.key} fill={getActivityChartColor(row)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <ul className="agent-chart-legend" aria-label="Tổng số liệu biểu đồ">
          {rows.map((row) => <li key={row.key}><span className="agent-chart-dot" style={{ backgroundColor: getActivityChartColor(row) }} aria-hidden="true" /><span>{row.label}<b style={row.key === "totalWinLossVnd" ? { color: getActivityChartColor(row) } : undefined}>{pointMoney.format(row.valueVnd)}</b></span></li>)}
        </ul>
        <table className="sr-only" aria-label={`Số liệu biểu đồ tháng ${month}`}>
          <thead><tr><th>Chỉ số</th><th>Tổng điểm</th></tr></thead>
          <tbody>{rows.map((row) => <tr key={row.key}><th scope="row">{row.label}</th><td style={row.key === "totalWinLossVnd" ? { color: getActivityChartColor(row) } : undefined}>{pointMoney.format(row.valueVnd)}</td></tr>)}</tbody>
        </table>
        <p className="agent-chart-note agent-chart-sign-note">THẮNG = MÀU XANH , THUA = MÀU ĐỎ</p>
        {axis.expanded && <p className="agent-chart-note">Trục tự mở rộng để hiển thị đầy đủ giá trị, số âm nằm dưới mốc 0.</p>}
      </>}
    </section>
  );
}
