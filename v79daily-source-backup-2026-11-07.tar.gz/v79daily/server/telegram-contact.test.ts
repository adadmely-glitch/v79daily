import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve("client/src/components/TelegramContact.tsx"), "utf8");
const css = readFileSync(resolve("client/src/styles/telegram.css"), "utf8");
const app = readFileSync(resolve("client/src/App.tsx"), "utf8");

describe("Telegram contact", () => {
  it("uses the requested HTTPS link, a new safe tab and accessible label", () => {
    expect(source).toContain('href="https://t.me/dailyv79/"');
    expect(source).toContain('target="_blank"');
    expect(source).toContain('rel="noopener noreferrer"');
    expect(source).toContain('aria-label="Liên hệ V79 Đại lý qua Telegram (mở tab mới)"');
    expect(source).toContain('aria-hidden="true"');
    expect(app.match(/<TelegramContact\s*\/>/g)).toHaveLength(1);
    expect(source).toContain('<img');
    expect(source).toContain('src="/manus-storage/cskh-v79-transparent_7529de06.webp"');
    expect(source).not.toContain('<Send');
  });

  it("anchors bottom-right with safe areas, mobile touch sizing and keyboard focus", () => {
    expect(css).toContain("position: fixed");
    expect(css).toContain("right: calc(24px + env(safe-area-inset-right, 0px))");
    expect(css).toContain("right: calc(16px + env(safe-area-inset-right, 0px))");
    expect(css).not.toContain("safe-area-inset-left");
    expect(css).toContain("bottom: calc(24px + env(safe-area-inset-bottom, 0px))");
    expect(css).toContain("z-index: 40");
    expect(css).toContain("@media (max-width: 640px)");
    expect(css).toContain("width: 108px");
    expect(css).toContain("width: 60px");
    expect(css).toContain("object-fit: contain");
    expect(css).toContain("background: transparent");
    expect(css).toContain("box-shadow: none");
    expect(css).not.toContain("background: #fff");
    expect(css).not.toContain("border-radius: 50%");
    expect(css).toContain("border-radius: 0");
    expect(css).toContain(":focus-visible");
    expect(css).toContain("prefers-reduced-motion");
  });
});
