CREATE TABLE `member_monthly_validity` (
	`id` int AUTO_INCREMENT NOT NULL,
	`member_id` int NOT NULL,
	`month_key` varchar(7) NOT NULL,
	`is_valid` int NOT NULL DEFAULT 0,
	`updated_by` int NOT NULL,
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `member_monthly_validity_id` PRIMARY KEY(`id`),
	CONSTRAINT `member_monthly_validity_uq` UNIQUE(`member_id`,`month_key`)
);
--> statement-breakpoint
ALTER TABLE `member_monthly_validity` ADD CONSTRAINT `member_monthly_validity_member_id_member_accounts_id_fk` FOREIGN KEY (`member_id`) REFERENCES `member_accounts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_monthly_validity` ADD CONSTRAINT `member_monthly_validity_updated_by_users_id_fk` FOREIGN KEY (`updated_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `member_monthly_validity_month_idx` ON `member_monthly_validity` (`month_key`);