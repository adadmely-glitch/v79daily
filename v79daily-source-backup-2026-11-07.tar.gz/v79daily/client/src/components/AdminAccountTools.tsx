import { useEffect, useRef, useState, type FormEvent } from "react";
import { trpc } from "@/lib/trpc";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import "@/styles/admin-account.css";

type AgencyTarget = { id: number; username: string };
export type AgencyOption = { id: number; username: string; fullName: string };

type FormStatus = "idle" | "success" | "warning" | "error";
type PendingNotificationImage = { contentType: "image/png" | "image/jpeg" | "image/webp"; data: string; previewUrl: string; name: string };
const MAX_NOTIFICATION_IMAGE_BYTES = 5 * 1024 * 1024;
const ACCEPTED_NOTIFICATION_IMAGE_TYPES = new Set<PendingNotificationImage["contentType"]>(["image/png", "image/jpeg", "image/webp"]);

const vietnamDateTime = new Intl.DateTimeFormat("vi-VN", {
  timeZone: "Asia/Ho_Chi_Minh",
  dateStyle: "short",
  timeStyle: "short",
});

export function AdminPasswordResetDialog({
  agency,
  onClose,
  onUpdated,
}: {
  agency: AgencyTarget | null;
  onClose: () => void;
  onUpdated: () => Promise<unknown>;
}) {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [reason, setReason] = useState("");
  const [showPasswords, setShowPasswords] = useState(false);
  const [status, setStatus] = useState<FormStatus>("idle");
  const [feedback, setFeedback] = useState("");
  const resetPassword = trpc.account.resetAgencyPassword.useMutation();
  const submitting = useRef(false);
  const [busy, setBusy] = useState(false);
  const lastTargetId = useRef<number | undefined>(agency?.id);

  useEffect(() => {
    if (agency) lastTargetId.current = agency.id;
    setNewPassword("");
    setConfirmPassword("");
    setReason("");
    setShowPasswords(false);
    setStatus("idle");
    setFeedback("");
    resetPassword.reset();
  }, [agency?.id]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting.current) return;
    const trimmedReason = reason.trim();
    if (newPassword.length < 8 || newPassword.length > 128) {
      setStatus("error");
      setFeedback("Mật khẩu mới phải dài từ 8 đến 128 ký tự.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setStatus("error");
      setFeedback("Mật khẩu nhập lại không khớp.");
      return;
    }
    if (trimmedReason.length < 3 || trimmedReason.length > 500) {
      setStatus("error");
      setFeedback("Lý do phải dài từ 3 đến 500 ký tự.");
      return;
    }
    if (!agency) return;
    if (!window.confirm(`Xác nhận đổi mật khẩu cho @${agency.username}? Thao tác sẽ thu hồi toàn bộ phiên đăng nhập cũ của đại lý và không tự mở khóa hồ sơ.`)) return;

    submitting.current = true;
    setBusy(true);
    setStatus("idle");
    setFeedback("");
    try {
      await resetPassword.mutateAsync({
        agencyId: agency.id,
        newPassword,
        confirmPassword,
        reason: trimmedReason,
      });
      setNewPassword("");
      setConfirmPassword("");
      setReason("");
      setShowPasswords(false);
      setStatus("success");
      setFeedback(`Đã đặt mật khẩu mới cho @${agency.username}. Các phiên cũ đã được thu hồi.`);
      await onUpdated().catch(() => undefined);
    } catch (error) {
      setStatus("error");
      setFeedback(error instanceof Error ? error.message : "Không thể đặt lại mật khẩu lúc này.");
    } finally {
      submitting.current = false;
      setBusy(false);
    }
  }

  return (
    <Dialog open={Boolean(agency)} onOpenChange={(open) => { if (!open && !busy) onClose(); }}>
      {agency && <DialogContent className="admin-account-dialog" showCloseButton={false} onCloseAutoFocus={(event) => {
        event.preventDefault(); document.getElementById(`admin-reset-password-${lastTargetId.current}`)?.focus();
      }}>
        <DialogHeader>
          <DialogTitle>Đổi mật khẩu đại lý</DialogTitle>
          <DialogDescription>
            Đang thao tác với <strong>@{agency.username}</strong>. Mật khẩu mới sẽ thu hồi toàn bộ phiên cũ; hồ sơ bị khóa sẽ không tự mở khóa.
          </DialogDescription>
        </DialogHeader>
        <form className="admin-account-form" onSubmit={submit}>
          <label>
            <span>Mật khẩu mới</span>
            <input type={showPasswords ? "text" : "password"} autoComplete="new-password" minLength={8} maxLength={128} required disabled={busy} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} />
          </label>
          <label>
            <span>Nhập lại mật khẩu mới</span>
            <input type={showPasswords ? "text" : "password"} autoComplete="new-password" minLength={8} maxLength={128} required disabled={busy} value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} />
          </label>
          <label>
            <span>Lý do thay đổi</span>
            <textarea minLength={3} maxLength={500} required disabled={busy} value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Ví dụ: Đại lý quên mật khẩu (không ghi mật khẩu tại đây)" />
          </label>
          <label className="admin-account-checkbox"><input type="checkbox" disabled={busy} checked={showPasswords} onChange={(event) => setShowPasswords(event.target.checked)} /> <span>Hiển thị mật khẩu đang nhập</span></label>
          {status === "success" && <p className="admin-account-success" role="status">{feedback}</p>}
          {status === "error" && <p className="admin-account-error" role="alert">{feedback}</p>}
          <DialogFooter className="admin-account-dialog-footer">
            <button type="button" className="admin-account-secondary" onClick={onClose} disabled={busy}>{status === "success" ? "Đóng" : "Hủy"}</button>
            <button type="submit" className="admin-account-primary" disabled={busy}>{busy ? "Đang lưu…" : "Đặt mật khẩu mới"}</button>
          </DialogFooter>
        </form>
      </DialogContent>}
    </Dialog>
  );
}

function AdminNotificationImageView({ id, title }: { id: number; title: string }) {
  const [expanded, setExpanded] = useState(false);
  const image = trpc.account.adminNotificationImage.useQuery({ id }, { enabled: expanded, retry: false });
  return <div className="admin-notification-image-view">
    <button type="button" className="admin-account-secondary" onClick={() => setExpanded((value) => !value)}>
      {expanded ? "Ẩn ảnh" : "Xem ảnh"}
    </button>
    {expanded && image.isFetching && <span role="status">Đang tải ảnh…</span>}
    {expanded && image.isError && <span className="admin-account-error" role="alert">Không tải được ảnh. <button type="button" onClick={() => void image.refetch()}>Thử lại</button></span>}
    {expanded && image.data?.id === id && <img src={`data:${image.data.contentType};base64,${image.data.data}`} alt={`Ảnh thông báo: ${title}`} loading="lazy" />}
  </div>;
}

export function AdminNotifications({
  agencies,
  onUpdated,
}: {
  agencies: AgencyOption[];
  onUpdated: () => Promise<unknown>;
}) {
  const utils = trpc.useUtils();
  const sentNotifications = trpc.account.sentNotifications.useQuery(undefined);
  const sendNotification = trpc.account.sendNotification.useMutation();
  const [recipientValue, setRecipientValue] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [status, setStatus] = useState<FormStatus>("idle");
  const [feedback, setFeedback] = useState("");
  const submitting = useRef(false);
  const [busy, setBusy] = useState(false);
  const [image, setImage] = useState<PendingNotificationImage | null>(null);
  const imageInput = useRef<HTMLInputElement>(null);

  useEffect(() => () => { if (image) URL.revokeObjectURL(image.previewUrl); }, [image]);

  function removeImage() {
    setImage(null);
    if (imageInput.current) imageInput.current.value = "";
  }

  function chooseImage(file: File | undefined) {
    if (!file) return;
    if (!ACCEPTED_NOTIFICATION_IMAGE_TYPES.has(file.type as PendingNotificationImage["contentType"]) || file.size > MAX_NOTIFICATION_IMAGE_BYTES) {
      setStatus("error");
      setFeedback("Ảnh phải là PNG, JPEG hoặc WebP và không vượt quá 5 MiB.");
      if (imageInput.current) imageInput.current.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === "string" ? reader.result : "";
      const data = result.split(",", 2)[1] ?? "";
      if (!data) {
        setStatus("error"); setFeedback("Không thể đọc ảnh đã chọn."); return;
      }
      setImage({ contentType: file.type as PendingNotificationImage["contentType"], data, previewUrl: URL.createObjectURL(file), name: file.name });
      setStatus("idle"); setFeedback("");
    };
    reader.onerror = () => { setStatus("error"); setFeedback("Không thể đọc ảnh đã chọn."); };
    reader.readAsDataURL(file);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting.current) return;
    const trimmedTitle = title.trim();
    const trimmedBody = body.trim();
    if (trimmedTitle.length < 3 || trimmedTitle.length > 160) {
      setStatus("error");
      setFeedback("Tiêu đề phải dài từ 3 đến 160 ký tự.");
      return;
    }
    if (trimmedBody.length < 1 || trimmedBody.length > 4000) {
      setStatus("error");
      setFeedback("Nội dung phải dài từ 1 đến 4.000 ký tự.");
      return;
    }
    if (!recipientValue) {
      setStatus("error");
      setFeedback("Chọn đại lý nhận thông báo.");
      return;
    }

    const agencyId = recipientValue === "all" ? null : Number(recipientValue);
    const recipient = agencyId === null ? null : agencies.find((item) => item.id === agencyId);
    if (agencyId !== null && !recipient) {
      setStatus("error");
      setFeedback("Đại lý nhận thông báo không hợp lệ.");
      return;
    }
    const scope = recipient ? `@${recipient.username} (${recipient.fullName})` : "toàn bộ đại lý";
    const attachment = image ? `\nẢnh đính kèm: ${image.name}\nẢnh sẽ được tải lên khi bạn xác nhận gửi.` : "";
    if (!window.confirm(`Xác nhận gửi thông báo?\nPhạm vi: ${scope}\nTiêu đề: ${trimmedTitle}\nNội dung:\n${trimmedBody}${attachment}`)) return;

    submitting.current = true;
    setBusy(true);
    setStatus("idle");
    setFeedback("");
    try {
      const result = await sendNotification.mutateAsync({ agencyId, title: trimmedTitle, body: trimmedBody, image: image ? { contentType: image.contentType, data: image.data } : undefined });
      setRecipientValue("");
      setTitle("");
      setBody("");
      removeImage();
      setStatus(result.imageStored ? "success" : "warning");
      setFeedback(result.imageStored ? "Đã gửi thông báo." : "Thông báo đã lưu nhưng chưa xác nhận được ảnh tải lên. Không gửi lại để tránh tạo thông báo trùng; hãy mở “Xem ảnh” trong lịch sử để thử tải ảnh.");
      await Promise.all([
        utils.account.sentNotifications.invalidate(),
        utils.admin.audit.invalidate(),
        onUpdated(),
      ]).catch(() => undefined);
    } catch (error) {
      setStatus("error");
      setFeedback(error instanceof Error ? error.message : "Không thể gửi thông báo lúc này.");
    } finally {
      submitting.current = false;
      setBusy(false);
    }
  }

  const rows = [...(sentNotifications.data ?? [])].sort((left, right) => right.createdAt.getTime() - left.createdAt.getTime());

  return <section className="admin-account-notifications">
    <div className="admin-card-head">
      <div><h2>Thông báo đại lý</h2><p>Gửi thông báo riêng cho một đại lý hoặc cùng lúc cho toàn bộ đại lý.</p></div>
    </div>
    <form className="admin-notification-form" onSubmit={submit}>
      <label><span>Người nhận</span><select disabled={busy} value={recipientValue} onChange={(event) => setRecipientValue(event.target.value)}><option value="">Chọn đại lý</option><option value="all">Tất cả đại lý</option>{agencies.map((agency) => <option key={agency.id} value={agency.id}>@{agency.username} · {agency.fullName}</option>)}</select></label>
      <label><span>Tiêu đề</span><input minLength={3} maxLength={160} required disabled={busy} value={title} onChange={(event) => setTitle(event.target.value)} /></label>
      <label><span>Nội dung</span><textarea minLength={1} maxLength={4000} required disabled={busy} value={body} onChange={(event) => setBody(event.target.value)} /></label>
      <div className="admin-notification-image-picker">
        <input ref={imageInput} className="admin-notification-file-input" type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={(event) => chooseImage(event.target.files?.[0])} />
        <button type="button" className="admin-account-secondary" disabled={busy} onClick={() => imageInput.current?.click()}>Chọn ảnh để tải lên</button>
        <span className="admin-notification-upload-hint">PNG, JPEG hoặc WebP · tối đa 5 MiB. Ảnh chỉ tải lên khi gửi.</span>
        {image && <div className="admin-notification-image-preview"><img src={image.previewUrl} alt={`Xem trước ${image.name}`} /><div><span>{image.name}</span><button type="button" className="admin-notification-remove-image" disabled={busy} onClick={removeImage}>Bỏ ảnh</button></div></div>}
      </div>
      <div className="admin-notification-actions"><button type="submit" className="admin-account-primary" disabled={busy}>{busy ? "Đang gửi…" : "Gửi thông báo"}</button>{status === "success" && <span className="admin-account-success" role="status">{feedback}</span>}{status === "warning" && <span className="admin-account-warning" role="status">{feedback}</span>}{status === "error" && <span className="admin-account-error" role="alert">{feedback}</span>}</div>
    </form>
    <div className="admin-sent-notifications">
      <div className="admin-sent-notifications-head"><h3>Thông báo đã gửi</h3><button type="button" className="admin-account-secondary" onClick={() => void sentNotifications.refetch()} disabled={sentNotifications.isFetching}>Thử lại</button></div>
      {sentNotifications.isLoading && <p className="admin-account-muted">Đang tải lịch sử thông báo…</p>}
      {sentNotifications.isError && <div className="admin-account-error" role="alert">Không tải được lịch sử thông báo. <button type="button" onClick={() => void sentNotifications.refetch()}>Thử lại</button></div>}
      {!sentNotifications.isLoading && !sentNotifications.isError && !rows.length && <p className="admin-account-muted">Chưa có thông báo nào.</p>}
      {!sentNotifications.isLoading && !sentNotifications.isError && rows.length > 0 && <div className="admin-table-wrap"><table className="admin-table admin-notification-table"><thead><tr><th>Người nhận</th><th>Tiêu đề</th><th>Nội dung</th><th>Ảnh</th><th>Thời gian</th><th>Người gửi</th></tr></thead><tbody>{rows.map((row) => <tr key={row.id}><td>{row.agencyId === null ? "Tất cả đại lý" : row.agencyUsername ? `@${row.agencyUsername}` : `Đại lý #${row.agencyId}`}</td><td><b>{row.title}</b></td><td className="admin-notification-body">{row.body}</td><td className="admin-notification-image-cell">{row.imageAvailable ? <AdminNotificationImageView id={row.id} title={row.title} /> : "—"}</td><td>{vietnamDateTime.format(row.createdAt)}</td><td>{row.senderName || "—"}</td></tr>)}</tbody></table></div>}
    </div>
  </section>;
}
