import { bigint, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const agencyProfiles = mysqlTable("agency_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  username: varchar("username", { length: 48 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull(),
  fullName: varchar("full_name", { length: 200 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "locked"]).default("pending").notNull(),
  referralLink: varchar("referral_link", { length: 2048 }),
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: int("reviewed_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdUnique: uniqueIndex("agency_profiles_user_id_uq").on(table.userId),
  usernameUnique: uniqueIndex("agency_profiles_username_uq").on(table.username),
  statusIndex: index("agency_profiles_status_idx").on(table.status),
}));

export const agencyCredentials = mysqlTable("agency_credentials", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "cascade" }),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  passwordVersion: int("password_version").default(0).notNull(),
  failedAttempts: int("failed_attempts").default(0).notNull(),
  loginBlockedUntil: timestamp("login_blocked_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  agencyUnique: uniqueIndex("agency_credentials_agency_uq").on(table.agencyId),
}));

export const bankAccounts = mysqlTable("bank_accounts", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "cascade" }),
  ownerName: varchar("owner_name", { length: 200 }).notNull(),
  accountNumber: varchar("account_number", { length: 64 }).notNull(),
  bankName: varchar("bank_name", { length: 120 }).notNull(),
  branch: varchar("branch", { length: 200 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  agencyIndex: index("bank_accounts_agency_idx").on(table.agencyId),
}));

export const walletAccounts = mysqlTable("wallet_accounts", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "cascade" }),
  asset: mysqlEnum("asset", ["USDT"]).notNull().default("USDT"),
  network: mysqlEnum("network", ["TRC20", "ERC20"]).notNull(),
  address: varchar("address", { length: 64 }).notNull(),
  addressKey: varchar("address_key", { length: 512 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  agencyIndex: index("wallet_accounts_agency_idx").on(table.agencyId, table.createdAt),
  walletUnique: uniqueIndex("wallet_accounts_agency_network_address_uq").on(table.agencyId, table.network, table.addressKey),
}));

export const withdrawalRequests = mysqlTable("withdrawal_requests", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "restrict" }),
  bankAccountId: int("bank_account_id").references(() => bankAccounts.id, { onDelete: "restrict" }),
  destinationType: mysqlEnum("destination_type", ["bank", "usdt"]).default("bank").notNull(),
  walletAccountId: int("wallet_account_id").references(() => walletAccounts.id, { onDelete: "restrict" }),
  walletNetwork: mysqlEnum("wallet_network", ["TRC20", "ERC20"]),
  walletAddress: varchar("wallet_address", { length: 64 }),
  ownerName: varchar("owner_name", { length: 200 }).notNull(),
  accountNumber: varchar("account_number", { length: 64 }).notNull(),
  bankName: varchar("bank_name", { length: 120 }).notNull(),
  branch: varchar("branch", { length: 200 }).notNull(),
  amountVnd: bigint("amount_vnd", { mode: "number" }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: int("reviewed_by").references(() => users.id, { onDelete: "set null" }),
  decisionNote: varchar("decision_note", { length: 500 }),
}, (table) => ({
  agencyIndex: index("withdrawals_agency_idx").on(table.agencyId, table.requestedAt),
  statusIndex: index("withdrawals_status_idx").on(table.status, table.requestedAt),
}));

export const balanceCredits = mysqlTable("balance_credits", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "restrict" }),
  amountVnd: bigint("amount_vnd", { mode: "number" }).notNull(),
  reason: varchar("reason", { length: 500 }).notNull(),
  createdBy: int("created_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  agencyIndex: index("balance_credits_agency_idx").on(table.agencyId, table.createdAt),
}));

export const memberAccounts = mysqlTable("member_accounts", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "cascade" }),
  username: varchar("username", { length: 64 }).notNull(),
  fullName: varchar("full_name", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  isValid: int("is_valid").notNull().default(0),
  deletedAt: timestamp("deleted_at"),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  createdBy: int("created_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  agencyUsernameUnique: uniqueIndex("member_agency_username_uq").on(table.agencyId, table.username),
  agencyDeletedIndex: index("member_agency_deleted_idx").on(table.agencyId, table.deletedAt),
  agencyJoinedIndex: index("member_agency_joined_idx").on(table.agencyId, table.joinedAt),
}));

export const memberMonthlyValidity = mysqlTable("member_monthly_validity", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("member_id").notNull().references(() => memberAccounts.id, { onDelete: "cascade" }),
  monthKey: varchar("month_key", { length: 7 }).notNull(),
  isValid: int("is_valid").notNull().default(0),
  updatedBy: int("updated_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  memberMonthUnique: uniqueIndex("member_monthly_validity_uq").on(table.memberId, table.monthKey),
  monthIndex: index("member_monthly_validity_month_idx").on(table.monthKey),
}));

export const memberTransactions = mysqlTable("member_transactions", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("member_id").notNull().references(() => memberAccounts.id, { onDelete: "restrict" }),
  kind: mysqlEnum("kind", ["deposit", "withdrawal"]).notNull(),
  amountVnd: bigint("amount_vnd", { mode: "number" }).notNull(),
  occurredAt: timestamp("occurred_at").notNull(),
  note: varchar("note", { length: 500 }),
  createdBy: int("created_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  memberDateIndex: index("member_transactions_member_date_idx").on(table.memberId, table.occurredAt),
  kindDateIndex: index("member_transactions_kind_date_idx").on(table.kind, table.occurredAt),
}));

export const memberMonthlyBets = mysqlTable("member_monthly_bets", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("member_id").notNull().references(() => memberAccounts.id, { onDelete: "cascade" }),
  monthKey: varchar("month_key", { length: 7 }).notNull(),
  amountVnd: bigint("amount_vnd", { mode: "number" }).notNull(),
  validBetVnd: bigint("valid_bet_vnd", { mode: "number" }).notNull().default(0),
  promotionVnd: bigint("promotion_vnd", { mode: "number" }).notNull().default(0),
  refundVnd: bigint("refund_vnd", { mode: "number" }).notNull().default(0),
  netWinLossVnd: bigint("net_win_loss_vnd", { mode: "number" }).notNull().default(0),
  updatedBy: int("updated_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  memberMonthUnique: uniqueIndex("member_monthly_bet_uq").on(table.memberId, table.monthKey),
  monthIndex: index("member_monthly_bet_month_idx").on(table.monthKey),
}));

export const memberReportAdjustments = mysqlTable("member_report_adjustments", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("member_id").notNull().references(() => memberAccounts.id, { onDelete: "restrict" }),
  monthKey: varchar("month_key", { length: 7 }).notNull(),
  depositDeltaVnd: bigint("deposit_delta_vnd", { mode: "number" }).notNull(),
  withdrawalDeltaVnd: bigint("withdrawal_delta_vnd", { mode: "number" }).notNull(),
  reason: varchar("reason", { length: 500 }).notNull(),
  createdBy: int("created_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  memberMonthIndex: index("member_report_adjustments_member_month_idx").on(table.memberId, table.monthKey),
  monthIndex: index("member_report_adjustments_month_idx").on(table.monthKey),
}));

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actor_user_id").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entity_type", { length: 80 }).notNull(),
  entityId: int("entity_id"),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  entityIndex: index("audit_entity_idx").on(table.entityType, table.entityId, table.createdAt),
  actorIndex: index("audit_actor_idx").on(table.actorUserId, table.createdAt),
}));

export const agencyNotifications = mysqlTable("agency_notifications", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").references(() => agencyProfiles.id, { onDelete: "restrict" }),
  title: varchar("title", { length: 160 }).notNull(),
  body: text("body").notNull(),
  imageKey: varchar("image_key", { length: 255 }),
  createdBy: int("created_by").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  agencyDateIndex: index("agency_notifications_agency_date_idx").on(table.agencyId, table.createdAt),
  createdIndex: index("agency_notifications_created_idx").on(table.createdAt),
}));

export const agencyNotificationReads = mysqlTable("agency_notification_reads", {
  id: int("id").autoincrement().primaryKey(),
  agencyId: int("agency_id").notNull().references(() => agencyProfiles.id, { onDelete: "cascade" }),
  eventKey: varchar("event_key", { length: 80 }).notNull(),
  readAt: timestamp("read_at").defaultNow().notNull(),
}, (table) => ({
  agencyEventUnique: uniqueIndex("agency_notification_reads_agency_event_uq").on(table.agencyId, table.eventKey),
}));
