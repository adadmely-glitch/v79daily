CREATE TABLE `agency_credentials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`password_hash` varchar(255) NOT NULL,
	`failed_attempts` int NOT NULL DEFAULT 0,
	`login_blocked_until` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agency_credentials_id` PRIMARY KEY(`id`),
	CONSTRAINT `agency_credentials_agency_uq` UNIQUE(`agency_id`)
);
--> statement-breakpoint
ALTER TABLE `agency_credentials` ADD CONSTRAINT `agency_credentials_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE cascade ON UPDATE no action;