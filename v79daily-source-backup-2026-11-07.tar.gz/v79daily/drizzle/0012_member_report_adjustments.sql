CREATE TABLE `member_report_adjustments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`member_id` int NOT NULL,
	`month_key` varchar(7) NOT NULL,
	`deposit_delta_vnd` bigint NOT NULL,
	`withdrawal_delta_vnd` bigint NOT NULL,
	`reason` varchar(500) NOT NULL,
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `member_report_adjustments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `member_report_adjustments` ADD CONSTRAINT `member_report_adjustments_member_id_member_accounts_id_fk` FOREIGN KEY (`member_id`) REFERENCES `member_accounts`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_report_adjustments` ADD CONSTRAINT `member_report_adjustments_created_by_users_id_fk` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `member_report_adjustments_member_month_idx` ON `member_report_adjustments` (`member_id`,`month_key`);--> statement-breakpoint
CREATE INDEX `member_report_adjustments_month_idx` ON `member_report_adjustments` (`month_key`);