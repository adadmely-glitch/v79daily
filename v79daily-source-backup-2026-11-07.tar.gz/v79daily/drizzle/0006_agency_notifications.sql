CREATE TABLE `agency_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int,
	`title` varchar(160) NOT NULL,
	`body` text NOT NULL,
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `agency_notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `agency_notifications` ADD CONSTRAINT `agency_notifications_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `agency_notifications` ADD CONSTRAINT `agency_notifications_created_by_users_id_fk` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `agency_notifications_agency_date_idx` ON `agency_notifications` (`agency_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `agency_notifications_created_idx` ON `agency_notifications` (`created_at`);