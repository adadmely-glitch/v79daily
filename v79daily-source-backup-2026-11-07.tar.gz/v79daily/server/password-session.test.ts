import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { Request } from "express";
import { sdk } from "./_core/sdk";
import { COOKIE_NAME } from "../shared/const";

const mock = vi.hoisted(() => ({ getUserByOpenId: vi.fn(), getAgencyPasswordVersion: vi.fn(), upsertUser: vi.fn() }));
vi.mock("./db", () => mock);
const user = { id: 42, openId: "agency-unit", name: "Unit", email: null, role: "user" as const, loginMethod: "password", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
beforeEach(() => {
  vi.clearAllMocks();
  vi.stubEnv("MANUS_PROJECT_ID", "session-unit-project");
  vi.stubEnv("MANUS_JWT_SECRET", "unit-session-key-not-deployed");
  mock.getUserByOpenId.mockResolvedValue(user);
  mock.getAgencyPasswordVersion.mockResolvedValue(0);
  mock.upsertUser.mockResolvedValue(undefined);
});
afterEach(() => vi.unstubAllEnvs());
function request(token: string) { return { headers: { cookie: `${COOKIE_NAME}=${token}` }, path: "/api/trpc/account.notifications" } as Request; }
async function token(version?: number) { return sdk.createSessionToken("agency-unit", { name: "Unit", expiresInMs: 60000, passwordVersion: version }); }

describe("password session version enforcement", () => {
  it("keeps legacy tokens valid at version0 without resetting anyone's password", async () => {
    const session = await token();
    expect((await sdk.verifySession(session))?.passwordVersion).toBeUndefined();
    expect(await sdk.authenticateRequest(request(session))).toEqual(user);
    expect(mock.getAgencyPasswordVersion).toHaveBeenCalledWith(42);
  });
  it("accepts the newly issued password session for the current version", async () => {
    mock.getAgencyPasswordVersion.mockResolvedValue(3);
    const session = await token(3);
    expect(await sdk.verifySession(session)).toMatchObject({ passwordVersion: 3 });
    expect(await sdk.authenticateRequest(request(session))).toEqual(user);
  });
  it.each([undefined, 0, 1, 2])("rejects a stale version %s after credentials reach version3", async (version) => {
    mock.getAgencyPasswordVersion.mockResolvedValue(3);
    await expect(sdk.authenticateRequest(request(await token(version)))).rejects.toThrow("Password session has been revoked");
    expect(mock.upsertUser).not.toHaveBeenCalled();
  });
  it("rejects a removed/missing credential record", async () => {
    mock.getAgencyPasswordVersion.mockResolvedValue(null);
    await expect(sdk.authenticateRequest(request(await token()))).rejects.toThrow("Password session has been revoked");
  });
  it("does not apply password version checks to a Manus OAuth admin", async () => {
    const admin = { ...user, role: "admin", loginMethod: "google" };
    mock.getUserByOpenId.mockResolvedValue(admin);
    expect(await sdk.authenticateRequest(request(await token()))).toEqual(admin);
    expect(mock.getAgencyPasswordVersion).not.toHaveBeenCalled();
  });
  it.each([-1, 0.5, 2147483648])("rejects an invalid signed credential version %s", async (version) => {
    expect(await sdk.verifySession(await token(version))).toBeNull();
  });
});
