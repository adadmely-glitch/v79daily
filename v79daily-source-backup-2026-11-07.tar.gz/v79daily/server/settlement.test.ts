import { describe, expect, it } from "vitest";
import { currentVietnamMonth, getSettlementCountdown, SETTLEMENT_DEADLINE } from "../shared/settlement";

describe("November settlement countdown", () => {
  it("ends at midnight December 1 in Vietnam", () => {
    expect(new Date(SETTLEMENT_DEADLINE).toISOString()).toBe("2026-11-30T17:00:00.000Z");
  });
  it("continues through the last second of November", () => {
    expect(getSettlementCountdown(SETTLEMENT_DEADLINE - 1_000)).toBe("0 ngày 00:00:01");
    expect(getSettlementCountdown(SETTLEMENT_DEADLINE - 86_400_000)).toBe("1 ngày 00:00:00");
  });
  it("never displays a negative countdown after the deadline", () => {
    expect(getSettlementCountdown(SETTLEMENT_DEADLINE)).toBe("0 ngày 00:00:00");
    expect(getSettlementCountdown(SETTLEMENT_DEADLINE + 86_400_000)).toBe("0 ngày 00:00:00");
  });
  it("uses the Vietnam month instead of the UTC month at the boundary", () => {
    expect(currentVietnamMonth(new Date("2026-10-31T17:00:00Z"))).toBe("2026-11");
    expect(currentVietnamMonth(new Date("2026-10-31T16:59:59Z"))).toBe("2026-10");
  });
});
