const iconSources = {
  bank: "/manus-storage/pasted_file_BIhiJG_image_6d7e6689.png",
  usdt: "/manus-storage/pasted_file_g5JC4P_image_d482bddf.png",
  withdrawal: "/manus-storage/pasted_file_zBwZSb_image_dbaf2fbb.png",
} as const;

export default function PayoutIcon({ type, size = 34 }: { type: keyof typeof iconSources; size?: number }) {
  return <img className={`payout-icon payout-icon-${type}`} src={iconSources[type]} alt="" aria-hidden="true" width={size} height={size} style={{ width: size, height: size, objectFit: "contain", flex: "0 0 auto" }} />;
}
