import { afterEach, describe, expect, it, vi } from "vitest";

const mock = vi.hoisted(() => ({ env: { forgeApiUrl: "https://forge.invalid", forgeApiKey: "unit-secret" } }));
vi.mock("./_core/env", () => ({ ENV: mock.env }));

import { storageCreateKey, storageGetSignedUrl, storagePutAtKey } from "./storage";

const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);

afterEach(() => vi.unstubAllGlobals());

describe("storage object helpers", () => {
  it("generates non-colliding keys with the required suffix pattern", () => {
    const first = storageCreateKey("agency-notifications/550e8400-e29b-41d4-a716-446655440000.png");
    const second = storageCreateKey("agency-notifications/550e8400-e29b-41d4-a716-446655440000.png");
    expect(first).toMatch(/^agency-notifications\/550e8400-e29b-41d4-a716-446655440000_[0-9a-f]{8}\.png$/);
    expect(second).not.toBe(first);
  });

  it("uploads at an already-indexed key without opening or changing it", async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({ url: "https://upload.invalid/presigned" }), { status: 200 }))
      .mockResolvedValueOnce(new Response(null, { status: 200 }));
    vi.stubGlobal("fetch", fetcher);
    const key = "agency-notifications/550e8400-e29b-41d4-a716-446655440000_abc12345.png";
    const result = await storagePutAtKey(key, png, "image/png");
    expect(result).toEqual({ key, url: `/manus-storage/${key}` });
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(fetcher.mock.calls[0]?.[0]).toBeInstanceOf(URL);
    expect(String(fetcher.mock.calls[0]?.[0])).toContain("/v1/storage/presign/put?path=");
    expect(fetcher.mock.calls[0]?.[1]).toMatchObject({ headers: { Authorization: "Bearer unit-secret" }, signal: expect.any(AbortSignal) });
    expect(fetcher.mock.calls[1]?.[0]).toBe("https://upload.invalid/presigned");
    expect(fetcher.mock.calls[1]?.[1]).toMatchObject({ method: "PUT", headers: { "Content-Type": "image/png" }, signal: expect.any(AbortSignal) });
  });

  it("uses a timeout for signed-URL retrieval and rejects unsafe keys before any request", async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response(JSON.stringify({ url: "https://signed.invalid/object" }), { status: 200 }));
    vi.stubGlobal("fetch", fetcher);
    const key = "agency-notifications/550e8400-e29b-41d4-a716-446655440000_abc12345.png";
    await expect(storageGetSignedUrl(key)).resolves.toBe("https://signed.invalid/object");
    expect(fetcher).toHaveBeenCalledWith(expect.any(URL), expect.objectContaining({ headers: { Authorization: "Bearer unit-secret" }, signal: expect.any(AbortSignal) }));
    await expect(storageGetSignedUrl("agency-notifications/../../other.png")).rejects.toThrow("Invalid storage key");
    expect(fetcher).toHaveBeenCalledTimes(1);
  });
});
