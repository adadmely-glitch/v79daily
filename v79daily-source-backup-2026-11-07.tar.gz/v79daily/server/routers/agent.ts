import { TRPCError } from "@trpc/server";
import { and, count, desc, eq, gte, inArray, isNull, like, lt, sum } from "drizzle-orm";
import { z } from "zod";
import { agencyProfiles, auditLogs, balanceCredits, bankAccounts, memberAccounts, walletAccounts, withdrawalRequests } from "../../drizzle/schema";
import { getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";
import { safeVndTotal } from "../reporting-utils";
import { walletAddressKey, walletInput } from "../../shared/wallet";
import { reportMonthSchema, vietnamMonthBounds } from "../../shared/monthly-report";
import { addExactVnd, getMemberMonthlyReportTotals } from "../member-report-totals";
import { getMemberMonthValidity } from "../member-month-validity";
import { withdrawalMinimumMessage, withdrawalMinimumVnd } from "../../shared/withdrawal-limits";

async function getApprovedProfile(userId: number) {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
  const [profile] = await db.select().from(agencyProfiles).where(eq(agencyProfiles.userId, userId)).limit(1);
  if (!profile || profile.status !== "approved") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Hồ sơ đại lý chưa được duyệt hoặc đang khóa." });
  }
  return { db, profile };
}

const bankInput = z.object({
  ownerName: z.string().trim().min(2).max(200),
  accountNumber: z.string().trim().min(4).max(64),
  bankName: z.string().trim().min(2).max(120),
  branch: z.string().trim().min(2).max(200),
});

export const agentRouter = router({
  overview: protectedProcedure.query(async ({ ctx }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    const [creditRow] = await db.select({ total: sum(balanceCredits.amountVnd) }).from(balanceCredits)
      .where(eq(balanceCredits.agencyId, profile.id));
    const [heldRow] = await db.select({ total: sum(withdrawalRequests.amountVnd) }).from(withdrawalRequests)
      .where(and(eq(withdrawalRequests.agencyId, profile.id), inArray(withdrawalRequests.status, ["pending", "approved"])));
    const [memberRow] = await db.select({ total: count() }).from(memberAccounts)
      .where(eq(memberAccounts.agencyId, profile.id));
    const [withdrawalRow] = await db.select({ total: count() }).from(withdrawalRequests)
      .where(and(eq(withdrawalRequests.agencyId, profile.id), eq(withdrawalRequests.status, "pending")));
    const monthParts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit" }).formatToParts(new Date());
    const activityMonth = `${monthParts.find((part) => part.type === "year")!.value}-${monthParts.find((part) => part.type === "month")!.value}`;
    const activeMembers = await db.select({ id: memberAccounts.id }).from(memberAccounts)
      .where(and(eq(memberAccounts.agencyId, profile.id), isNull(memberAccounts.deletedAt)));
    const monthlyTotals = await getMemberMonthlyReportTotals(db, activeMembers.map((member) => member.id), activityMonth);
    let totalWinLossVnd = 0;
    for (const totals of monthlyTotals.values()) totalWinLossVnd = addExactVnd(totalWinLossVnd, totals.netWinLossVnd);
    const [validMemberRow] = await db.select({ total: count() }).from(memberAccounts)
      .where(and(eq(memberAccounts.agencyId, profile.id), eq(memberAccounts.isValid, 1)));
    const credited = safeVndTotal(creditRow?.total);
    const held = safeVndTotal(heldRow?.total);
    return {
      id: profile.id,
      username: profile.username,
      fullName: profile.fullName,
      status: profile.status,
      referralLink: profile.referralLink,
      creditedVnd: credited,
      availableVnd: Math.max(0, safeVndTotal(credited - held)),
      memberCount: Number(memberRow?.total ?? 0),
      pendingWithdrawals: Number(withdrawalRow?.total ?? 0),
      activityMonth,
      totalWinLossVnd,
      validMemberCount: Number(validMemberRow?.total ?? 0),
    };
  }),

  performance: protectedProcedure.input(z.object({
    month: reportMonthSchema,
    cacheKey: z.number().int().positive().optional(),
  }).strict()).query(async ({ ctx, input }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    const bounds = vietnamMonthBounds(input.month);
    const members = await db.select({ id: memberAccounts.id, joinedAt: memberAccounts.joinedAt })
      .from(memberAccounts).where(and(eq(memberAccounts.agencyId, profile.id), isNull(memberAccounts.deletedAt)));
    const memberIds = members.map((member) => member.id);
    const newMembers = members.filter((member) => member.joinedAt >= bounds.start && member.joinedAt < bounds.end);
    const totals = await getMemberMonthlyReportTotals(db, memberIds, input.month);
    const validity = await getMemberMonthValidity(db, memberIds, input.month);
    let totalDepositVnd = 0, totalWithdrawalVnd = 0, totalBetsVnd = 0, totalPromotionVnd = 0, totalRefundVnd = 0, totalWinLossVnd = 0;
    for (const value of totals.values()) {
      totalDepositVnd = addExactVnd(totalDepositVnd, value.totalDepositVnd);
      totalWithdrawalVnd = addExactVnd(totalWithdrawalVnd, value.totalWithdrawalVnd);
      totalBetsVnd = addExactVnd(totalBetsVnd, value.totalBetsVnd);
      totalPromotionVnd = addExactVnd(totalPromotionVnd, value.promotionVnd);
      totalRefundVnd = addExactVnd(totalRefundVnd, value.totalRefundVnd);
      totalWinLossVnd = addExactVnd(totalWinLossVnd, value.netWinLossVnd);
    }
    return {
      activityMonth: input.month,
      memberCount: members.length,
      validMemberCount: members.filter((member) => validity.get(member.id) === 1).length,
      newMemberCount: newMembers.length,
      newValidMemberCount: newMembers.filter((member) => validity.get(member.id) === 1).length,
      totalDepositVnd,
      totalWithdrawalVnd,
      totalBetsVnd,
      totalPromotionVnd,
      totalRefundVnd,
      totalWinLossVnd,
    };
  }),

  members: protectedProcedure.input(z.object({
    search: z.string().trim().max(100).optional(),
    joinedDay: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  })).query(async ({ ctx, input }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    const filters = [eq(memberAccounts.agencyId, profile.id), isNull(memberAccounts.deletedAt)];
    if (input.search) {
      const pattern = `%${input.search.replace(/[\\%_]/g, "\\$&")}%`;
      filters.push(like(memberAccounts.username, pattern));
    }
    if (input.joinedDay) {
      const start = new Date(`${input.joinedDay}T00:00:00+07:00`);
      const end = new Date(start.getTime() + 86_400_000);
      filters.push(gte(memberAccounts.joinedAt, start), lt(memberAccounts.joinedAt, end));
    }
    return db.select({
      id: memberAccounts.id,
      username: memberAccounts.username,
      joinedAt: memberAccounts.joinedAt,
      isValid: memberAccounts.isValid,
    }).from(memberAccounts).where(and(...filters)).orderBy(desc(memberAccounts.joinedAt));
  }),

  bankAccounts: protectedProcedure.query(async ({ ctx }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    return db.select({
      id: bankAccounts.id,
      ownerName: bankAccounts.ownerName,
      accountNumber: bankAccounts.accountNumber,
      bankName: bankAccounts.bankName,
      branch: bankAccounts.branch,
      createdAt: bankAccounts.createdAt,
    }).from(bankAccounts).where(eq(bankAccounts.agencyId, profile.id)).orderBy(desc(bankAccounts.createdAt));
  }),

  addBankAccount: protectedProcedure.input(bankInput).mutation(async ({ ctx, input }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    return db.transaction(async (tx) => {
      const [created] = await tx.insert(bankAccounts).values({ agencyId: profile.id, ...input }).$returningId();
      const id = Number(created.id);
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id,
        action: "agency.bank_account_added",
        entityType: "bank_account",
        entityId: id,
        details: JSON.stringify({ agencyId: profile.id, bankName: input.bankName, accountLast4: input.accountNumber.slice(-4) }),
      });
      return { id };
    });
  }),

  walletAccounts: protectedProcedure.query(async ({ ctx }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    return db.select({
      id: walletAccounts.id, asset: walletAccounts.asset, network: walletAccounts.network,
      address: walletAccounts.address, createdAt: walletAccounts.createdAt,
    }).from(walletAccounts).where(eq(walletAccounts.agencyId, profile.id)).orderBy(desc(walletAccounts.createdAt));
  }),

  addWalletAccount: protectedProcedure.input(walletInput).mutation(async ({ ctx, input }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    const addressKey = walletAddressKey(input.network, input.address);
    return db.transaction(async (tx) => {
      const [lockedProfile] = await tx.select({ id: agencyProfiles.id, status: agencyProfiles.status }).from(agencyProfiles)
        .where(eq(agencyProfiles.id, profile.id)).for("update");
      if (!lockedProfile || lockedProfile.status !== "approved") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Tài khoản đại lý không còn ở trạng thái hoạt động." });
      }
      const [existing] = await tx.select({ id: walletAccounts.id }).from(walletAccounts).where(and(
        eq(walletAccounts.agencyId, profile.id), eq(walletAccounts.network, input.network), eq(walletAccounts.addressKey, addressKey),
      )).limit(1);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Ví này đã có trong danh sách của bạn trên mạng đã chọn." });
      const [created] = await tx.insert(walletAccounts).values({
        agencyId: profile.id, asset: "USDT", network: input.network, address: input.address, addressKey,
      }).$returningId();
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id, action: "agency.wallet_account_added", entityType: "wallet_account", entityId: created.id,
        details: JSON.stringify({ agencyId: profile.id, asset: "USDT", network: input.network, addressLast6: input.address.slice(-6) }),
      });
      return { id: created.id };
    });
  }),

  withdrawals: protectedProcedure.query(async ({ ctx }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    const rows = await db.select({
      id: withdrawalRequests.id,
      amountVnd: withdrawalRequests.amountVnd,
      destinationType: withdrawalRequests.destinationType,
      walletNetwork: withdrawalRequests.walletNetwork,
      walletAddress: withdrawalRequests.walletAddress,
      bankName: withdrawalRequests.bankName,
      accountNumber: withdrawalRequests.accountNumber,
      ownerName: withdrawalRequests.ownerName,
      branch: withdrawalRequests.branch,
      status: withdrawalRequests.status,
      requestedAt: withdrawalRequests.requestedAt,
      decisionNote: withdrawalRequests.decisionNote,
    }).from(withdrawalRequests).where(eq(withdrawalRequests.agencyId, profile.id))
      .orderBy(desc(withdrawalRequests.requestedAt));
    return rows.map((row) => ({ ...row, amountVnd: safeVndTotal(row.amountVnd) }));
  }),

  createWithdrawal: protectedProcedure.input(z.object({
    bankAccountId: z.number().int().positive().optional(),
    walletAccountId: z.number().int().positive().optional(),
    amountVnd: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
  }).strict().refine((input) => Boolean(input.bankAccountId) !== Boolean(input.walletAccountId), "Chọn đúng một ngân hàng hoặc ví USDT nhận tiền.")).mutation(async ({ ctx, input }) => {
    const { db, profile } = await getApprovedProfile(ctx.user.id);
    return db.transaction(async (tx) => {
      // Serialize balance checks per agency so concurrent requests cannot overspend.
      const [lockedProfile] = await tx.select({ id: agencyProfiles.id, status: agencyProfiles.status, fullName: agencyProfiles.fullName }).from(agencyProfiles)
        .where(eq(agencyProfiles.id, profile.id)).for("update");
      if (!lockedProfile) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy tài khoản đại lý." });
      if (lockedProfile.status !== "approved") throw new TRPCError({ code: "FORBIDDEN", message: "Tài khoản đại lý không còn ở trạng thái hoạt động." });

      const [bank] = input.bankAccountId ? await tx.select().from(bankAccounts).where(and(
        eq(bankAccounts.id, input.bankAccountId),
        eq(bankAccounts.agencyId, profile.id),
      )).limit(1) : [];
      const [wallet] = input.walletAccountId ? await tx.select().from(walletAccounts).where(and(
        eq(walletAccounts.id, input.walletAccountId), eq(walletAccounts.agencyId, profile.id),
      )).limit(1) : [];
      if (input.bankAccountId && !bank) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy thông tin ngân hàng của tài khoản này." });
      if (input.walletAccountId && !wallet) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy ví USDT của tài khoản này." });

      const destination = wallet ? "usdt" : "bank";
      if (input.amountVnd < withdrawalMinimumVnd(destination)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: withdrawalMinimumMessage(destination) });
      }

      const [creditRow] = await tx.select({ total: sum(balanceCredits.amountVnd) }).from(balanceCredits)
        .where(eq(balanceCredits.agencyId, profile.id));
      const [heldRow] = await tx.select({ total: sum(withdrawalRequests.amountVnd) }).from(withdrawalRequests)
        .where(and(eq(withdrawalRequests.agencyId, profile.id), inArray(withdrawalRequests.status, ["pending", "approved"])));
      const credited = safeVndTotal(creditRow?.total);
      const held = safeVndTotal(heldRow?.total);
      const available = safeVndTotal(credited - held);
      if (input.amountVnd > available) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Số tiền rút vượt quá số dư khả dụng." });
      }

      const [created] = await tx.insert(withdrawalRequests).values({
        agencyId: profile.id,
        bankAccountId: bank?.id ?? null,
        destinationType: destination,
        walletAccountId: wallet?.id ?? null,
        walletNetwork: wallet?.network ?? null,
        walletAddress: wallet?.address ?? null,
        ownerName: bank?.ownerName ?? lockedProfile.fullName,
        accountNumber: bank?.accountNumber ?? "",
        bankName: bank?.bankName ?? "",
        branch: bank?.branch ?? "",
        amountVnd: input.amountVnd,
        status: "pending",
      }).$returningId();
      const id = Number(created.id);
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id,
        action: "withdrawal.requested",
        entityType: "withdrawal_request",
        entityId: id,
        details: JSON.stringify({ agencyId: profile.id, amountVnd: input.amountVnd, destinationType: destination, bankAccountId: bank?.id ?? null, walletAccountId: wallet?.id ?? null }),
      });
      return { id, status: "pending" as const };
    });
  }),
});
