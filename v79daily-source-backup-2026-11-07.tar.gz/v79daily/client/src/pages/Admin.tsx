import { Fragment, useState, type FormEvent } from "react";
import { Redirect, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { winLossClass } from "@/lib/winloss";
import { AdminNotifications, AdminPasswordResetDialog } from "@/components/AdminAccountTools";
import AdminPayoutDestination from "@/components/AdminPayoutDestination";
import { V79_LOGO_SRC } from "@/brand";
import { Activity, ArrowDownToLine, Check, CircleHelp, ClipboardList, KeyRound, LockKeyhole, LogOut, Plus, Search, ShieldCheck, UnlockKeyhole, UsersRound, WalletCards } from "lucide-react";
import { formatPointEquivalent, formatPointInput, formatVnd, formatVndAsPointNumber, pointMoney, pointsToVnd, POINT_RATE_TEXT } from "@shared/money";
import { sortAdminMemberRowsByDeposit, summarizeAdminMemberRows, type MemberDepositSort } from "@shared/admin-member-view";
import { filterAdminAgencies } from "@shared/admin-agency-search";
import { calculateMonthlyWinLossVnd } from "@shared/monthly-report";
import "@/styles/admin.css";
import "@/styles/admin-account.css";
import "@/styles/winloss.css";

const money = pointMoney;
const vietnamDateTime = new Intl.DateTimeFormat("vi-VN", { timeZone: "Asia/Ho_Chi_Minh", dateStyle: "short", timeStyle: "short" });
const vietnamDate = new Intl.DateTimeFormat("vi-VN", { timeZone: "Asia/Ho_Chi_Minh", dateStyle: "short" });
type AdminTab = "overview" | "registrations" | "agencies" | "notifications" | "withdrawals" | "members" | "audit";
type MemberScope = "month" | "joined" | "cumulative";
type MonthlyEditorSeed = {
  memberId: number;
  username: string;
  agencyUsername: string;
  agencyName: string;
  month: string;
  expected: {
    totalDepositVnd: number;
    totalWithdrawalVnd: number;
    totalBetsVnd: number;
    totalPromotionVnd: number;
  };
};
const tabItems: Array<{ id: AdminTab; label: string }> = [
  { id: "overview", label: "Tổng quan" },
  { id: "registrations", label: "Đăng ký" },
  { id: "agencies", label: "Đại lý" },
  { id: "notifications", label: "Thông báo" },
  { id: "withdrawals", label: "Lệnh rút" },
  { id: "members", label: "Hội viên & báo cáo" },
  { id: "audit", label: "Nhật ký" },
];

function currentVietnamMonth() {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit" }).formatToParts(new Date());
  const year = parts.find((part) => part.type === "year")?.value ?? "";
  const month = parts.find((part) => part.type === "month")?.value ?? "";
  return `${year}-${month}`;
}

function vndToPointInput(vnd: number) {
  const whole = Math.floor(vnd / 1_000);
  const fraction = String(vnd % 1_000).padStart(3, "0").replace(/0+$/, "");
  return formatPointInput(`${whole}${fraction ? `.${fraction}` : ""}`);
}

function statusLabel(status: string) {
  const names: Record<string, string> = { pending: "Chờ duyệt", approved: "Đã duyệt", rejected: "Từ chối", locked: "Đang khóa" };
  return names[status] ?? status;
}

export default function Admin() {
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [withdrawalStatus, setWithdrawalStatus] = useState<"all" | "pending" | "approved" | "rejected">("all");
  const [selectedAgency, setSelectedAgency] = useState("");
  const [selectedMember, setSelectedMember] = useState("");
  const [transactionMember, setTransactionMember] = useState<{ id: number; username: string } | null>(null);
  const [memberArchiveStatus, setMemberArchiveStatus] = useState<"active" | "archived">("active");
  const [memberSearch, setMemberSearch] = useState("");
  const [agencySearch, setAgencySearch] = useState("");
  const [memberScope, setMemberScope] = useState<MemberScope>("month");
  const [memberMonth, setMemberMonth] = useState(currentVietnamMonth);
  const [memberDepositSort, setMemberDepositSort] = useState<MemberDepositSort>("default");
  const [agencyReportMonth, setAgencyReportMonth] = useState(currentVietnamMonth);
  const [monthlyEditor, setMonthlyEditor] = useState<MonthlyEditorSeed | null>(null);
  const [memberFormOpen, setMemberFormOpen] = useState(false);
  const [memberForm, setMemberForm] = useState({ username: "", joinedAt: "" });
  const [passwordAgency, setPasswordAgency] = useState<{ id: number; username: string } | null>(null);
  const [recordKind, setRecordKind] = useState<"transactions" | "bets">("transactions");
  // These controlled form strings contain points; API payloads still contain VND.
  const [recordForm, setRecordForm] = useState({ amountVnd: "", depositVnd: "", withdrawalVnd: "", promotionVnd: "", refundVnd: "", month: "", note: "" });

  const isAdmin = auth.user?.role === "admin";
  const overviewQuery = trpc.admin.overview.useQuery({ month: agencyReportMonth }, { enabled: isAdmin && Boolean(agencyReportMonth), refetchInterval: 30_000 });
  const agenciesPerformance = trpc.admin.agencies.useQuery({ month: agencyReportMonth }, { enabled: isAdmin && Boolean(agencyReportMonth), refetchInterval: 30_000 });
  const registrations = trpc.admin.agencies.useQuery(undefined, { enabled: isAdmin, refetchInterval: 30_000 });
  const withdrawals = trpc.admin.withdrawals.useQuery({ status: withdrawalStatus }, { enabled: isAdmin });
  const memberQueryEnabled = isAdmin && (memberScope === "cumulative" || Boolean(memberMonth));
  const memberQueryInput = {
    agencyId: selectedAgency ? Number(selectedAgency) : undefined,
    includeDeleted: memberArchiveStatus === "archived",
    ...(memberScope !== "cumulative" && memberMonth ? { month: memberMonth } : {}),
    ...(memberScope === "joined" && memberMonth ? { joinedInMonth: true } : {}),
  };
  const members = trpc.admin.members.useQuery(memberQueryInput, { enabled: memberQueryEnabled });
  const memberSummary = trpc.admin.members.useQuery(
    { agencyId: Number(selectedAgency), includeDeleted: memberArchiveStatus === "archived", month: memberScope !== "cumulative" ? memberMonth : undefined },
    { enabled: isAdmin && activeTab === "members" && Boolean(selectedAgency) && memberQueryEnabled, refetchInterval: 30_000 },
  );
  const audit = trpc.admin.audit.useQuery({ limit: 120 }, { enabled: isAdmin && activeTab === "audit" });

  const refresh = async () => {
    setNotice("");
    setError("");
    await Promise.all([
      utils.admin.overview.invalidate(), utils.admin.agencies.invalidate(), utils.admin.withdrawals.invalidate(),
      utils.admin.members.invalidate(), utils.admin.memberTransactions.invalidate(), utils.admin.audit.invalidate(),
    ]);
  };
  const reviewRegistration = trpc.admin.reviewRegistration.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const setAgencyLock = trpc.admin.setAgencyLock.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const updateReferral = trpc.admin.updateReferralLink.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const addBalance = trpc.admin.addBalanceCredit.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const reviewWithdrawal = trpc.admin.reviewWithdrawal.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const createMember = trpc.admin.createMember.useMutation({ onSuccess: async () => { setMemberFormOpen(false); setMemberForm({ username: "", joinedAt: "" }); await refresh(); }, onError: (e) => setError(e.message) });
  const updateMember = trpc.admin.updateMember.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const setMemberValidity = trpc.admin.setMemberValidity.useMutation({ onSuccess: refresh, onError: (e) => setError(e.message) });
  const setMemberArchived = trpc.admin.setMemberArchived.useMutation({ onSuccess: async ({ archived }) => { closeMemberEditors(); setMemberFormOpen(false); await refresh(); setNotice(archived ? "Đã lưu trữ hội viên. Lịch sử và báo cáo gốc vẫn được giữ, có thể khôi phục." : "Đã khôi phục hội viên."); }, onError: (e) => setError(e.message) });
  const addTransaction = trpc.admin.addMemberTransaction.useMutation({ onSuccess: async () => { setRecordForm({ ...recordForm, amountVnd: "", note: "" }); await refresh(); }, onError: (e) => setError(e.message) });
  const addMemberTransactions = trpc.admin.addMemberTransactions.useMutation({ onSuccess: () => { setRecordForm((current) => ({ ...current, depositVnd: "", withdrawalVnd: "" })); setNotice("Đã ghi nhận dữ liệu nạp/rút cho hội viên."); void Promise.all([utils.admin.members.invalidate(), utils.admin.agencies.invalidate(), utils.admin.overview.invalidate(), utils.admin.audit.invalidate()]).catch(() => undefined); }, onError: (e) => setError(e.message) });
  const saveMonthlyBet = trpc.admin.upsertMonthlyBet.useMutation({ onSuccess: async () => { setRecordForm((current) => ({ ...current, amountVnd: "", promotionVnd: "", refundVnd: "" })); await refresh(); setNotice("Đã lưu dữ liệu cược theo tháng. Các chỉ số để trống được giữ nguyên, hoặc là 0 nếu chưa có dữ liệu."); }, onError: (e) => setError(e.message) });
  const saveMemberMonth = trpc.admin.saveMemberMonth.useMutation({
    onSuccess: (result) => {
      setMonthlyEditor(null);
      setError("");
      setNotice(`Đã lưu tổng tháng ${result.month} cho hội viên #${result.memberId}. Lịch sử giao dịch gốc được giữ nguyên; thay đổi báo cáo đã được ghi nhật ký.`);
      void Promise.all([
        utils.admin.members.invalidate(),
        utils.admin.agencies.invalidate(),
        utils.admin.overview.invalidate(),
        utils.admin.audit.invalidate(),
      ]).catch(() => undefined);
    },
    onError: (e) => setError(e.message),
  });

  if (auth.loading) return <main className="admin-auth-state"><span className="auth-spin"><Activity size={20} /></span>Đang xác minh tài khoản Manus…</main>;
  if (!auth.user) return <Redirect to="/admin/login" />;
  if (!isAdmin) return <main className="admin-auth-state admin-denied"><ShieldCheck size={24} /><h1>Không có quyền quản trị</h1><p>Tài khoản Manus này không được cấp vai trò quản trị viên.</p><button type="button" onClick={() => setLocation("/dashboard")}>Về cổng đại lý</button></main>;

  const directoryRows = registrations.data ?? [];
  const filteredAgencyRows = filterAdminAgencies(directoryRows, agencySearch);
  const reportRows = agenciesPerformance.data ?? [];
  const directoryById = new Map(directoryRows.map((row) => [row.id, row]));
  const overviewRows = reportRows.map((reportRow) => {
    const directoryRow = directoryById.get(reportRow.id);
    return {
      ...reportRow,
      fullName: directoryRow?.fullName ?? reportRow.fullName,
      username: directoryRow?.username ?? reportRow.username,
      status: directoryRow?.status ?? reportRow.status,
      memberCount: directoryRow?.memberCount ?? reportRow.memberCount,
      availableVnd: directoryRow?.availableVnd ?? reportRow.availableVnd,
    };
  });
  const performanceByAgency = new Map(reportRows.map((row) => [row.id, row]));
  const registrationRows = directoryRows.filter((item) => item.status === "pending");
  const memberDataPending = addMemberTransactions.isPending || saveMonthlyBet.isPending || saveMemberMonth.isPending || setMemberArchived.isPending;
  const filteredMemberRows = (memberQueryEnabled ? (members.data ?? []) : []).filter((member) => {
    const search = memberSearch.trim().toLowerCase();
    return !search || member.username.toLowerCase().includes(search);
  });
  const memberRows = sortAdminMemberRowsByDeposit(filteredMemberRows, memberDepositSort);
  const selectedAgencyId = selectedAgency ? Number(selectedAgency) : undefined;
  const selectedAgencyRow = selectedAgencyId ? directoryRows.find((agency) => agency.id === selectedAgencyId) : undefined;
  const memberSummaryReady = Boolean(selectedAgencyId) && memberQueryEnabled && !memberSummary.isLoading && !memberSummary.isFetching && !memberSummary.error && Array.isArray(memberSummary.data);
  const memberSummaryCounts = memberSummaryReady && selectedAgencyId !== undefined
    ? summarizeAdminMemberRows(memberSummary.data ?? [], selectedAgencyId)
    : undefined;
  const selectedMemberRow = memberRows.find((member) => member.id === Number(selectedMember));
  const recordAmountVnd = pointsToVnd(recordForm.amountVnd);
  const promotionForCalculation = recordForm.promotionVnd.trim() === "" ? selectedMemberRow?.totalPromotionVnd ?? 0 : pointsToVnd(recordForm.promotionVnd);
  const refundForCalculation = recordForm.refundVnd.trim() === "" ? selectedMemberRow?.totalRefundVnd ?? 0 : pointsToVnd(recordForm.refundVnd);
  const calculatedWinLossVnd = selectedMemberRow && promotionForCalculation !== null && refundForCalculation !== null
    ? calculateMonthlyWinLossVnd({ totalDepositVnd: selectedMemberRow.totalDepositVnd, totalPromotionVnd: promotionForCalculation, totalRefundVnd: refundForCalculation, totalWithdrawalVnd: selectedMemberRow.totalWithdrawalVnd })
    : null;

  function closeMemberEditors() {
    setSelectedMember("");
    setMonthlyEditor(null);
    setTransactionMember(null);
  }

  function changeMemberScope(scope: MemberScope) {
    closeMemberEditors();
    setMemberScope(scope);
  }

  function changeMemberMonth(month: string) {
    closeMemberEditors();
    setMemberMonth(month);
  }

  function toggleMemberTransactions(row: { id: number; username: string }) {
    if (memberScope === "cumulative" || !memberMonth) return;
    setSelectedMember("");
    setMonthlyEditor(null);
    setTransactionMember((current) => current?.id === row.id ? null : row);
  }

  function archiveMember(row: { id: number; username: string }) {
    if (!window.confirm(`Xóa hội viên @${row.username} khỏi danh sách đang hoạt động? Hồ sơ sẽ chuyển vào mục lưu trữ; lịch sử nạp/rút, báo cáo và audit KHÔNG bị xóa và có thể khôi phục.`)) return;
    setMemberArchived.mutate({ memberId: row.id, archived: true });
  }

  function restoreMember(row: { id: number; username: string }) {
    if (!window.confirm(`Khôi phục hội viên @${row.username} về danh sách đang hoạt động?`)) return;
    setMemberArchived.mutate({ memberId: row.id, archived: false });
  }

  function openMonthlyEditor(row: {
    id: number;
    username: string;
    agencyUsername: string;
    agencyName: string;
    totalDepositVnd: number;
    totalWithdrawalVnd: number;
    totalBetsVnd: number;
    totalPromotionVnd?: number;
  }) {
    if (memberScope === "cumulative" || !memberMonth) return;
    setMonthlyEditor({
      memberId: row.id,
      username: row.username,
      agencyUsername: row.agencyUsername,
      agencyName: row.agencyName,
      month: memberMonth,
      expected: {
        totalDepositVnd: row.totalDepositVnd,
        totalWithdrawalVnd: row.totalWithdrawalVnd,
        totalBetsVnd: row.totalBetsVnd,
        totalPromotionVnd: row.totalPromotionVnd ?? 0,
      },
    });
  }

  function confirmRegistration(agencyId: number, decision: "approved" | "rejected", name: string) {
    const action = decision === "approved" ? "duyệt" : "từ chối";
    if (!window.confirm(`Xác nhận ${action} hồ sơ đại lý “${name}”?`)) return;
    reviewRegistration.mutate({ agencyId, decision });
  }

  function confirmLock(agencyId: number, locked: boolean, name: string) {
    const action = locked ? "khóa" : "mở khóa";
    if (!window.confirm(`Xác nhận ${action} tài khoản đại lý “${name}”?`)) return;
    setAgencyLock.mutate({ agencyId, locked });
  }

  function confirmWithdrawal(withdrawalId: number, decision: "approved" | "rejected", amountVnd: number) {
    if (reviewWithdrawal.isPending) return;
    const action = decision === "approved" ? "duyệt" : "từ chối";
    if (!window.confirm(`Xác nhận ${action} đơn rút ${formatPointEquivalent(amountVnd)}? Thao tác chỉ cập nhật trạng thái, không tự chuyển tiền.`)) return;
    const note = decision === "rejected" ? window.prompt("Nhập lý do từ chối:")?.trim() : undefined;
    if (decision === "rejected" && !note) return;
    reviewWithdrawal.mutate({ withdrawalId, decision, note });
  }

  function submitMember(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (createMember.isPending) return;
    if (!selectedAgency) { setError("Chọn đại lý trước khi thêm hội viên."); return; }
    createMember.mutate({
      agencyId: Number(selectedAgency), username: memberForm.username,
      joinedAt: memberForm.joinedAt ? new Date(`${memberForm.joinedAt}T00:00:00+07:00`) : undefined,
    });
  }

  function submitMemberRecord(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (addMemberTransactions.isPending || saveMonthlyBet.isPending) return;
    if (!selectedMember) { setError("Chọn hội viên trước khi ghi dữ liệu."); return; }
    if (members.isFetching || members.error) { setError("Đợi tải xong dữ liệu hội viên trước khi lưu."); return; }
    if (recordKind === "bets") {
      const amountVnd = pointsToVnd(recordForm.amountVnd);
      if (amountVnd === null || amountVnd < 0) { setError("Tổng cược phải là số điểm không âm hợp lệ, tối đa 3 số thập phân."); return; }
      const promotionVnd = recordForm.promotionVnd.trim() === "" ? undefined : pointsToVnd(recordForm.promotionVnd);
      const refundVnd = recordForm.refundVnd.trim() === "" ? undefined : pointsToVnd(recordForm.refundVnd);
      const netWinLossVnd = calculatedWinLossVnd;
      if (!recordForm.month) { setError("Chọn tháng để lưu tổng cược."); return; }
      if (promotionVnd === null || (promotionVnd !== undefined && promotionVnd < 0)) { setError("Khuyến mãi phải là số điểm không âm hợp lệ, tối đa 3 số thập phân."); return; }
      if (refundVnd === null || (refundVnd !== undefined && refundVnd < 0)) { setError("Hoàn trả phải là số điểm không âm hợp lệ, tối đa 3 số thập phân."); return; }
      if (netWinLossVnd === null) { setError("Không thể tính Tổng thắng thua an toàn từ dữ liệu tháng này. Hãy kiểm tra nạp/rút, khuyến mãi và hoàn trả."); return; }
      const unchanged = "giữ giá trị đã lưu (0 nếu chưa có dữ liệu)";
      const promotion = promotionVnd === undefined ? unchanged : formatPointEquivalent(promotionVnd);
      const outcome = netWinLossVnd > 0 ? `hội viên thắng ${formatPointEquivalent(netWinLossVnd)}` : netWinLossVnd < 0 ? `hội viên thua ${formatPointEquivalent(Math.abs(netWinLossVnd))}` : "hòa";
      const refund = refundVnd === undefined ? unchanged : formatPointEquivalent(refundVnd);
      if (!window.confirm(`Cập nhật dữ liệu cược tháng ${recordForm.month} cho @${selectedMemberRow?.username ?? "hội viên"}: khuyến mãi ${promotion}, tổng cược ${formatPointEquivalent(amountVnd)}, thắng/thua tự tính ${outcome}, hoàn trả ${refund}?`)) return;
      saveMonthlyBet.mutate({ memberId: Number(selectedMember), month: recordForm.month, amountVnd, promotionVnd, refundVnd });
    } else {
      const depositVnd = recordForm.depositVnd.trim() === "" ? undefined : pointsToVnd(recordForm.depositVnd);
      const withdrawalVnd = recordForm.withdrawalVnd.trim() === "" ? undefined : pointsToVnd(recordForm.withdrawalVnd);
      if (depositVnd === null || withdrawalVnd === null || (depositVnd ?? 0) < 0 || (withdrawalVnd ?? 0) < 0) {
        setError("Nhập số điểm nạp/rút không âm hợp lệ; dùng dấu phẩy hàng nghìn và tối đa 3 số thập phân."); return;
      }
      if ((depositVnd ?? 0) <= 0 && (withdrawalVnd ?? 0) <= 0) { setError("Nhập ít nhất một khoản nạp hoặc rút lớn hơn 0."); return; }
      const deposit = depositVnd && depositVnd > 0 ? formatPointEquivalent(depositVnd) : "0 điểm";
      const withdrawal = withdrawalVnd && withdrawalVnd > 0 ? formatPointEquivalent(withdrawalVnd) : "0 điểm";
      if (!window.confirm(`Ghi nhận cho @${selectedMemberRow?.username ?? "hội viên"}: nạp ${deposit}, rút ${withdrawal}?`)) return;
      addMemberTransactions.mutate({
        memberId: Number(selectedMember),
        depositVnd: depositVnd && depositVnd > 0 ? depositVnd : undefined,
        withdrawalVnd: withdrawalVnd && withdrawalVnd > 0 ? withdrawalVnd : undefined,
      });
    }
  }

  function renderMemberRecordForm() {
    if (!selectedMemberRow) return null;
    return (
      <form className="admin-record-form admin-record-form-inline" onSubmit={submitMemberRecord}>
        <div className="admin-record-title"><div><b>Ghi dữ liệu cho @{selectedMemberRow.username}</b><small>Thao tác sẽ tạo nhật ký quản trị.</small>{recordKind === "transactions" && <small>Ngày giờ giao dịch do hệ thống tự ghi nhận khi lưu.</small>}{recordKind === "bets" && <><small>Tháng và tổng cược bắt buộc. Khuyến mãi/hoàn trả để trống giữ giá trị đã lưu, hoặc dùng 0 nếu chưa có dữ liệu.</small><small>Tổng thắng thua tự tính = Rút − Nạp − Khuyến mãi − Hoàn trả.</small></>}</div><button type="button" disabled={memberDataPending} onClick={() => setSelectedMember("")}>Đóng</button></div>
        <div className="admin-record-fields">
          <label><span>Loại dữ liệu</span><select value={recordKind} disabled={addMemberTransactions.isPending || saveMonthlyBet.isPending} onChange={(event) => setRecordKind(event.target.value as typeof recordKind)}><option value="transactions">Lịch sử nạp / rút</option><option value="bets">Chỉ số cược theo tháng</option></select></label>
          {recordKind === "bets" && <label><span>Tháng</span><input required type="month" disabled value={recordForm.month} title="Dùng tháng đã chọn ở bộ lọc danh sách." /></label>}
          {recordKind === "bets" ? <>
            <label><span>Khuyến mãi (điểm)</span><input type="text" inputMode="decimal" placeholder="Để trống giữ giá trị cũ; nhập 0 để đặt về 0" value={recordForm.promotionVnd} disabled={saveMonthlyBet.isPending} onChange={(event) => setRecordForm({ ...recordForm, promotionVnd: event.target.value })} onBlur={() => setRecordForm((current) => ({ ...current, promotionVnd: formatPointInput(current.promotionVnd) }))} /></label>
            <label><span>Tổng cược (điểm)</span><input required type="text" inputMode="decimal" disabled={saveMonthlyBet.isPending} placeholder="Ví dụ: 1,000" value={recordForm.amountVnd} onChange={(event) => setRecordForm({ ...recordForm, amountVnd: event.target.value })} onBlur={() => setRecordForm((current) => ({ ...current, amountVnd: formatPointInput(current.amountVnd) }))} /></label>
            <label><span>Tổng thắng thua (điểm)</span><input type="text" className={calculatedWinLossVnd === null ? "win-loss-neutral" : winLossClass(calculatedWinLossVnd)} readOnly aria-readonly="true" value={calculatedWinLossVnd === null ? "—" : formatVndAsPointNumber(calculatedWinLossVnd)} title="Rút − Nạp − Khuyến mãi − Hoàn trả" /></label>
          <label><span>Hoàn trả (điểm)</span><input type="text" inputMode="decimal" placeholder="Để trống giữ giá trị cũ; nhập 0 để đặt về 0" value={recordForm.refundVnd} disabled={saveMonthlyBet.isPending} onChange={(event) => setRecordForm({ ...recordForm, refundVnd: event.target.value })} onBlur={() => setRecordForm((current) => ({ ...current, refundVnd: formatPointInput(current.refundVnd) }))} /></label>
          </> : <>
            <label><span>Số tiền nạp (điểm)</span><input type="text" inputMode="decimal" placeholder="Để trống nếu không nạp" value={recordForm.depositVnd} disabled={addMemberTransactions.isPending} onChange={(event) => setRecordForm({ ...recordForm, depositVnd: event.target.value })} onBlur={() => setRecordForm((current) => ({ ...current, depositVnd: formatPointInput(current.depositVnd) }))} /></label>
            <label><span>Số tiền rút (điểm)</span><input type="text" inputMode="decimal" placeholder="Để trống nếu không rút" value={recordForm.withdrawalVnd} disabled={addMemberTransactions.isPending} onChange={(event) => setRecordForm({ ...recordForm, withdrawalVnd: event.target.value })} onBlur={() => setRecordForm((current) => ({ ...current, withdrawalVnd: formatPointInput(current.withdrawalVnd) }))} /></label>
          </>}
          <button type="submit" className="admin-primary-button" disabled={addMemberTransactions.isPending || saveMonthlyBet.isPending}>{addMemberTransactions.isPending || saveMonthlyBet.isPending ? "Đang lưu…" : "Lưu dữ liệu"}</button>
        </div>
        {recordKind === "bets" && recordAmountVnd !== null && <p className="mt-3 text-xs text-slate-600">Quy đổi: {formatPointEquivalent(recordAmountVnd)}.</p>}
            </form>
    );
  }

  return (
    <main className="admin-shell">
      <header className="admin-topbar"><a href="/admin" className="dashboard-wordmark" aria-label="V79 Admin"><span className="dashboard-logo-frame"><img className="dashboard-logo-image" src={V79_LOGO_SRC} alt="V79" /></span><span className="wordmark-label">ADMIN</span></a><div className="admin-topbar-title"><ShieldCheck size={17} /> Bảng điều khiển quản trị</div><div className="admin-user"><span>{auth.user.name || auth.user.email}</span><button type="button" onClick={() => { void auth.logout().then(() => setLocation("/")); }}><LogOut size={14} /> Đăng xuất</button></div></header>
      <div className="admin-layout">
        <aside className="admin-sidebar"><div className="admin-sidebar-label">QUẢN LÝ V79</div>{tabItems.map((item) => <button type="button" key={item.id} className={activeTab === item.id ? "admin-tab active" : "admin-tab"} onClick={() => setActiveTab(item.id)}>{item.label}</button>)}<div className="admin-sidebar-note"><LockKeyhole size={15} /><span>Mọi thao tác quản trị đều được ghi nhật ký.</span></div></aside>
        <section className="admin-main">
          <div className="admin-page-heading"><div><span className="admin-eyebrow">V79 · ADMIN</span><h1>{tabItems.find((item) => item.id === activeTab)?.label}</h1><p>Đơn vị số tiền: điểm · {POINT_RATE_TEXT}{" "}</p></div><div className="admin-page-heading-tools">{(activeTab === "overview" || activeTab === "agencies") && <label className="admin-report-month-control"><span>Tháng báo cáo</span><input type="month" value={agencyReportMonth} onChange={(event) => setAgencyReportMonth(event.target.value)} /></label>}<span className="admin-role-pill"><ShieldCheck size={14} /> Admin</span></div></div>
          {notice && <div className="admin-notice" role="status">{notice}</div>}
          {error && <div className="admin-error" role="alert">{error}<button type="button" onClick={() => setError("")}>Đóng</button></div>}
          {(activeTab === "overview" || activeTab === "agencies") && agencyReportMonth && (overviewQuery.error || agenciesPerformance.error) && <div className="admin-error" role="alert">Không tải được báo cáo tháng {agencyReportMonth}: {overviewQuery.error?.message ?? agenciesPerformance.error?.message ?? "Lỗi không xác định."}</div>}

          {activeTab === "overview" && <>
            <div className="admin-stat-grid">
              <article><span className="admin-stat-icon stat-violet"><ClipboardList size={18} /></span><small>Hồ sơ chờ duyệt</small><b>{overviewQuery.isLoading || overviewQuery.isFetching ? "Đang tải…" : overviewQuery.error ? "Lỗi" : overviewQuery.data?.pendingRegistrations ?? "—"}</b></article>
              <article><span className="admin-stat-icon stat-blue"><UsersRound size={18} /></span><small>Tài khoản đại lý</small><b>{overviewQuery.isLoading || overviewQuery.isFetching ? "Đang tải…" : overviewQuery.error ? "Lỗi" : overviewQuery.data?.agencies ?? "—"}</b></article>
              <article><span className="admin-stat-icon stat-gold"><ArrowDownToLine size={18} /></span><small>Lệnh rút chờ duyệt</small><b>{overviewQuery.isLoading || overviewQuery.isFetching ? "Đang tải…" : overviewQuery.error ? "Lỗi" : overviewQuery.data?.pendingWithdrawals ?? "—"}</b></article>
              <article><span className="admin-stat-icon stat-green"><WalletCards size={18} /></span><small>Hội viên</small><b>{overviewQuery.isLoading || overviewQuery.isFetching ? "Đang tải…" : overviewQuery.error ? "Lỗi" : overviewQuery.data?.members ?? "—"}</b></article>
            </div>
            <section className="admin-card">
              <div className="admin-card-head"><div><h2>Hiệu suất đại lý · {agencyReportMonth || "chưa chọn tháng"}</h2><p>Hội viên, trạng thái, hồ sơ và số dư khả dụng là thông tin hiện tại. Các khoản nạp/rút và cược là báo cáo của tháng đã chọn; số dư không phải số dư lịch sử. Thắng/thua dương = hội viên thắng; âm = hội viên thua.</p></div></div>
              <div className="admin-table-wrap"><table className="admin-table">
                <thead><tr><th>Đại lý</th><th>Trạng thái</th><th>Hội viên</th><th>Nạp tháng</th><th>Rút tháng</th><th>Tổng cược tháng</th><th>Khuyến mãi + Hoàn trả</th><th>Tổng thắng thua tháng</th><th>Số dư khả dụng</th></tr></thead>
                <tbody>{!agencyReportMonth ? <tr><td colSpan={9} className="admin-empty">Chưa chọn tháng. Hãy chọn tháng để xem hiệu suất đại lý.</td></tr> : agenciesPerformance.isLoading || agenciesPerformance.isFetching || overviewQuery.isLoading || overviewQuery.isFetching ? <tr><td colSpan={9} className="admin-empty">Đang tải báo cáo đại lý tháng {agencyReportMonth}…</td></tr> : agenciesPerformance.error || overviewQuery.error ? <tr><td colSpan={9} className="admin-empty admin-empty-error">Không tải được báo cáo đại lý tháng {agencyReportMonth}.</td></tr> : !overviewRows.length ? <tr><td colSpan={9} className="admin-empty">Không có hồ sơ đại lý trong báo cáo tháng {agencyReportMonth}.</td></tr> : overviewRows.map((row) => { const promotionRefund = typeof row.monthPromotionRefundVnd === "number" ? row.monthPromotionRefundVnd : typeof row.monthPromotionVnd === "number" && typeof row.monthRefundVnd === "number" ? row.monthPromotionVnd + row.monthRefundVnd : null; return <tr key={row.id}><td className="admin-agency-identity"><b>@{row.username}</b><small>{row.fullName}</small></td><td><span className={`admin-status status-${row.status}`}>{statusLabel(row.status)}</span></td><td>{row.memberCount}</td><td>{money.format(row.monthDepositVnd)}</td><td>{money.format(row.monthMemberWithdrawalVnd)}</td><td>{money.format(row.monthBetsVnd)}</td><td>{promotionRefund === null ? "—" : money.format(promotionRefund)}</td><td className={winLossClass(row.monthWinLossVnd ?? 0)}>{money.format(row.monthWinLossVnd ?? 0)}</td><td>{money.format(row.availableVnd)}</td></tr>; })}</tbody>
              </table></div>
            </section>
            <div className="admin-safety-note"><CircleHelp size={16} /><span></span></div>
          </>}

          {activeTab === "registrations" && <section className="admin-card"><div className="admin-card-head"><div><h2>Hồ sơ đăng ký đại lý</h2><p>Gmail do người đăng ký cung cấp; hồ sơ chỉ được cấp quyền sau khi admin duyệt.</p></div><span className="admin-count">{registrationRows.length} chờ duyệt</span></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Tên đăng nhập</th><th>Họ và tên</th><th>Gmail liên hệ</th><th>Số điện thoại</th><th>Ngày đăng ký</th><th>Thao tác</th></tr></thead><tbody>{registrationRows.map((row) => <tr key={row.id}><td><b>@{row.username}</b></td><td>{row.fullName}</td><td>{row.email || "—"}</td><td>{row.phone}</td><td>{vietnamDateTime.format(row.createdAt)}</td><td className="admin-actions"><button type="button" className="action-approve" onClick={() => confirmRegistration(row.id, "approved", row.username)}>Duyệt</button><button type="button" className="action-reject" onClick={() => confirmRegistration(row.id, "rejected", row.username)}>Từ chối</button></td></tr>)}{!registrationRows.length && <tr><td colSpan={6} className="admin-empty">Không có hồ sơ đang chờ duyệt.</td></tr>}</tbody></table></div></section>}

          {activeTab === "agencies" && <section className="admin-card"><div className="admin-card-head"><div><h2>Quản lý đại lý</h2><p>Sửa liên kết, cộng số dư, khóa hoặc mở tài khoản. Số dư và thông tin hồ sơ là hiện tại; hiệu suất bên dưới thuộc tháng đã chọn, không phải số dư lịch sử.</p></div><span className="admin-count">{registrations.isLoading || registrations.isFetching ? "Đang tải…" : registrations.error ? "—" : agencySearch.trim() ? `${filteredAgencyRows.length}/${directoryRows.length} hồ sơ` : `${directoryRows.length} hồ sơ`}</span></div><div className="admin-member-controls"><label className="admin-member-search"><span>Tìm đại lý</span><div><Search size={14} /><input type="search" aria-label="Tìm đại lý" placeholder="Tên đăng nhập hoặc họ tên đại lý" value={agencySearch} onChange={(event) => setAgencySearch(event.target.value)} /></div></label></div><div className="admin-table-wrap"><table className="admin-table admin-agency-table"><thead><tr><th>Đại lý</th><th>Trạng thái</th><th>Số dư</th><th>Hiệu suất ({agencyReportMonth || "chưa chọn tháng"})</th><th>Liên kết giới thiệu</th><th>Quyền truy cập</th></tr></thead><tbody>{registrations.isLoading || registrations.isFetching ? <tr><td colSpan={6} className="admin-empty">Đang tải hồ sơ đại lý…</td></tr> : registrations.error ? <tr><td colSpan={6} className="admin-empty admin-empty-error">Không tải được directory đại lý: {registrations.error.message}</td></tr> : !filteredAgencyRows.length ? <tr><td colSpan={6} className="admin-empty">{agencySearch.trim() ? "Không tìm thấy đại lý phù hợp." : "Chưa có hồ sơ đại lý."}</td></tr> : filteredAgencyRows.map((row) => { const performance = performanceByAgency.get(row.id); return <tr key={row.id}><td><b>{row.fullName}</b><small>@{row.username} · {row.email}</small><small>{row.phone}</small></td><td><span className={`admin-status status-${row.status}`}>{statusLabel(row.status)}</span></td><td><b>{money.format(row.availableVnd)}</b><small>Đã cộng {money.format(row.creditedVnd)}</small><BalanceCreditForm agencyId={row.id} agencyName={row.username} addBalance={addBalance} /></td><td>{!agencyReportMonth ? <span className="muted-text">Chưa chọn tháng</span> : agenciesPerformance.isLoading || agenciesPerformance.isFetching ? <span className="muted-text">Đang tải…</span> : agenciesPerformance.error ? <span className="admin-inline-error">Lỗi tải báo cáo</span> : !performance ? <span className="muted-text">Chưa có dữ liệu tháng</span> : <><b>{row.memberCount} hội viên</b><small className="admin-agency-depositors" title="Mỗi hội viên có tổng nạp sau điều chỉnh lớn hơn 0 trong tháng được đếm một lần.">Số hội viên nạp: {performance.monthDepositorCount ?? "—"}</small><small className="admin-agency-valid-members" title={`Admin đánh dấu hợp lệ cho tháng ${agencyReportMonth}.`}>Hội viên hợp lệ: {performance.monthValidMemberCount ?? "—"}</small><small>Nạp {money.format(performance.monthDepositVnd)}</small><small>Rút {money.format(performance.monthMemberWithdrawalVnd)}</small><small>Tổng cược {money.format(performance.monthBetsVnd)}</small><small className="admin-agency-promotion">Khuyến mãi {typeof performance.monthPromotionVnd === "number" ? money.format(performance.monthPromotionVnd) : "—"}</small><small>Thắng/thua <span className={winLossClass(performance.monthWinLossVnd ?? 0)}>{money.format(performance.monthWinLossVnd ?? 0)}</span></small><small>Lần đăng nhập {row.lastSignedIn ? vietnamDateTime.format(row.lastSignedIn) : "—"}</small></>}</td><td><ReferralLinkForm agencyId={row.id} value={row.referralLink ?? ""} updateReferral={updateReferral} /></td><td><button id={`admin-reset-password-${row.id}`} type="button" className="admin-account-reset-button" onClick={() => setPasswordAgency({ id: row.id, username: row.username })}><KeyRound size={14} /> Đổi mật khẩu</button>{row.status === "approved" ? <button type="button" className="action-lock" onClick={() => confirmLock(row.id, true, row.username)}><LockKeyhole size={14} /> Khóa</button> : row.status === "locked" ? <button type="button" className="action-unlock" onClick={() => confirmLock(row.id, false, row.username)}><UnlockKeyhole size={14} /> Mở khóa</button> : <span className="muted-text">Duyệt hồ sơ trước</span>}</td></tr>; })}</tbody></table></div></section>}

          {activeTab === "notifications" && <AdminNotifications agencies={directoryRows} onUpdated={refresh} />}

          {activeTab === "withdrawals" && <section className="admin-card">
            <div className="admin-card-head"><div><h2>Đơn rút hoa hồng</h2><p>Đối chiếu họ tên, STK/địa chỉ ví, ngân hàng/mạng USDT và số điểm trước khi duyệt hoặc thanh toán.</p></div>
              <select className="admin-filter" value={withdrawalStatus} onChange={(event) => setWithdrawalStatus(event.target.value as typeof withdrawalStatus)}><option value="all">Tất cả trạng thái</option><option value="pending">Chờ duyệt</option><option value="approved">Đã duyệt</option><option value="rejected">Từ chối</option></select>
            </div>
            <div className="admin-table-wrap"><table className="admin-table admin-withdrawal-table">
              <thead><tr><th>Đại lý</th><th>Ngày giờ</th><th>Họ tên nhận tiền</th><th>Số tài khoản / Địa chỉ ví</th><th>Ngân hàng / Loại ví</th><th>Số điểm rút</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
              <tbody>{withdrawals.data?.map((row) => <tr key={row.id}>
                <td><b>{row.agencyName}</b><small>@{row.agencyUsername}</small></td>
                <td>{vietnamDateTime.format(row.requestedAt)}</td>
                <td><b>{row.ownerName}</b></td>
                <td className="admin-payout-account"><AdminPayoutDestination kind={row.destinationType === "usdt" ? "usdt" : "bank"} value={row.destinationType === "usdt" ? row.walletAddress : row.accountNumber} withdrawalId={row.id} /></td>
                <td><b>{row.destinationType === "usdt" ? `USDT (${row.walletNetwork})` : row.bankName}</b>{row.destinationType !== "usdt" && <small>{row.branch}</small>}</td>
                <td className="admin-payout-amount"><b>{money.format(row.amountVnd)}</b><small>{formatVnd(row.amountVnd)}</small></td>
                <td><span className={`admin-status status-${row.status}`}>{row.status === "approved" ? "Đã duyệt · Chưa chuyển" : statusLabel(row.status)}</span>{row.decisionNote && <small>{row.decisionNote}</small>}</td>
                <td className="admin-actions">{row.status === "pending" ? <><button type="button" className="action-approve" disabled={reviewWithdrawal.isPending} onClick={() => confirmWithdrawal(row.id, "approved", row.amountVnd)}>Duyệt</button><button type="button" className="action-reject" disabled={reviewWithdrawal.isPending} onClick={() => confirmWithdrawal(row.id, "rejected", row.amountVnd)}>Từ chối</button></> : <span className="muted-text">Đã xử lý</span>}</td>
              </tr>)}{!withdrawals.data?.length && <tr><td colSpan={8} className="admin-empty">Chưa có lệnh rút.</td></tr>}</tbody>
            </table></div>
          </section>}

          {activeTab === "members" && <section className="admin-card"><div className="admin-card-head"><div><h2>Hội viên và dữ liệu báo cáo</h2><p>{memberScope === "cumulative" ? "Lũy kế tất cả tháng; không chọn tháng và không sửa tổng tháng từ phạm vi này. Cờ hợp lệ là trạng thái hiện tại, không phải tổng lịch sử theo tháng." : memberScope === "joined" ? `Chỉ hội viên tham gia trong tháng ${memberMonth || "đang chọn"}; số liệu vẫn tính theo tháng đã chọn.` : `Số liệu theo tháng ${memberMonth || "chưa chọn"}; giữ cả hội viên cũ để xem hoạt động.`} Đơn vị: điểm.</p></div></div>
            <div className="admin-member-controls">
              <label><span>Phạm vi</span><select value={memberScope} disabled={createMember.isPending || memberDataPending} onChange={(event) => changeMemberScope(event.target.value as MemberScope)}><option value="month">Theo tháng</option><option value="joined">Hội viên tham gia trong tháng</option><option value="cumulative">Lũy kế tất cả tháng</option></select></label>
              <label><span>Tháng</span><input className="admin-month-input" type="month" value={memberMonth} disabled={createMember.isPending || memberDataPending || memberScope === "cumulative"} onChange={(event) => changeMemberMonth(event.target.value)} /></label>
              <label><span>Đại lý</span><select value={selectedAgency} disabled={createMember.isPending || memberDataPending} onChange={(event) => { closeMemberEditors(); setSelectedAgency(event.target.value); }}><option value="">Tất cả (chỉ xem)</option>{directoryRows.filter((agency) => agency.status === "approved").map((agency) => <option key={agency.id} value={agency.id}>@{agency.username} · {agency.fullName}</option>)}</select></label>
              <label className="admin-member-search"><span>Tìm hội viên</span><div><Search size={14} /><input value={memberSearch} onChange={(event) => setMemberSearch(event.target.value)} placeholder="Tên đăng nhập hội viên" /></div></label>
              <label><span>Sắp xếp nạp</span><select aria-label="Sắp xếp tiền nạp" value={memberDepositSort} onChange={(event) => setMemberDepositSort(event.target.value as MemberDepositSort)}><option value="default">Mặc định</option><option value="desc">Nạp cao→thấp</option><option value="asc">Nạp thấp→cao</option></select></label>
              <label><span>Trạng thái</span><select aria-label="Trạng thái hội viên" value={memberArchiveStatus} onChange={(event) => { closeMemberEditors(); setMemberFormOpen(false); setMemberArchiveStatus(event.target.value as typeof memberArchiveStatus); }}><option value="active">Đang hoạt động</option><option value="archived">Đã lưu trữ</option></select></label>
              <button type="button" disabled={!selectedAgency || memberArchiveStatus === "archived" || createMember.isPending || memberDataPending} className="admin-primary-button" onClick={() => { setMemberFormOpen((open) => !open); setError(""); }}><Plus size={15} /> Thêm hội viên</button>
            </div>
            {selectedAgency && <div className="admin-member-stats" aria-live="polite"><div className="admin-member-stats-caption">Đại lý: @{selectedAgencyRow?.username ?? selectedAgency}{selectedAgencyRow?.fullName ? ` · ${selectedAgencyRow.fullName}` : ""} · Kỳ báo cáo: {memberScope === "cumulative" ? "Lũy kế tất cả tháng · cờ hợp lệ hiện tại" : memberScope === "joined" ? `${memberMonth ? `Tháng ${memberMonth}` : "Chưa chọn tháng"} · số đếm toàn đại lý` : memberMonth ? `Tháng ${memberMonth}` : "Chưa chọn tháng"}</div><article><small>Số khách nạp</small><b>{memberSummaryCounts?.depositingCustomerCount ?? "—"}</b></article><article><small>Số khách hợp lệ</small><b>{memberSummaryCounts?.validCustomerCount ?? "—"}</b></article></div>}
            <div className="admin-member-scope-note">{!memberQueryEnabled ? "Hãy chọn tháng để tải dữ liệu theo tháng. Không có tháng thì không gọi truy vấn và không hiển thị dữ liệu lũy kế." : memberScope === "cumulative" ? "Phạm vi lũy kế: đây là số liệu xem tổng hợp, nút Sửa tổng tháng bị khóa." : "Sửa tổng tháng chỉ tác động báo cáo của đúng hội viên và tháng; lịch sử giao dịch gốc vẫn giữ nguyên và thay đổi có nhật ký."}</div>
            {memberFormOpen && <form className="admin-inline-form" onSubmit={submitMember}>
              <label><span>Tên đăng nhập</span><input required minLength={2} maxLength={64} disabled={createMember.isPending} value={memberForm.username} onChange={(event) => setMemberForm({ ...memberForm, username: event.target.value })} /></label>
              <label><span>Ngày tham gia</span><input type="date" disabled={createMember.isPending} value={memberForm.joinedAt} onChange={(event) => setMemberForm({ ...memberForm, joinedAt: event.target.value })} /></label>
              <button type="submit" className="admin-primary-button" disabled={createMember.isPending}>{createMember.isPending ? "Đang lưu…" : "Lưu hội viên"}</button>
            </form>}
            <div className="admin-table-wrap"><table className="admin-table admin-member-table">
              <thead><tr><th>Đại lý</th><th>Tên đăng nhập</th><th>Tổng nạp</th><th>Tổng rút</th><th>Tổng cược</th><th>Khuyến mãi</th><th>Hoàn trả</th><th>Tổng thắng thua</th><th>Ngày tham gia</th><th>Hội viên hợp lệ</th><th>Thao tác</th></tr></thead>
              <tbody>{!memberQueryEnabled ? <tr><td colSpan={11} className="admin-empty">Chưa chọn tháng. Hãy chọn tháng để xem dữ liệu theo tháng.</td></tr> : members.isLoading || members.isFetching ? <tr><td colSpan={11} className="admin-empty">Đang tải danh sách hội viên…</td></tr> : members.error ? <tr><td colSpan={11} className="admin-empty admin-empty-error">Không tải được danh sách hội viên: {members.error.message}</td></tr> : memberRows.map((row) => <Fragment key={row.id}><tr>
                <td>@{row.agencyUsername}</td><td><b>{row.username}</b></td>
                <td className="admin-member-money">{money.format(row.totalDepositVnd)}</td>
                <td className="admin-member-money">{money.format(row.totalWithdrawalVnd)}</td>
                <td className="admin-member-money">{money.format(row.totalBetsVnd)}</td>
                <td className="admin-member-money">{money.format(row.totalPromotionVnd ?? 0)}</td>
                <td className="admin-member-money">{money.format(row.totalRefundVnd ?? 0)}</td>
                <td className={`admin-member-money ${winLossClass(row.netWinLossVnd ?? 0)}`}>{money.format(row.netWinLossVnd ?? 0)}</td>
                <td>{vietnamDate.format(row.joinedAt)}</td>
                <td><input type="checkbox" aria-label={`Hội viên hợp lệ: ${row.username}`} title={memberScope === "cumulative" ? "Phạm vi lũy kế chỉ đọc; hãy chọn một tháng để đánh dấu hợp lệ." : `Trạng thái hợp lệ riêng của tháng ${memberMonth}.`} checked={row.isValid === 1} disabled={memberArchiveStatus === "archived" || memberScope === "cumulative" || !memberMonth || setMemberValidity.isPending} onChange={(event) => setMemberValidity.mutate({ memberId: row.id, isValid: event.target.checked, month: memberMonth })} /></td>
                <td className="admin-actions admin-member-actions">
                  <button type="button" className="action-edit member-action-secondary" disabled={updateMember.isPending || memberDataPending || memberArchiveStatus === "archived"} onClick={() => { const username = window.prompt("Tên đăng nhập:", row.username); if (username === null) return; updateMember.mutate({ memberId: row.id, username }); }}>Cập nhật</button>
                  {memberArchiveStatus === "active" ? <>
                    <button type="button" className="action-edit member-action-secondary" disabled={memberDataPending || memberScope === "cumulative" || !memberMonth} title={memberScope === "cumulative" ? "Chọn phạm vi theo tháng để ghi dữ liệu." : undefined} onClick={() => { setTransactionMember(null); setMonthlyEditor(null); setSelectedMember(String(row.id)); setRecordForm({ ...recordForm, amountVnd: "", depositVnd: "", withdrawalVnd: "", promotionVnd: formatVndAsPointNumber(row.totalPromotionVnd ?? 0), refundVnd: formatVndAsPointNumber(row.totalRefundVnd ?? 0), month: memberMonth || currentVietnamMonth(), note: "" }); }}>Ghi dữ liệu</button>
                    <button type="button" className="action-edit action-edit-month" disabled={memberScope === "cumulative" || !memberMonth || memberDataPending} onClick={() => { setTransactionMember(null); setSelectedMember(""); openMonthlyEditor(row); }}>Sửa tổng tháng</button>
                    <button type="button" className="action-edit" disabled={memberScope === "cumulative" || !memberMonth || memberDataPending} title={memberScope === "cumulative" ? "Chọn tháng để xem và sửa giao dịch." : undefined} onClick={() => toggleMemberTransactions(row)}>Sửa nạp/rút</button>
                    <button type="button" className="action-reject" aria-label={`Xóa hội viên ${row.username}`} disabled={setMemberArchived.isPending} onClick={() => archiveMember(row)}>Xóa</button>
                  </> : <>
                    <button type="button" className="action-edit" disabled={!memberMonth || memberScope === "cumulative"} onClick={() => toggleMemberTransactions(row)}>Xem/sửa nạp/rút</button>
                    <button type="button" className="action-approve" disabled={setMemberArchived.isPending} onClick={() => restoreMember(row)}>Khôi phục</button>
                  </>}
                </td>
              </tr>{selectedMember === String(row.id) && <tr className="admin-record-row"><td colSpan={11}>{renderMemberRecordForm()}</td></tr>}{transactionMember?.id === row.id && memberMonth && memberScope !== "cumulative" && <tr className="admin-transaction-history-row"><td colSpan={11}><MemberTransactionHistory key={`${row.id}:${memberMonth}`} memberId={row.id} username={row.username} month={memberMonth} onUpdated={() => { setNotice(`Đã sửa giao dịch của @${row.username}; Tổng thắng thua tháng đã được tính lại.`); void Promise.all([utils.admin.members.invalidate(), utils.admin.memberTransactions.invalidate(), utils.admin.agencies.invalidate(), utils.admin.overview.invalidate(), utils.admin.audit.invalidate()]); }} /></td></tr>}</Fragment>)}{memberQueryEnabled && !members.isLoading && !members.isFetching && !members.error && !memberRows.length && <tr><td colSpan={11} className="admin-empty">Chưa có hội viên trong bộ lọc.</td></tr>}</tbody>
            </table></div>
            {monthlyEditor && <MemberMonthEditor key={`${monthlyEditor.memberId}:${monthlyEditor.month}`} seed={monthlyEditor} mutation={saveMemberMonth} onCancel={() => setMonthlyEditor(null)} />}

          </section>}

          {activeTab === "audit" && <section className="admin-card"><div className="admin-card-head"><div><h2>Nhật ký quản trị</h2><p>Hiển thị tối đa 120 thao tác mới nhất; thông tin tài khoản ngân hàng không ghi đầy đủ vào nhật ký.</p></div></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Ngày giờ</th><th>Người thao tác</th><th>Hành động</th><th>Đối tượng</th><th>Chi tiết</th></tr></thead><tbody>{audit.data?.map((row) => <tr key={row.id}><td>{vietnamDateTime.format(row.createdAt)}</td><td>{row.actorName || row.actorEmail || `ID ${row.actorUserId ?? "system"}`}</td><td><code>{row.action}</code></td><td>{row.entityType} #{row.entityId ?? "—"}</td><td><pre className="audit-details">{row.details || "—"}</pre></td></tr>)}{!audit.data?.length && <tr><td colSpan={5} className="admin-empty">Chưa có thao tác được ghi nhận.</td></tr>}</tbody></table></div></section>}
          <AdminPasswordResetDialog agency={passwordAgency} onClose={() => setPasswordAgency(null)} onUpdated={refresh} />
        </section>
      </div>
    </main>
  );
}

function MemberMonthEditor({ seed, mutation, onCancel }: {
  seed: MonthlyEditorSeed;
  mutation: ReturnType<typeof trpc.admin.saveMemberMonth.useMutation>;
  onCancel: () => void;
}) {
  const [values, setValues] = useState({
    totalDeposit: vndToPointInput(seed.expected.totalDepositVnd),
    totalWithdrawal: vndToPointInput(seed.expected.totalWithdrawalVnd),
    totalBets: vndToPointInput(seed.expected.totalBetsVnd),
    totalPromotion: vndToPointInput(seed.expected.totalPromotionVnd),
  });
  const [reason, setReason] = useState("");
  const [editorError, setEditorError] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (mutation.isPending) return;
    const totalDepositVnd = pointsToVnd(values.totalDeposit);
    const totalWithdrawalVnd = pointsToVnd(values.totalWithdrawal);
    const totalBetsVnd = pointsToVnd(values.totalBets);
    const totalPromotionVnd = pointsToVnd(values.totalPromotion);
    if (totalDepositVnd === null || totalWithdrawalVnd === null || totalBetsVnd === null || totalPromotionVnd === null || totalDepositVnd < 0 || totalWithdrawalVnd < 0 || totalBetsVnd < 0 || totalPromotionVnd < 0) {
      setEditorError("Bốn tổng phải là số điểm không âm hợp lệ, tối đa 3 số thập phân và không vượt giới hạn lưu trữ.");
      return;
    }
    const cleanReason = reason.trim();
    if (cleanReason.length < 3 || cleanReason.length > 500) {
      setEditorError("Nhập lý do từ 3 đến 500 ký tự.");
      return;
    }
    setEditorError("");
    if (!window.confirm(`Xác nhận sửa tổng tháng cho @${seed.username} (đại lý @${seed.agencyUsername}) tháng ${seed.month}: Tổng nạp ${money.format(totalDepositVnd)}, Tổng rút ${money.format(totalWithdrawalVnd)}, Tổng cược ${money.format(totalBetsVnd)}, Tổng khuyến mãi ${money.format(totalPromotionVnd)}? Lý do: “${cleanReason}”`)) return;
    mutation.mutate({
      memberId: seed.memberId,
      month: seed.month,
      totalDepositVnd,
      totalWithdrawalVnd,
      totalBetsVnd,
      totalPromotionVnd,
      reason: cleanReason,
      expected: seed.expected,
    });
  }

  return <form className="admin-month-editor" onSubmit={submit}>
    <div className="admin-record-title"><div><b>Sửa tổng tháng · @{seed.username}</b><small>Đại lý: @{seed.agencyUsername} · {seed.agencyName || "chưa có tên"} · Tháng cố định: {seed.month}</small><small>Lịch sử giao dịch gốc giữ nguyên; sửa báo cáo sẽ tạo nhật ký. Nếu dữ liệu đã đổi, thao tác sẽ bị từ chối để tránh ghi đè.</small></div><button type="button" disabled={mutation.isPending} onClick={onCancel}>Hủy</button></div>
    <div className="admin-month-editor-fields">
      <label><span>Tổng nạp (điểm)</span><input required type="text" inputMode="decimal" disabled={mutation.isPending} value={values.totalDeposit} onChange={(event) => setValues({ ...values, totalDeposit: event.target.value })} onBlur={() => setValues((current) => ({ ...current, totalDeposit: formatPointInput(current.totalDeposit) }))} /></label>
      <label><span>Tổng rút (điểm)</span><input required type="text" inputMode="decimal" disabled={mutation.isPending} value={values.totalWithdrawal} onChange={(event) => setValues({ ...values, totalWithdrawal: event.target.value })} onBlur={() => setValues((current) => ({ ...current, totalWithdrawal: formatPointInput(current.totalWithdrawal) }))} /></label>
      <label><span>Tổng cược (điểm)</span><input required type="text" inputMode="decimal" disabled={mutation.isPending} value={values.totalBets} onChange={(event) => setValues({ ...values, totalBets: event.target.value })} onBlur={() => setValues((current) => ({ ...current, totalBets: formatPointInput(current.totalBets) }))} /></label>
      <label><span>Tổng khuyến mãi (điểm)</span><input required type="text" inputMode="decimal" disabled={mutation.isPending} value={values.totalPromotion} onChange={(event) => setValues({ ...values, totalPromotion: event.target.value })} onBlur={() => setValues((current) => ({ ...current, totalPromotion: formatPointInput(current.totalPromotion) }))} /></label>
      <label className="admin-month-editor-reason"><span>Lý do (3–500 ký tự)</span><textarea aria-label="Lý do (3–500 ký tự)" required minLength={3} maxLength={500} disabled={mutation.isPending} value={reason} onChange={(event) => setReason(event.target.value)} /></label>
      <button type="submit" className="admin-primary-button" disabled={mutation.isPending}>{mutation.isPending ? "Đang lưu…" : "Xác nhận sửa tổng tháng"}</button>
    </div>
    {editorError && <p className="admin-error" role="alert">{editorError}</p>}
  </form>;
}

type MemberTransactionRowData = { id: number; kind: "deposit" | "withdrawal"; amountVnd: number; occurredAt: Date; note: string | null };

function MemberTransactionHistory({ memberId, username, month, onUpdated }: { memberId: number; username: string; month: string; onUpdated: () => void }) {
  const transactions = trpc.admin.memberTransactions.useQuery({ memberId, month });
  return <section className="admin-transaction-history" aria-label={`Giao dịch tháng ${month} của ${username}`}>
    <div className="admin-transaction-history-head"><b>Lịch sử nạp/rút · @{username} · {month}</b><small>Chỉ sửa số tiền của đúng giao dịch; loại, ngày giờ và lịch sử kiểm toán được giữ.</small></div>
    {transactions.isLoading ? <p className="admin-transaction-history-state">Đang tải giao dịch…</p> : transactions.error ? <p className="admin-transaction-history-state admin-empty-error" role="alert">Không tải được lịch sử: {transactions.error.message}</p> : !transactions.data?.length ? <p className="admin-transaction-history-state">Không có giao dịch nạp/rút trong tháng này.</p> : <div className="admin-table-wrap"><table className="admin-table admin-transaction-history-table">
      <thead><tr><th>Loại</th><th>Ngày giờ</th><th>Số tiền hiện tại</th><th>Số tiền mới</th><th>Thao tác</th></tr></thead>
      <tbody>{transactions.data.map((transaction) => <MemberTransactionAmountEditor key={`${transaction.id}:${transaction.amountVnd}`} transaction={transaction} username={username} onUpdated={onUpdated} />)}</tbody>
    </table></div>}
  </section>;
}

function MemberTransactionAmountEditor({ transaction, username, onUpdated }: { transaction: MemberTransactionRowData; username: string; onUpdated: () => void }) {
  const [amount, setAmount] = useState(vndToPointInput(transaction.amountVnd));
  const [error, setError] = useState("");
  const save = trpc.admin.updateMemberTransaction.useMutation({ onSuccess: () => { setError(""); onUpdated(); }, onError: (e) => setError(e.message) });
  const amountVnd = pointsToVnd(amount);
  const label = transaction.kind === "deposit" ? "nạp" : "rút";
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (save.isPending) return;
    if (amountVnd === null || amountVnd <= 0) { setError("Số tiền mới phải là số điểm dương hợp lệ, tối đa 3 số thập phân."); return; }
    if (amountVnd === transaction.amountVnd) { setError("Số tiền chưa thay đổi."); return; }
    if (!window.confirm(`Sửa giao dịch ${label} của @${username} ngày ${vietnamDateTime.format(transaction.occurredAt)} từ ${formatPointEquivalent(transaction.amountVnd)} thành ${formatPointEquivalent(amountVnd)}? Lịch sử thay đổi sẽ được ghi nhật ký.`)) return;
    setError("");
    save.mutate({ transactionId: transaction.id, amountVnd });
  }
  return <tr>
    <td>{transaction.kind === "deposit" ? "Nạp" : "Rút"}</td>
    <td>{vietnamDateTime.format(transaction.occurredAt)}{transaction.note && <small>{transaction.note}</small>}</td>
    <td className="admin-member-money">{formatPointEquivalent(transaction.amountVnd)}</td>
    <td><form className="admin-transaction-edit-form" onSubmit={submit}><input required type="text" inputMode="decimal" aria-label={`Số tiền mới ${label} ${transaction.id}`} value={amount} disabled={save.isPending} onChange={(event) => { setAmount(event.target.value); setError(""); }} onBlur={() => setAmount(formatPointInput(amount))} /><small>{POINT_RATE_TEXT}</small></form>{error && <small className="admin-inline-error" role="alert">{error}</small>}</td>
    <td><button type="button" className="action-edit" disabled={save.isPending || amountVnd === null || amountVnd <= 0 || amountVnd === transaction.amountVnd} onClick={(event) => { const form = event.currentTarget.closest("tr")?.querySelector("form"); if (form instanceof HTMLFormElement) form.requestSubmit(); }}>{save.isPending ? "Đang lưu…" : "Lưu sửa"}</button></td>
  </tr>;
}

function ReferralLinkForm({ agencyId, value, updateReferral }: { agencyId: number; value: string; updateReferral: ReturnType<typeof trpc.admin.updateReferralLink.useMutation> }) {
  const [link, setLink] = useState(value);
  return <form className="referral-edit-form" onSubmit={(event) => { event.preventDefault(); if (!link.trim()) return; if (!window.confirm("Cập nhật liên kết giới thiệu HTTPS cho đại lý này?")) return; updateReferral.mutate({ agencyId, referralLink: link.trim() }); }}><input type="url" required value={link} onChange={(event) => setLink(event.target.value)} placeholder="https://…" /><button type="submit" disabled={updateReferral.isPending || link.trim() === value}>Lưu</button></form>;
}

function BalanceCreditForm({ agencyId, agencyName, addBalance }: { agencyId: number; agencyName: string; addBalance: ReturnType<typeof trpc.admin.addBalanceCredit.useMutation> }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const amountVnd = pointsToVnd(amount);
  return <div className="credit-form-wrap">
    <button type="button" className="action-credit" onClick={() => setOpen((current) => !current)}><Plus size={13} /> Cộng số dư</button>
    {open && <form className="credit-mini-form" onSubmit={(event) => {
      event.preventDefault();
      if (amountVnd === null || amountVnd <= 0 || reason.trim().length < 3) { setError("Nhập số điểm dương hợp lệ và lý do ít nhất 3 ký tự."); return; }
      if (!window.confirm(`Cộng ${formatPointEquivalent(amountVnd)} cho đại lý @${agencyName} với lý do “${reason.trim()}”?`)) return;
      addBalance.mutate({ agencyId, amountVnd, reason: reason.trim() }, { onSuccess: () => { setOpen(false); setAmount(""); setReason(""); setError(""); } });
    }}>
      <input required type="text" inputMode="decimal" aria-label="Số điểm cộng" placeholder="Số điểm, ví dụ: 1,000" value={amount} onChange={(event) => { setAmount(event.target.value); setError(""); }} onBlur={() => setAmount(formatPointInput(amount))} />
      <small>{POINT_RATE_TEXT}{amountVnd !== null ? ` · ${formatPointEquivalent(amountVnd)}` : ""}</small>
      <input required minLength={3} maxLength={500} placeholder="Lý do bắt buộc" value={reason} onChange={(event) => setReason(event.target.value)} />
      {error && <small role="alert">{error}</small>}
      <button type="submit" disabled={addBalance.isPending}>Xác nhận cộng</button>
    </form>}
  </div>;
}
