export const SETTLEMENT_DEADLINE = new Date("2026-12-01T00:00:00+07:00").getTime();

export function currentVietnamMonth(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit",
  }).formatToParts(now);
  return `${parts.find((part) => part.type === "year")!.value}-${parts.find((part) => part.type === "month")!.value}`;
}

export function getSettlementCountdown(now: number) {
  const left = Math.max(0, SETTLEMENT_DEADLINE - now);
  const days = Math.floor(left / 86_400_000);
  const hours = Math.floor((left % 86_400_000) / 3_600_000);
  const minutes = Math.floor((left % 3_600_000) / 60_000);
  const seconds = Math.floor((left % 60_000) / 1_000);
  return `${days} ngày ${[hours, minutes, seconds].map((part) => String(part).padStart(2, "0")).join(":")}`;
}
