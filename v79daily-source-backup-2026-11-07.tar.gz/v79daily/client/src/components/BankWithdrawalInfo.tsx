import { useState, type FormEvent } from "react";
import { Building2, CircleHelp, Landmark, LoaderCircle, Plus, UserRound, WalletCards, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { formatPointInput, formatVnd, pointMoney, pointsToVnd } from "@shared/money";
import { formatWithdrawalMinimum, withdrawalMinimumMessage, withdrawalMinimumVnd, type WithdrawalDestination } from "@shared/withdrawal-limits";
import UsdtWalletInfo from "@/components/UsdtWalletInfo";
import PayoutIcon from "@/components/PayoutIcon";

const money = pointMoney;
const emptyForm = { ownerName: "", accountNumber: "", bankName: "", branch: "" };

function displayStatus(status: "pending" | "approved" | "rejected") {
  if (status === "approved") return "Đã duyệt";
  if (status === "rejected") return "Từ chối";
  return "Chờ duyệt";
}

export default function BankWithdrawalInfo() {
  const utils = trpc.useUtils();
  const banks = trpc.agent.bankAccounts.useQuery(undefined, { refetchOnWindowFocus: false });
  const wallets = trpc.agent.walletAccounts.useQuery(undefined, { refetchOnWindowFocus: false });
  const history = trpc.agent.withdrawals.useQuery(undefined, { refetchOnWindowFocus: false });
  const overview = trpc.agent.overview.useQuery(undefined, { refetchInterval: 30_000 });
  const [form, setForm] = useState(emptyForm);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [bankAccountId, setBankAccountId] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const addBank = trpc.agent.addBankAccount.useMutation({
    onSuccess: async () => {
      await utils.agent.bankAccounts.invalidate();
      setForm(emptyForm);
      setIsModalOpen(false);
      setError("");
      setMessage("Đã lưu thông tin ngân hàng vào hồ sơ của bạn.");
    },
    onError: (mutationError) => setError(mutationError.message),
  });
  const createWithdrawal = trpc.agent.createWithdrawal.useMutation({
    onSuccess: async () => {
      await Promise.all([utils.agent.withdrawals.invalidate(), utils.agent.overview.invalidate()]);
      setAmount("");
      setError("");
      setMessage("Đơn rút đã được ghi nhận và đang chờ quản trị viên duyệt.");
    },
    onError: (mutationError) => setError(mutationError.message),
  });

  function saveBank(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setMessage("");
    addBank.mutate({
      ownerName: form.ownerName.trim(),
      accountNumber: form.accountNumber.trim(),
      bankName: form.bankName.trim(),
      branch: form.branch.trim(),
    });
  }

  function submitWithdrawal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (createWithdrawal.isPending) return;
    setError("");
    setMessage("");
    const parsedAmount = pointsToVnd(amount);
    if (parsedAmount === null || parsedAmount <= 0 || (!selectedBank && !selectedWallet)) {
      setError("Nhập số điểm dương hợp lệ (dấu phẩy hàng nghìn, tối đa 3 số thập phân) và chọn ngân hàng hoặc ví USDT.");
      return;
    }
    const destination: WithdrawalDestination = selectedWallet ? "usdt" : "bank";
    if (parsedAmount < withdrawalMinimumVnd(destination)) {
      setError(withdrawalMinimumMessage(destination));
      return;
    }
    if (parsedAmount > available) { setError("Số điểm rút vượt số dư khả dụng."); return; }
    createWithdrawal.mutate(selectedWallet ? { walletAccountId: selectedWallet.id, amountVnd: parsedAmount } : { bankAccountId: selectedBank!.id, amountVnd: parsedAmount });
  }

  const accountRows = banks.data ?? [];
  const walletRows = wallets.data ?? [];
  const selectedWallet = bankAccountId.startsWith("wallet:") ? walletRows.find((wallet) => wallet.id === Number(bankAccountId.slice(7))) : undefined;
  const selectedBank = !bankAccountId.startsWith("wallet:") ? accountRows.find((bank) => bank.id === Number(bankAccountId)) : undefined;
  const hasDestinations = accountRows.length > 0 || walletRows.length > 0;
  const withdrawalRows = history.data ?? [];
  const available = overview.data?.availableVnd ?? 0;
  const withdrawalAmountVnd = pointsToVnd(amount);
  const destination: WithdrawalDestination | null = selectedWallet ? "usdt" : selectedBank ? "bank" : null;
  const minimumVnd = destination ? withdrawalMinimumVnd(destination) : null;
  const minimumMessage = destination ? withdrawalMinimumMessage(destination) : "";
  const belowMinimum = withdrawalAmountVnd !== null && minimumVnd !== null && withdrawalAmountVnd > 0 && withdrawalAmountVnd < minimumVnd;

  return (
    <section className="bank-info-page" aria-labelledby="bank-info-title">
      <header className="bank-info-header">
        <div>
          <h1 id="bank-info-title">THÔNG TIN NHẬN HOA HỒNG</h1>
        </div>
        <button className="bank-add-button" type="button" onClick={() => { setIsModalOpen(true); setError(""); }}>
          <Plus size={16} /> Thêm Ngân hàng
        </button>
      </header>

      <section className="bank-info-card" aria-label="Danh sách thông tin nhận hoa hồng">
        <div className="bank-card-title"><PayoutIcon type="bank" /><div><b>Thông tin nhận hoa hồng</b></div></div>
        <div className="bank-table-wrap"><table className="bank-info-table">
          <thead><tr><th>Họ và tên</th><th>Số tài khoản</th><th>Ngân hàng</th><th>Chi nhánh</th></tr></thead>
          <tbody>
            {banks.isLoading ? <tr><td colSpan={4}><div className="bank-empty-state"><LoaderCircle className="auth-spin" size={21} /><span>Đang tải thông tin…</span></div></td></tr>
              : accountRows.length === 0 ? <tr><td colSpan={4}><div className="bank-empty-state"><WalletCards size={23} /><b>Chưa có thông tin ngân hàng</b><span>Chọn “Thêm Ngân hàng” để lưu tài khoản nhận hoa hồng.</span></div></td></tr>
              : accountRows.map((bank) => <tr key={bank.id}><td>{bank.ownerName}</td><td className="bank-account-number">{bank.accountNumber}</td><td>{bank.bankName}</td><td>{bank.branch}</td></tr>)}
          </tbody>
        </table></div>
      </section>

      <UsdtWalletInfo />

      <section className="withdrawal-card" aria-labelledby="withdrawal-title">
        <div className="withdrawal-section-heading"><PayoutIcon type="withdrawal" /><div><h2 id="withdrawal-title">RÚT HOA HỒNG</h2><p>Số dư khả dụng: <b>{money.format(available)}</b></p></div></div>
        <form className="withdrawal-form" onSubmit={submitWithdrawal}>
          <label htmlFor="withdrawal-amount"><span>Số điểm rút</span><div className="withdrawal-input-wrap"><input id="withdrawal-amount" type="text" inputMode="decimal" required value={amount} onChange={(event) => { setAmount(event.target.value); setError(""); setMessage(""); }} onBlur={() => setAmount(formatPointInput(amount))} placeholder="Ví dụ: 1,000" /><span>điểm</span></div></label>
          <label htmlFor="withdrawal-bank"><span>Ngân hàng / Ví USDT</span><select id="withdrawal-bank" required disabled={!hasDestinations || createWithdrawal.isPending} value={bankAccountId} onChange={(event) => { setBankAccountId(event.target.value); setError(""); setMessage(""); }}>
            {!hasDestinations ? <option value="">Thêm ngân hàng hoặc ví USDT trước</option> : <option value="" disabled>Chọn ngân hàng hoặc ví nhận</option>}
            {accountRows.length > 0 && <optgroup label="Ngân hàng">{accountRows.map((bank) => <option key={bank.id} value={bank.id}>{bank.bankName} · {bank.accountNumber}</option>)}</optgroup>}
            {walletRows.length > 0 && <optgroup label="Ví USDT">{walletRows.map((wallet) => <option key={wallet.id} value={`wallet:${wallet.id}`}>USDT ({wallet.network}) · {wallet.address}</option>)}</optgroup>}
          </select></label>
          <button className="withdrawal-submit-button" type="submit" disabled={createWithdrawal.isPending || (!selectedBank && !selectedWallet) || withdrawalAmountVnd === null || withdrawalAmountVnd <= 0 || belowMinimum || withdrawalAmountVnd > available}>
            {createWithdrawal.isPending ? <LoaderCircle className="auth-spin" size={15} /> : <Plus size={15} />} Tạo đơn rút
          </button>
        </form>
        {destination && <p className="withdrawal-minimum-hint">Mức tối thiểu cho {destination === "bank" ? "ngân hàng" : "ví USDT"}: {formatWithdrawalMinimum(destination)}.</p>}
        {belowMinimum && !error && <p className="withdrawal-error" role="alert">{minimumMessage}</p>}
        {error && <p className="withdrawal-error" role="alert">{error}</p>}
        {message && <p className="withdrawal-confirmation" role="status"><CircleHelp size={15} />{message}</p>}
      </section>

      <section className="withdrawal-history-card" aria-labelledby="withdrawal-history-title">
        <div className="withdrawal-section-heading history-heading"><span className="withdrawal-section-icon history-icon"><Landmark size={16} /></span><div><h2 id="withdrawal-history-title">LỊCH SỬ RÚT TIỀN</h2><p>Trạng thái được cập nhật trong hồ sơ đại lý.</p></div></div>
        <div className="bank-table-wrap"><table className="withdrawal-history-table">
          <thead><tr><th>Ngày giờ rút</th><th>Số điểm rút</th><th>Ngân hàng / Ví nhận</th><th>Trạng thái</th></tr></thead>
          <tbody>
            {history.isLoading ? <tr><td colSpan={4} className="history-empty-state">Đang tải lịch sử…</td></tr>
              : withdrawalRows.length === 0 ? <tr><td colSpan={4} className="history-empty-state">Chưa có lịch sử rút tiền.</td></tr>
              : withdrawalRows.map((record) => <tr key={record.id}>
                <td>{new Intl.DateTimeFormat("vi-VN", { timeZone: "Asia/Ho_Chi_Minh", dateStyle: "short", timeStyle: "short" }).format(record.requestedAt)}</td>
                <td className="history-amount">{money.format(record.amountVnd)}<small className="history-account-number">{formatVnd(record.amountVnd)}</small></td>
                <td><span className="history-bank-name">{record.destinationType === "usdt" ? `USDT (${record.walletNetwork})` : record.bankName}</span><small className="history-account-number">{record.destinationType === "usdt" ? record.walletAddress : record.accountNumber} · {record.ownerName}</small></td>
                <td><span className={`history-status history-status-${record.status}`}>{displayStatus(record.status)}</span>{record.decisionNote && <small className="history-decision-note">{record.decisionNote}</small>}</td>
              </tr>)}
          </tbody>
        </table></div>
      </section>

      {isModalOpen && <div className="bank-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setIsModalOpen(false); }}>
        <section className="bank-modal" role="dialog" aria-modal="true" aria-labelledby="bank-modal-title">
          <header className="bank-modal-header"><PayoutIcon type="bank" size={36} /><div><h2 id="bank-modal-title">Thêm Ngân hàng</h2><p>Lưu thông tin nhận hoa hồng vào tài khoản đại lý.</p></div><button className="bank-modal-close" type="button" aria-label="Đóng" onClick={() => setIsModalOpen(false)}><X size={18} /></button></header>
          <form className="bank-modal-form" autoComplete="off" onSubmit={saveBank}>
            <label><span><UserRound size={14} /> Họ và tên</span><input required maxLength={200} value={form.ownerName} onChange={(event) => setForm((current) => ({ ...current, ownerName: event.target.value }))} placeholder="Nhập họ và tên chủ tài khoản" /></label>
            <label><span><WalletCards size={14} /> Số tài khoản</span><input required maxLength={64} inputMode="numeric" value={form.accountNumber} onChange={(event) => setForm((current) => ({ ...current, accountNumber: event.target.value }))} placeholder="Nhập số tài khoản" /></label>
            <label><span><Landmark size={14} /> Ngân hàng</span><input required maxLength={120} value={form.bankName} onChange={(event) => setForm((current) => ({ ...current, bankName: event.target.value }))} placeholder="Nhập tên ngân hàng" /></label>
            <label><span><Building2 size={14} /> Chi nhánh</span><input required maxLength={200} value={form.branch} onChange={(event) => setForm((current) => ({ ...current, branch: event.target.value }))} placeholder="Nhập chi nhánh" /></label>
            {error && <p className="withdrawal-error" role="alert">{error}</p>}
            <p className="bank-modal-privacy"><CircleHelp size={14} /> Thông tin được lưu trong cơ sở dữ liệu của cổng và hiển thị cho quản trị viên để xét duyệt lệnh rút.</p>
            <div className="bank-modal-actions"><button type="button" className="bank-cancel-button" onClick={() => setIsModalOpen(false)}>Hủy</button><button type="submit" className="bank-save-button" disabled={addBank.isPending}>{addBank.isPending ? "Đang lưu…" : "Lưu thông tin"}</button></div>
          </form>
        </section>
      </div>}
    </section>
  );
}
