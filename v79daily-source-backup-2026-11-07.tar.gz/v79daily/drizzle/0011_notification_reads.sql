CREATE TABLE `agency_notification_reads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`event_key` varchar(80) NOT NULL,
	`read_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `agency_notification_reads_id` PRIMARY KEY(`id`),
	CONSTRAINT `agency_notification_reads_agency_event_uq` UNIQUE(`agency_id`,`event_key`)
);
--> statement-breakpoint
ALTER TABLE `agency_notification_reads` ADD CONSTRAINT `agency_notification_reads_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE cascade ON UPDATE no action;