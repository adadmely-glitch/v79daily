import { useEffect, useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { V79_LOGO_SRC } from "@/brand";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import "@/styles/auth.css";
import {
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  Eye,
  EyeOff,
  LoaderCircle,
  LockKeyhole,
  Mail,
  Phone,
  ShieldCheck,
  UserPlus,
  UserRound,
} from "lucide-react";

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Không thể hoàn tất yêu cầu. Vui lòng thử lại.";
}

function PendingTelegramMessage() {
  return <small className="auth-pending-telegram">VUI LÒNG LIÊN HỆ TELEGRAM ĐẠI LÝ <a href="https://t.me/dailyv79/" target="_blank" rel="noopener noreferrer">@DAILYV79</a> ĐỂ DUYỆT HỒ SƠ</small>;
}

export default function Login() {
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [registerMode, setRegisterMode] = useState(false);
  const [registrationComplete, setRegistrationComplete] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ username: "", phone: "", fullName: "", email: "", password: "", confirmPassword: "" });

  useEffect(() => {
    if (auth.user?.role === "admin") setLocation("/admin");
  }, [auth.user?.role, setLocation]);

  const registrationQuery = trpc.registration.status.useQuery(undefined, {
    enabled: auth.isAuthenticated && auth.user?.role !== "admin" && auth.user?.loginMethod === "password",
    retry: false,
  });
  const loginMutation = trpc.auth.loginWithPassword.useMutation({
    onSuccess: async (result) => {
      setError("");
      await Promise.all([utils.auth.me.invalidate(), utils.registration.status.invalidate()]);
      if (result.status === "approved") setLocation("/dashboard");
    },
    onError: (mutationError) => setError(errorMessage(mutationError)),
  });
  const registerMutation = trpc.registration.submit.useMutation({
    onSuccess: () => {
      setRegistrationComplete(true);
      setRegisterMode(false);
      setError("");
      setForm({ username: "", phone: "", fullName: "", email: "", password: "", confirmPassword: "" });
    },
    onError: (mutationError) => setError(errorMessage(mutationError)),
  });

  function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    loginMutation.mutate({ username, password });
  }

  async function submitRegistration(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (form.password !== form.confirmPassword) {
      setError("Mật khẩu xác nhận không khớp.");
      return;
    }
    try {
      await registerMutation.mutateAsync({
        username: form.username,
        phone: form.phone,
        fullName: form.fullName,
        email: form.email,
        password: form.password,
      });
    } catch {
      // Mutation error is rendered below without exposing submitted details.
    }
  }

  const profile = registrationQuery.data;
  const registrationError = registrationQuery.error;
  const isPasswordAccount = auth.user?.loginMethod === "password";

  return (
    <main className="login-screen">
      <section className="login-card" aria-label="Đăng nhập V79 Đại lý">
        <div className="login-brand-panel">
          <div className="login-orb login-orb-top" />
          <div className="login-orb login-orb-bottom" />
          <div className="login-streak streak-one" />
          <div className="login-streak streak-two" />
          <div className="login-streak streak-three" />
          <div className="login-streak streak-four" />
          <div className="brand-copy">
            <a className="login-wordmark" href="/" aria-label="V79 Đại lý">
              <img className="login-logo-image" src={V79_LOGO_SRC} alt="V79" />
            </a>
            <p>Hệ thống quản lý đầu cuối dành cho Đại lý</p>
          </div>
          <div className="brand-footnote"><span className="brand-footnote-dot" /> CỔNG THÔNG TIN ĐẠI LÝ</div>
        </div>

        <div className="login-form-panel">
          <div className="login-content">
            <div className="mobile-wordmark"><img src={V79_LOGO_SRC} alt="V79" /><small>ĐẠI LÝ</small></div>
            <h1>{registerMode ? "Đăng Ký Đại Lý" : "Đăng Nhập"}</h1>
            <p className="login-subtitle">{registerMode ? "Gửi thông tin để quản trị viên xét duyệt" : "Truy cập khu vực quản lý đại lý"}</p>

            {auth.loading ? (
              <div className="auth-status-card" role="status"><LoaderCircle className="auth-spin" size={20} /> Đang xác minh phiên đăng nhập…</div>
            ) : auth.isAuthenticated && auth.user?.role === "admin" ? (
              <div className="auth-status-card auth-admin-card"><ShieldCheck size={23} /><div><b>Đang chuyển đến khu quản trị…</b><span>Quyền admin được xác minh phía máy chủ.</span></div></div>
            ) : auth.isAuthenticated && !isPasswordAccount ? (
              <div className="auth-status-card auth-error-card">
                <ShieldCheck size={23} />
                <div><b>Phiên này không phải tài khoản đại lý</b><span>Đăng xuất khỏi phiên quản trị rồi dùng Tên đăng nhập và Mật khẩu đại lý.</span></div>
                <button type="button" className="auth-secondary-action" onClick={() => void auth.logout()}>Đăng xuất</button>
              </div>
            ) : auth.isAuthenticated && registrationQuery.isLoading ? (
              <div className="auth-status-card" role="status"><LoaderCircle className="auth-spin" size={20} /> Đang kiểm tra hồ sơ đại lý…</div>
            ) : auth.isAuthenticated && registrationError ? (
              <div className="auth-status-card auth-error-card" role="alert">Không thể tải hồ sơ. Hãy thử tải lại trang.</div>
            ) : auth.isAuthenticated && profile?.status === "approved" ? (
              <div className="auth-status-card auth-approved-card">
                <CheckCircle2 size={23} />
                <div><b>Hồ sơ đại lý đã được duyệt</b><span>{profile.fullName} · @{profile.username}</span></div>
                <button type="button" onClick={() => setLocation("/dashboard")}>Mở cổng đại lý <ArrowRight size={15} /></button>
                <button type="button" className="auth-secondary-action" onClick={() => void auth.logout()}>Đăng xuất</button>
              </div>
            ) : auth.isAuthenticated && profile ? (
              <div className={`auth-status-card ${profile.status === "pending" ? "auth-pending-card" : "auth-error-card"}`}>
                <ShieldCheck size={23} />
                <div><b>{profile.status === "pending" ? "Hồ sơ đang chờ duyệt" : profile.status === "locked" ? "Tài khoản đang khóa" : "Hồ sơ chưa được duyệt"}</b><span>{profile.fullName} · @{profile.username}</span>{profile.status === "pending" ? <PendingTelegramMessage /> : <small>Liên hệ quản trị viên để biết thêm thông tin.</small>}</div>
                <button type="button" className="auth-secondary-action" onClick={() => void auth.logout()}>Đăng xuất</button>
              </div>
            ) : auth.isAuthenticated ? (
              <div className="auth-status-card auth-error-card"><ShieldCheck size={23} /><div><b>Chưa có hồ sơ đại lý</b><span>Đăng xuất để đăng nhập bằng tài khoản đại lý.</span></div><button type="button" className="auth-secondary-action" onClick={() => void auth.logout()}>Đăng xuất</button></div>
            ) : registrationComplete ? (
              <div className="auth-status-card auth-pending-card"><CheckCircle2 size={23} /><div><b>Đã gửi hồ sơ đăng ký</b><PendingTelegramMessage /><small>Sau khi được duyệt, bạn đăng nhập bằng Tên đăng nhập và Mật khẩu đã tạo.</small></div><button type="button" onClick={() => { setRegistrationComplete(false); setRegisterMode(false); }}>Về đăng nhập</button></div>
            ) : registerMode ? (
              <form className="login-form registration-form" onSubmit={submitRegistration}>
                <label className="login-input-wrap"><UserRound size={18} aria-hidden="true" /><input required minLength={3} maxLength={32} pattern="[A-Za-z0-9._-]+" autoComplete="username" placeholder="Tên đăng nhập" value={form.username} onChange={(event) => { setForm((current) => ({ ...current, username: event.target.value })); setError(""); }} /></label>
                <label className="login-input-wrap"><Phone size={17} aria-hidden="true" /><input required minLength={7} maxLength={32} autoComplete="tel" type="tel" placeholder="Số điện thoại" value={form.phone} onChange={(event) => { setForm((current) => ({ ...current, phone: event.target.value })); setError(""); }} /></label>
                <label className="login-input-wrap"><UserPlus size={17} aria-hidden="true" /><input required minLength={2} maxLength={120} autoComplete="name" placeholder="Họ tên" value={form.fullName} onChange={(event) => { setForm((current) => ({ ...current, fullName: event.target.value })); setError(""); }} /></label>
                <label className="login-input-wrap"><Mail size={17} aria-hidden="true" /><input required type="email" maxLength={320} autoComplete="email" placeholder="Gmail" value={form.email} onChange={(event) => { setForm((current) => ({ ...current, email: event.target.value })); setError(""); }} /></label>
                <label className="login-input-wrap"><LockKeyhole size={17} aria-hidden="true" /><input required minLength={8} maxLength={128} autoComplete="new-password" type={showPassword ? "text" : "password"} placeholder="Mật khẩu (ít nhất 8 ký tự)" value={form.password} onChange={(event) => { setForm((current) => ({ ...current, password: event.target.value })); setError(""); }} /><button className="password-toggle" type="button" aria-label={showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"} onClick={() => setShowPassword((value) => !value)}>{showPassword ? <Eye size={18} /> : <EyeOff size={18} />}</button></label>
                <label className="login-input-wrap"><LockKeyhole size={17} aria-hidden="true" /><input required minLength={8} maxLength={128} autoComplete="new-password" type={showPassword ? "text" : "password"} placeholder="Xác nhận mật khẩu" value={form.confirmPassword} onChange={(event) => { setForm((current) => ({ ...current, confirmPassword: event.target.value })); setError(""); }} /></label>
                {error && <p className="login-error" role="alert">{error}</p>}
                <button className="login-submit" type="submit" disabled={registerMutation.isPending}>{registerMutation.isPending ? <LoaderCircle className="auth-spin" size={18} /> : <UserPlus size={18} />}<span>{registerMutation.isPending ? "Đang gửi hồ sơ…" : "Gửi hồ sơ đăng ký"}</span></button>
                <button className="oauth-back-button" type="button" onClick={() => { setRegisterMode(false); setError(""); }}>Quay lại đăng nhập</button>
              </form>
            ) : (
              <>
                <form className="login-form" onSubmit={handleLogin}>
                  <label className="login-input-wrap"><UserRound size={18} strokeWidth={2.5} aria-hidden="true" /><input required minLength={3} maxLength={32} autoComplete="username" placeholder="Xin Vui Lòng Nhập Tài Khoản" value={username} onChange={(event) => { setUsername(event.target.value); setError(""); }} /></label>
                  <label className="login-input-wrap"><LockKeyhole size={17} strokeWidth={2.5} aria-hidden="true" /><input required minLength={8} maxLength={128} autoComplete="current-password" placeholder="Xin Vui Lòng Nhập Mật Khẩu" type={showPassword ? "text" : "password"} value={password} onChange={(event) => { setPassword(event.target.value); setError(""); }} /><button className="password-toggle" type="button" aria-label={showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"} onClick={() => setShowPassword((value) => !value)}>{showPassword ? <Eye size={18} /> : <EyeOff size={18} />}</button></label>
                  {error && <p className="login-error" role="alert">{error}</p>}
                  <button className="login-submit" type="submit" disabled={loginMutation.isPending}>{loginMutation.isPending ? <LoaderCircle className="auth-spin" size={18} /> : <ArrowRight size={19} />}<span>{loginMutation.isPending ? "Đang đăng nhập…" : "Đăng Nhập"}</span></button>
                </form>
                <button className="register-entry-button" type="button" onClick={() => { setRegisterMode(true); setError(""); }}><UserPlus size={16} /> Đăng ký tài khoản đại lý</button>
                <button className="country-picker" type="button" aria-label="Quốc gia: Việt Nam"><span className="flag-vn" aria-hidden="true">★</span><span>Việt Nam</span><ChevronDown size={13} /></button>
              </>
            )}
          </div>
        </div>
      </section>
      <div className="login-copyright">V79 ĐẠI LÝ <span>•</span> CỔNG QUẢN LÝ ĐỐI TÁC</div>
    </main>
  );
}
