import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { agentRouter } from "./routers/agent";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
const dialect = new MySqlDialect();
function context(): TrpcContext {
  return { user: { id: 42, openId: "test", email: null, name: "Test", loginMethod: "password", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}
function fakeDb(resultSets: unknown[][]) {
  const queries: Array<{ fields: Record<string, unknown>; filters: SQL[]; joins: SQL[]; grouped: boolean }> = [];
  const db = { select: vi.fn((fields: Record<string, unknown> = {}) => {
    const result = resultSets.shift() ?? [];
    const entry = { fields, filters: [] as SQL[], joins: [] as SQL[], grouped: false };
    queries.push(entry);
    const chain: any = {
      from: () => chain, where: (filter: SQL) => { entry.filters.push(filter); return chain; },
      innerJoin: (_table: unknown, filter: SQL) => { entry.joins.push(filter); return chain; },
      groupBy: () => { entry.grouped = true; return chain; }, limit: () => chain,
      then: (resolve: (rows: unknown[]) => unknown) => Promise.resolve(result).then(resolve),
    };
    return chain;
  }) };
  mock.getDb.mockResolvedValue(db);
  return queries;
}
const sqlQuery = (query: SQL) => dialect.sqlToQuery(query);
const monthStart = "2026-09-30T17:00:00.000Z", monthEnd = "2026-10-31T17:00:00.000Z";
const members = [
  { id: 1, joinedAt: new Date("2026-01-01"), isValid: 1 },
  { id: 2, joinedAt: new Date(monthStart), isValid: 0 },
  { id: 3, joinedAt: new Date("2026-10-10"), isValid: 1 },
  { id: 4, joinedAt: new Date("2026-10-20"), isValid: 0 },
  { id: 5, joinedAt: new Date(monthEnd), isValid: 1 },
];
function completeResults(overrides: Partial<Record<"members" | "deposits" | "withdrawals" | "bets" | "adjustments" | "validity", unknown[]>> = {}): unknown[][] {
  return [
    [{ id: 37, status: "approved" }], overrides.members ?? members,
    overrides.deposits ?? [{ memberId: 1, total: "1000" }, { memberId: 2, total: "2000" }, { memberId: 5, total: "500" }],
    overrides.withdrawals ?? [{ memberId: 1, total: "400" }, { memberId: 2, total: "100" }, { memberId: 5, total: "50" }],
    overrides.bets ?? [{ memberId: 2, total: "9000", promotionTotal: "700", refundTotal: "200" }, { memberId: 3, total: "100", promotionTotal: "50", refundTotal: "500" }, { memberId: 5, total: "1000", promotionTotal: "10", refundTotal: "10" }],
    overrides.adjustments ?? [{ memberId: 2, depositDeltaVnd: "-100", withdrawalDeltaVnd: "25" }],
    overrides.validity ?? [{ memberId: 1, isValid: 1 }, { memberId: 2, isValid: 1 }, { memberId: 3, isValid: 0 }, { memberId: 4, isValid: 1 }],
  ];
}
beforeEach(() => vi.clearAllMocks());

describe("agent performance", () => {
  it("counts ALL agency members, new members within Vietnam boundaries and only selected month's validity marks", async () => {
    const queries = fakeDb(completeResults());
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).resolves.toEqual({
      activityMonth: "2026-10", memberCount: 5, validMemberCount: 3, newMemberCount: 3, newValidMemberCount: 2,
      totalDepositVnd: 3400, totalWithdrawalVnd: 575, totalBetsVnd: 10100, totalPromotionVnd: 760, totalRefundVnd: 710, totalWinLossVnd: -4295,
    });
    expect(queries).toHaveLength(7);
    expect(Object.keys(queries[1].fields).sort()).toEqual(["id", "joinedAt"]);
    expect(sqlQuery(queries[0].filters[0]).params).toEqual([42]);
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([37]);
    expect(sqlQuery(queries[1].filters[0]).sql).not.toContain("joined_at");
    for (const query of queries.slice(2, 6)) {
      expect(query.grouped).toBe(true); expect(query.joins).toHaveLength(0);
      expect(sqlQuery(query.filters[0]).params).toEqual(expect.arrayContaining([1, 2, 3, 4, 5]));
    }
    const deposit = sqlQuery(queries[2].filters[0]);
    expect(deposit.sql).toContain("`occurred_at` >= ?"); expect(deposit.sql).toContain("`occurred_at` < ?");
    expect(deposit.params.slice(6).map((v: any) => new Date(v).toISOString())).toEqual([monthStart, monthEnd]);
    expect(sqlQuery(queries[6].filters[0]).params).toEqual([1, 2, 3, 4, 5, "2026-10"]);
  });

  it("does not infer monthly validity from legacy flags when the month has no Admin marks", async () => {
    fakeDb(completeResults({ validity: [] }));
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).resolves.toMatchObject({ memberCount: 5, validMemberCount: 0, newMemberCount: 3, newValidMemberCount: 0 });
  });

  it("keeps total member count unchanged and monthly validity independent across months", async () => {
    fakeDb(completeResults({ validity: [{ memberId: 2, isValid: 1 }] }));
    const october = await agentRouter.createCaller(context()).performance({ month: "2026-10" });
    const queries = fakeDb(completeResults({ validity: [{ memberId: 1, isValid: 1 }, { memberId: 5, isValid: 1 }] }));
    const november = await agentRouter.createCaller(context()).performance({ month: "2026-11" });
    expect(october).toMatchObject({ memberCount: 5, validMemberCount: 1, newMemberCount: 3, newValidMemberCount: 1 });
    expect(november).toMatchObject({ memberCount: 5, validMemberCount: 2, newMemberCount: 1, newValidMemberCount: 1 });
    expect(sqlQuery(queries[6].filters[0]).params).toEqual([1, 2, 3, 4, 5, "2026-11"]);
  });

  it("keeps promotions independent from equal wager amounts and applies signed corrections", async () => {
    fakeDb(completeResults({
      bets: [{ memberId: 1, total: "100000", promotionTotal: "1234", refundTotal: "3000" }, { memberId: 2, total: "100000", promotionTotal: "5678", refundTotal: "4000" }],
      adjustments: [{ memberId: 1, depositDeltaVnd: "-100", withdrawalDeltaVnd: "25" }, { memberId: 2, depositDeltaVnd: "50", withdrawalDeltaVnd: "-10" }],
    }));
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).resolves.toMatchObject({ totalDepositVnd: 3450, totalWithdrawalVnd: 565, totalPromotionVnd: 6912, totalRefundVnd: 7000 });
  });

  it("returns zero for an empty agency without querying unrelated aggregates", async () => {
    const queries = fakeDb([[{ id: 37, status: "approved" }], []]);
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).resolves.toEqual({ activityMonth: "2026-10", memberCount: 0, validMemberCount: 0, newMemberCount: 0, newValidMemberCount: 0, totalDepositVnd: 0, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0, totalRefundVnd: 0, totalWinLossVnd: 0 });
    expect(queries).toHaveLength(2);
  });

  it.each(["deposit", "withdrawal", "wagers", "promotion", "refund", "correction"])("rejects unsafe %s totals across members rather than rounding", async (source) => {
    const max = "9007199254740991";
    const overrides: Parameters<typeof completeResults>[0] = { deposits: [], withdrawals: [], bets: [], adjustments: [] };
    if (source === "deposit") overrides.deposits = [{ memberId: 1, total: max }, { memberId: 2, total: max }];
    if (source === "withdrawal") overrides.withdrawals = [{ memberId: 1, total: max }, { memberId: 2, total: max }];
    if (source === "wagers") overrides.bets = [{ memberId: 1, total: max, promotionTotal: "0" }, { memberId: 2, total: max, promotionTotal: "0" }];
    if (source === "promotion") overrides.bets = [{ memberId: 1, total: "0", promotionTotal: max }, { memberId: 2, total: "0", promotionTotal: max }];
    if (source === "refund") overrides.bets = [{ memberId: 1, total: "0", promotionTotal: "0", refundTotal: max }, { memberId: 2, total: "0", promotionTotal: "0", refundTotal: max }];
    if (source === "correction") overrides.adjustments = [{ memberId: 1, depositDeltaVnd: max, withdrawalDeltaVnd: "0" }, { memberId: 2, depositDeltaVnd: max, withdrawalDeltaVnd: "0" }];
    fakeDb(completeResults(overrides));
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("does not trust a persisted win-loss value after the formula changes", async () => {
    fakeDb(completeResults({ deposits: [], withdrawals: [], adjustments: [], bets: [{ memberId: 1, total: "0", promotionTotal: "0", refundTotal: "0", netWinLossVnd: "9007199254740993" }] }));
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).resolves.toMatchObject({ totalWinLossVnd: 0 });
  });

  it("cannot change session-derived agency scope via cache keys", async () => {
    const results = [];
    for (const cacheKey of [undefined, 1, 999]) {
      const queries = fakeDb(completeResults());
      results.push(await agentRouter.createCaller(context()).performance({ month: "2026-10", cacheKey }));
      expect(sqlQuery(queries[1].filters[0]).params).toEqual([37]);
    }
    expect(results[0]).toEqual(results[1]); expect(results[1]).toEqual(results[2]);
  });

  it.each(["pending", "locked", "rejected"])("blocks a %s agency before any member query", async (status) => {
    const queries = fakeDb([[{ id: 37, status }]]);
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(queries).toHaveLength(1);
  });

  it("requires an approved profile", async () => {
    const queries = fakeDb([[]]);
    await expect(agentRouter.createCaller(context()).performance({ month: "2026-10" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(queries).toHaveLength(1);
  });

  it("requires auth before accessing the database", async () => {
    await expect(agentRouter.createCaller({ ...context(), user: null }).performance({ month: "2026-10" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("rejects invalid month/cache keys and explicit scope fields before DB access", async () => {
    for (const input of [{ month: "" }, { month: "2026-00" }, { month: "2026-13" }, { month: "not-a-month" }, { month: "2026-10", cacheKey: 0 }, { month: "2026-10", cacheKey: -1 }, { month: "2026-10", cacheKey: 1.5 }, { month: "2026-10", agencyId: 999 }]) {
      await expect(agentRouter.createCaller(context()).performance(input as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    }
    expect(mock.getDb).not.toHaveBeenCalled();
  });
});
