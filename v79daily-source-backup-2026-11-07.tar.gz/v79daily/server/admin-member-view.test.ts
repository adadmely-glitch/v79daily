import { describe, expect, it } from "vitest";
import {
  sortAdminMemberRowsByDeposit,
  summarizeAdminMemberRows,
  type AdminMemberViewRow,
} from "../shared/admin-member-view";

const row = (
  overrides: Partial<AdminMemberViewRow> = {}
): AdminMemberViewRow => ({
  id: 1,
  agencyId: 8,
  totalDepositVnd: 0,
  isValid: 0,
  ...overrides,
});

describe("admin member view helpers", () => {
  it("counts unique selected-agency depositors and valid members from raw rows", () => {
    const rows = [
      row({ id: 1, totalDepositVnd: 100_000, isValid: 1 }),
      row({ id: 1, totalDepositVnd: 0, isValid: 1 }),
      row({ id: 2, totalDepositVnd: -1, isValid: 1 }),
      row({ id: 3, totalDepositVnd: 0, isValid: 1 }),
      row({ id: 4, agencyId: 9, totalDepositVnd: 500_000, isValid: 1 }),
      row({ id: 5, totalDepositVnd: 250_000, isValid: 0 }),
    ];

    expect(summarizeAdminMemberRows(rows, 8)).toEqual({
      depositingCustomerCount: 2,
      validCustomerCount: 3,
    });
    expect(summarizeAdminMemberRows(rows, 9)).toEqual({
      depositingCustomerCount: 1,
      validCustomerCount: 1,
    });
  });

  it("returns zero counts for empty input", () => {
    expect(summarizeAdminMemberRows([], 8)).toEqual({
      depositingCustomerCount: 0,
      validCustomerCount: 0,
    });
  });

  it("sorts deposits numerically in both directions, preserves ties, and does not mutate", () => {
    const rows = [
      row({ id: 1, totalDepositVnd: 100 }),
      row({ id: 2, totalDepositVnd: 1_000 }),
      row({ id: 3, totalDepositVnd: 0 }),
      row({ id: 4, totalDepositVnd: 0 }),
    ];
    const original = [...rows];

    expect(
      sortAdminMemberRowsByDeposit(rows, "desc").map(({ id }) => id)
    ).toEqual([2, 1, 3, 4]);
    expect(
      sortAdminMemberRowsByDeposit(rows, "asc").map(({ id }) => id)
    ).toEqual([3, 4, 1, 2]);
    expect(
      sortAdminMemberRowsByDeposit(rows, "default").map(({ id }) => id)
    ).toEqual([1, 2, 3, 4]);
    expect(rows).toEqual(original);
    expect(sortAdminMemberRowsByDeposit(rows, "desc")).not.toBe(rows);
  });

  it("returns a new empty array for empty sorting input", () => {
    const rows: AdminMemberViewRow[] = [];
    const sorted = sortAdminMemberRowsByDeposit(rows, "desc");
    expect(sorted).toEqual([]);
    expect(sorted).not.toBe(rows);
  });
});
