import React from "react";
import { ChevronDown } from "lucide-react";
import { pointMoney } from "@shared/money";

export type AgencyNotification = {
  eventKey: string;
  kind: "admin" | "credit" | "withdrawal";
  title: string;
  message: string;
  imageAvailable: boolean;
  createdAt: Date;
  amountVnd: number | null;
  isRead: boolean;
};
export type NotificationImageData = { eventKey: string; contentType: string; data: string };

const dateTime = new Intl.DateTimeFormat("vi-VN", {
  timeZone: "Asia/Ho_Chi_Minh", dateStyle: "short", timeStyle: "short",
});

export default function AgentNotificationItem({ item, expanded, disabled, onToggle, imageData, imageLoading, imageError, onRetryImage }: {
  item: AgencyNotification;
  expanded: boolean;
  disabled: boolean;
  onToggle: () => void;
  imageData?: NotificationImageData;
  imageLoading?: boolean;
  imageError?: boolean;
  onRetryImage?: () => void;
}) {
  const detailId = `account-notification-${item.eventKey}`;
  return <article className={`account-notification-card ${item.isRead === false ? "account-notification-unread" : ""}`}>
    <button className="account-notification-title" type="button" disabled={disabled}
      aria-expanded={expanded} aria-controls={detailId} onClick={onToggle}>
      <span>{item.title}</span>
      <ChevronDown size={16} aria-hidden="true" className={expanded ? "account-notification-chevron-open" : ""} />
    </button>
    {expanded && <section id={detailId} className="account-notification-detail" aria-label="Chi tiết thông báo">
      <time dateTime={item.createdAt.toISOString()}>{dateTime.format(item.createdAt)}</time>
      <p>{item.message}</p>
      {item.imageAvailable && imageLoading && <p className="account-notification-image-status" role="status">Đang tải ảnh thông báo…</p>}
      {item.imageAvailable && imageError && <p className="account-notification-image-error" role="alert">Không tải được ảnh thông báo. {onRetryImage && <button type="button" onClick={onRetryImage}>Thử lại</button>}</p>}
      {item.imageAvailable && imageData?.eventKey === item.eventKey && <img className="account-notification-image" src={`data:${imageData.contentType};base64,${imageData.data}`} alt="Ảnh đính kèm thông báo" />}
      {item.amountVnd !== null && <strong>{pointMoney.format(item.amountVnd)}</strong>}
      <span className="account-notification-read-state">{item.isRead ? "Đã đọc" : "Chưa đọc"}</span>
    </section>}
  </article>;
}
