import React, { useState } from "react";
import { Check, Copy, LoaderCircle } from "lucide-react";

type Props = {
  kind: "bank" | "usdt";
  value: string | null | undefined;
  withdrawalId: number;
};

export default function AdminPayoutDestination({ kind, value, withdrawalId }: Props) {
  const [pending, setPending] = useState(false);
  const [feedback, setFeedback] = useState<"" | "success" | "error">("");
  const label = kind === "usdt" ? "địa chỉ ví" : "STK";

  if (!value?.trim()) {
    return <div className="admin-payout-missing" role="note">
      Chưa có {label} trên đơn này. Cần đối chiếu thông tin nhận tiền.
    </div>;
  }

  async function copyDestination() {
    if (pending || !value) return;
    setPending(true);
    setFeedback("");
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(value);
      setFeedback("success");
    } catch {
      setFeedback("error");
    } finally {
      setPending(false);
    }
  }

  return <div className="admin-payout-destination">
    <span className="admin-payout-caption">{kind === "usdt" ? "Địa chỉ ví USDT" : "STK ngân hàng"}</span>
    <code className="admin-payout-value">{value}</code>
    <button type="button" className="admin-payout-copy" disabled={pending}
      aria-label={`Sao chép ${label} đơn #${withdrawalId}`} onClick={() => void copyDestination()}>
      {pending ? <LoaderCircle size={13} className="auth-spin" /> : feedback === "success" ? <Check size={13} /> : <Copy size={13} />}
      {pending ? "Đang sao chép…" : "Sao chép"}
    </button>
    {feedback === "success" && <span className="admin-payout-feedback" role="status">Đã sao chép {label}.</span>}
    {feedback === "error" && <span className="admin-payout-feedback copy-error" role="alert">Không thể tự sao chép. Hãy chọn {label} phía trên và sao chép thủ công.</span>}
  </div>;
}
