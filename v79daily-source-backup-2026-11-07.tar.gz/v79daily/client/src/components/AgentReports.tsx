import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { winLossClass } from "@/lib/winloss";
import { formatVndAsPointNumber } from "@shared/money";
import { reportMonthSchema } from "@shared/monthly-report";

type Props = { month: string; onMonthChange: (month: string) => void; cacheKey?: number };

export default function AgentReports({ month, onMonthChange, cacheKey }: Props) {
  const [username, setUsername] = useState("");
  const validMonth = reportMonthSchema.safeParse(month).success;
  const query = trpc.reports.agentMonthly.useQuery({
    kind: "monthly", month, username: username.trim() || undefined, cacheKey,
  }, { enabled: validMonth && Boolean(cacheKey), refetchInterval: 30_000, refetchOnWindowFocus: true });
  const data = validMonth && query.isSuccess && query.data.kind === "monthly" && query.data.month === month
    ? query.data : undefined;

  return (
    <section className="agent-panel agent-monthly-report">
      <div className="agent-panel-heading"><div><span className="agent-eyebrow">BÁO CÁO ĐẠI LÝ</span><h1>Các loại báo cáo</h1></div></div>
      <div className="report-filters">
        <label><span>Tháng <b className="required-mark">*</b></span><input required type="month" aria-label="Tháng báo cáo đại lý" value={month} onChange={(event) => onMonthChange(event.target.value)} /></label>
        <label><span>Tên đăng nhập <small>(không bắt buộc)</small></span><input value={username} maxLength={64} onChange={(event) => setUsername(event.target.value)} placeholder="Để trống để xem tất cả" /></label>
      </div>
      {!validMonth && <div className="agent-empty report-prompt" role="status">Chọn tháng để xem báo cáo.</div>}
      {validMonth && query.isError && <p className="agent-error" role="alert">Không thể tải báo cáo. <button type="button" onClick={() => void query.refetch()}>Thử lại</button></p>}
      {validMonth && <div className="agent-table-wrap"><table className="agent-table">
        <thead><tr><th>Tên đăng nhập</th><th>Nạp tiền</th><th>Rút tiền</th><th>Khuyến mãi</th><th>Hoàn trả</th><th>Tổng cược</th><th>Tổng thắng thua</th></tr></thead>
        <tbody>
          {query.isLoading ? <tr><td colSpan={7} className="agent-empty">Đang tải báo cáo…</td></tr>
            : query.isError ? <tr><td colSpan={7} className="agent-empty">Chưa tải được dữ liệu tháng đã chọn.</td></tr>
            : data?.rows.length ? data.rows.map((row) => (
              <tr key={row.memberId}>
                <td className="agent-username">{row.username}</td>
                <td className="agent-amount">{formatVndAsPointNumber(row.totalDepositVnd)}</td>
                <td className="agent-amount">{formatVndAsPointNumber(row.totalWithdrawalVnd)}</td>
                <td className="agent-amount">{formatVndAsPointNumber(row.promotionVnd)}</td>
                <td className="agent-amount">{formatVndAsPointNumber(row.totalRefundVnd)}</td>
                <td className="agent-amount">{formatVndAsPointNumber(row.totalBetsVnd)}</td>
                <td className={`agent-amount ${winLossClass(row.netWinLossVnd)}`}>{formatVndAsPointNumber(row.netWinLossVnd)}</td>
              </tr>
            )) : <tr><td colSpan={7} className="agent-empty">Không có hội viên phù hợp trong tháng đã chọn.</td></tr>}
        </tbody>
      </table></div>}
    </section>
  );
}
