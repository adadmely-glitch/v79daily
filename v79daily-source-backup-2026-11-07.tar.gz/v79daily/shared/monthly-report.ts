import { z } from "zod";

export function vietnamMonthBounds(month: string) {
  const [year, number] = month.split("-").map(Number);
  const yearText = String(year).padStart(4, "0");
  const nextYear = number === 12 ? year + 1 : year;
  const nextMonth = number === 12 ? 1 : number + 1;
  return {
    start: new Date(`${yearText}-${String(number).padStart(2, "0")}-01T00:00:00+07:00`),
    end: new Date(`${String(nextYear).padStart(4, "0")}-${String(nextMonth).padStart(2, "0")}-01T00:00:00+07:00`),
  };
}

export function vietnamMonthKey(date: Date) {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit" }).formatToParts(date);
  const year = parts.find((part) => part.type === "year")?.value ?? "";
  const month = parts.find((part) => part.type === "month")?.value ?? "";
  return `${year}-${month}`;
}

export function calculateMonthlyWinLossVnd(input: { totalDepositVnd: number; totalPromotionVnd: number; totalRefundVnd: number; totalWithdrawalVnd: number }) {
  const values = [input.totalDepositVnd, input.totalPromotionVnd, input.totalRefundVnd, input.totalWithdrawalVnd];
  if (!values.every(Number.isSafeInteger)) return null;
  const total = BigInt(input.totalWithdrawalVnd) - BigInt(input.totalDepositVnd) - BigInt(input.totalPromotionVnd) - BigInt(input.totalRefundVnd);
  if (total > BigInt(Number.MAX_SAFE_INTEGER) || total < BigInt(Number.MIN_SAFE_INTEGER)) return null;
  return Number(total);
}

export const reportMonthSchema = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Chọn tháng hợp lệ.")
  .refine((month) => {
    const { start, end } = vietnamMonthBounds(month);
    return Number(month.slice(0, 4)) >= 1000 && Number.isFinite(start.getTime()) && Number.isFinite(end.getTime());
  }, "Tháng ngoài phạm vi lưu trữ hợp lệ.");

const nonnegativeVnd = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
export const monthlyTotalsSchema = z.object({
  totalDepositVnd: nonnegativeVnd,
  totalWithdrawalVnd: nonnegativeVnd,
  totalBetsVnd: nonnegativeVnd,
  totalPromotionVnd: nonnegativeVnd,
});
export type MonthlyTotals = z.infer<typeof monthlyTotalsSchema>;

export const saveMemberMonthSchema = monthlyTotalsSchema.extend({
  memberId: z.number().int().positive(),
  month: reportMonthSchema,
  reason: z.string().trim().min(3, "Nhập lý do ít nhất 3 ký tự.").max(500),
  expected: monthlyTotalsSchema.optional(),
}).strict();

export const memberPeriodInputSchema = z.object({
  agencyId: z.number().int().positive().optional(),
  month: reportMonthSchema.optional(),
  joinedInMonth: z.boolean().optional(),
  includeDeleted: z.boolean().optional(),
}).refine((input) => !input.joinedInMonth || Boolean(input.month), {
  path: ["month"], message: "Chọn tháng để lọc hội viên tham gia trong tháng.",
}).optional();
