ALTER TABLE `withdrawal_requests` MODIFY COLUMN `bank_account_id` int;--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD `destination_type` enum('bank','usdt') DEFAULT 'bank' NOT NULL;--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD `wallet_account_id` int;--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD `wallet_network` enum('TRC20','ERC20');--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD `wallet_address` varchar(64);--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD CONSTRAINT `withdrawal_requests_wallet_account_id_wallet_accounts_id_fk` FOREIGN KEY (`wallet_account_id`) REFERENCES `wallet_accounts`(`id`) ON DELETE restrict ON UPDATE no action;