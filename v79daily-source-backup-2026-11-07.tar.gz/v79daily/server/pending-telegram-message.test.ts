import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const loginSource = readFileSync(new URL("../client/src/pages/Login.tsx", import.meta.url), "utf8");
const authStyles = readFileSync(new URL("../client/src/styles/auth.css", import.meta.url), "utf8");

describe("pending agency Telegram message", () => {
  it("uses the requested copy and Telegram target in both pending states", () => {
    expect(loginSource).toContain("VUI LÒNG LIÊN HỆ TELEGRAM ĐẠI LÝ");
    expect(loginSource).toContain("@DAILYV79</a> ĐỂ DUYỆT HỒ SƠ");
    expect(loginSource).toContain('href="https://t.me/dailyv79/" target="_blank" rel="noopener noreferrer"');
    expect(loginSource.match(/<PendingTelegramMessage\s*\/>/g)).toHaveLength(2);
    expect(loginSource).not.toContain("Quản trị viên sẽ xem xét hồ sơ trước khi cấp quyền đại lý.");
  });

  it("styles the CTA blue with a subtle blink and honors reduced-motion preference", () => {
    expect(authStyles).toMatch(/\.auth-pending-telegram[^\n]*color:\s*#075fc8/i);
    expect(authStyles).toMatch(/animation:\s*auth-pending-blink/);
    expect(authStyles).toMatch(/prefers-reduced-motion:\s*reduce/);
    expect(authStyles).toMatch(/\.auth-pending-telegram\s*\{\s*animation:\s*none;/);
  });
});
