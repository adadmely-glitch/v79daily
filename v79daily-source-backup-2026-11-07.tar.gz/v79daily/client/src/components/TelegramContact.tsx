import "@/styles/telegram.css";

export default function TelegramContact() {
  return (
    <a
      className="telegram-contact"
      href="https://t.me/dailyv79/"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Liên hệ V79 Đại lý qua Telegram (mở tab mới)"
      title="CSKH Đại lý V79 qua Telegram"
    >
      <img
        className="telegram-contact-image"
        src="/manus-storage/cskh-v79-transparent_7529de06.webp"
        alt=""
        aria-hidden="true"
        width={384}
        height={384}
        decoding="async"
      />
    </a>
  );
}
