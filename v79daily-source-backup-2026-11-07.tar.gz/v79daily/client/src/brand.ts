export const V79_LOGO_SRC = "/manus-storage/v79-logo_ea94967e.png";
