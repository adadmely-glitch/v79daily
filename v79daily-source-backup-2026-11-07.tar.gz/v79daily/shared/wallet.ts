import { z } from "zod";

export const walletNetworks = ["TRC20", "ERC20"] as const;
export type WalletNetwork = typeof walletNetworks[number];

export const walletInput = z.object({
  network: z.enum(walletNetworks),
  address: z.string().trim().min(1, "Nhập địa chỉ ví.").max(64, "Địa chỉ ví quá dài."),
}).strict();

export function walletAddressKey(network: WalletNetwork, address: string): string {
  const normalized = network === "ERC20" ? address.toLowerCase() : address;
  // Preserve the existing ASCII keys, but encode arbitrary input without Unicode collisions.
  return Array.from(new TextEncoder().encode(normalized), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
