import { useEffect, useRef, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import AgentPolicy from "@/components/AgentPolicy";
import BankWithdrawalInfo from "@/components/BankWithdrawalInfo";
import AgentPerformance from "@/components/AgentPerformance";
import AgentReports from "@/components/AgentReports";
import AgentAccountDialogs, { type AccountDialogMode } from "@/components/AgentAccountDialogs";
import NotificationUnreadBadge from "@/components/NotificationUnreadBadge";
import { V79_LOGO_SRC } from "@/brand";
import { pointMoney } from "@shared/money";
import { currentVietnamMonth, getSettlementCountdown } from "@shared/settlement";
import {
  Activity, BarChart3, Bell, Check, ChevronDown, ChevronRight, CircleHelp,
  Copy, FileSearch, Grid2X2, KeyRound, LogOut, Menu, Search, UsersRound, X,
} from "lucide-react";
import "@/styles/agent.css";
import "@/styles/winloss.css";

const HOME = "Tổng Quan";
const MEMBERS = "Kiểm tra hội viên";
const POLICY = "Chính Sách  Đại Lý";
const WITHDRAW = "Rút Hoa Hồng";
const REPORTS = "Các loại báo cáo";
const money = pointMoney;
const navItems = [
  { label: HOME, icon: Grid2X2 },
  { label: MEMBERS, icon: UsersRound },
  { label: POLICY, icon: Search },
  { label: WITHDRAW, icon: FileSearch },
  { label: REPORTS, icon: BarChart3 },
];

function MemberList() {
  const [search, setSearch] = useState("");
  const [joinedDay, setJoinedDay] = useState("");
  const members = trpc.agent.members.useQuery({ search: search.trim() || undefined, joinedDay: joinedDay || undefined }, { refetchOnWindowFocus: false });
  return (
    <section className="agent-panel">
      <div className="agent-panel-heading"><div><span className="agent-eyebrow">DANH SÁCH HỘI VIÊN</span><h1>Kiểm tra hội viên</h1></div><span className="agent-count-badge">{members.data?.length ?? 0} hội viên</span></div>
      <div className="agent-filters">
        <label className="agent-search"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm theo tên đăng nhập hội viên" /></label>
        <label className="agent-date-filter"><span>Ngày tháng tham gia</span><input type="date" value={joinedDay} onChange={(event) => setJoinedDay(event.target.value)} /></label>
      </div>
      {members.isError ? <p className="agent-error">Không thể tải danh sách hội viên.</p> : null}
      <div className="agent-table-wrap"><table className="agent-table"><thead><tr><th>Tên đăng nhập</th><th>Ngày tham gia</th><th>Trạng thái</th></tr></thead><tbody>
        {members.isLoading ? <tr><td colSpan={3} className="agent-empty">Đang tải dữ liệu…</td></tr> : members.data?.length ? members.data.map((member) => <tr key={member.id}><td className="agent-username">{member.username}</td><td>{new Intl.DateTimeFormat("vi-VN", { timeZone: "Asia/Ho_Chi_Minh", dateStyle: "medium" }).format(member.joinedAt)}</td><td><span className={`transaction-pill ${member.isValid === 1 ? "transaction-deposit" : "transaction-withdrawal"}`}>{member.isValid === 1 ? "Hợp lệ" : "Chưa hợp lệ"}</span></td></tr>) : <tr><td colSpan={3} className="agent-empty">Chưa có hội viên phù hợp.</td></tr>}
      </tbody></table></div>
    </section>
  );
}

export default function AgentDashboard({ user }: { user: { name: string | null; email: string | null } }) {
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const [activeNav, setActiveNav] = useState(HOME);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [accountDialogMode, setAccountDialogMode] = useState<AccountDialogMode>(null);
  const accountAreaRef = useRef<HTMLDivElement>(null);
  const accountButtonRef = useRef<HTMLButtonElement>(null);
  const notificationButtonRef = useRef<HTMLButtonElement>(null);
  const accountDialogSource = useRef<"account" | "bell">("account");
  const [now, setNow] = useState(Date.now());
  const [copied, setCopied] = useState(false);
  const [performanceMonth, setPerformanceMonth] = useState(() => currentVietnamMonth());
  const [reportMonth, setReportMonth] = useState("");
  const overview = trpc.agent.overview.useQuery(undefined, { refetchInterval: 30_000 });
  const cacheKey = auth.user?.id;
  const unreadQuery = trpc.account.notificationUnreadCount.useQuery({ cacheKey }, {
    enabled: Boolean(cacheKey && overview.data?.status === "approved"),
    refetchInterval: 30_000, refetchOnWindowFocus: true,
  });
  const unreadCount = unreadQuery.isSuccess ? unreadQuery.data.count : undefined;
  const countdown = getSettlementCountdown(now);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1_000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!accountMenuOpen) return;
    function closeOutside(event: PointerEvent) {
      if (!accountAreaRef.current?.contains(event.target as Node)) setAccountMenuOpen(false);
    }
    function closeOnEscape(event: KeyboardEvent) {
      if (event.key === "Escape") { setAccountMenuOpen(false); accountButtonRef.current?.focus(); }
    }
    document.addEventListener("pointerdown", closeOutside);
    document.addEventListener("keydown", closeOnEscape);
    return () => { document.removeEventListener("pointerdown", closeOutside); document.removeEventListener("keydown", closeOnEscape); };
  }, [accountMenuOpen]);

  function changeActivityMonth(month: string) {
    setPerformanceMonth(month);
    setReportMonth(month);
  }

  function openAccountDialog(mode: Exclude<AccountDialogMode, null>, source: "account" | "bell" = "account") {
    accountDialogSource.current = source;
    setAccountMenuOpen(false); setAccountDialogMode(mode);
  }

  async function copyLink() {
    const link = overview.data?.referralLink;
    if (!link) return;
    try { await navigator.clipboard.writeText(link); setCopied(true); }
    catch { setCopied(false); }
    window.setTimeout(() => setCopied(false), 2_000);
  }

  async function signOut() {
    await auth.logout();
    setLocation("/");
  }

  const profile = overview.data;
  return (
    <main className="agent-shell">
      <header className="agent-topbar">
        <a href="/dashboard" className="dashboard-wordmark" aria-label="V79 Đại lý"><span className="dashboard-logo-frame"><img className="dashboard-logo-image" src={V79_LOGO_SRC} alt="V79" /></span></a>
        <button className="agent-mobile-toggle" type="button" onClick={() => setMobileNavOpen((open) => !open)} aria-label="Mở điều hướng">{mobileNavOpen ? <X size={19} /> : <Menu size={19} />}</button>
        <nav className={`agent-nav ${mobileNavOpen ? "agent-nav-open" : ""}`} aria-label="Điều hướng đại lý">
          {navItems.map(({ label, icon: Icon }) => <button key={label} type="button" className={activeNav === label ? "agent-nav-link active" : "agent-nav-link"} onClick={() => { setActiveNav(label); setMobileNavOpen(false); }}><Icon size={15} /><span>{label}</span></button>)}
        </nav>
        <div className="agent-top-actions" ref={accountAreaRef}>
          <div className="agent-header-balance" title="Số dư khả dụng hiện tại, không phụ thuộc tháng báo cáo">
            <span>Số dư</span><b>{overview.isSuccess && profile ? money.format(profile.availableVnd) : "—"}</b>
          </div>
          <button ref={notificationButtonRef} className="agent-notification-button" type="button"
            aria-label={unreadCount === undefined ? "Thông báo" : `Thông báo, ${unreadCount} chưa đọc`}
            title={unreadQuery.isError ? "Chưa tải được số thông báo chưa đọc" : "Thông báo"}
            onClick={() => openAccountDialog("notifications", "bell")}>
            <Bell size={18} aria-hidden="true" /><NotificationUnreadBadge count={unreadCount} />
          </button>
          <button ref={accountButtonRef} className="agent-account-button" type="button" aria-label="Mở menu tài khoản" aria-expanded={accountMenuOpen} aria-controls="agent-account-options" onClick={() => setAccountMenuOpen((open) => !open)}><span className="agent-avatar">{(profile?.username || user.name || "A").slice(0, 1).toUpperCase()}</span><span>{profile?.username || user.name || user.email}</span><ChevronDown size={13} /></button>
          {accountMenuOpen && <div id="agent-account-options" className="agent-account-menu" role="group" aria-label="Tùy chọn tài khoản"><b>{profile?.fullName || user.name}</b><small>{user.email}</small><button type="button" onClick={() => openAccountDialog("notifications")}><Bell size={15} aria-hidden="true" /> Thông báo<NotificationUnreadBadge count={unreadCount} /></button><button type="button" onClick={() => openAccountDialog("password")}><KeyRound size={15} aria-hidden="true" /> Đổi mật khẩu</button><button type="button" onClick={() => void signOut()}><LogOut size={15} aria-hidden="true" /> Đăng xuất</button></div>}
        </div>
      </header>

      <div className="agent-content">
        <div className="agent-breadcrumb"><button type="button" aria-label="Về Tổng Quan" onClick={() => { setActiveNav(HOME); setMobileNavOpen(false); }}>Tổng Quan</button><ChevronRight size={13} /><b>{activeNav}</b></div>
        {overview.isLoading ? <div className="agent-panel agent-loading"><span className="auth-spin"><Activity size={18} /></span>Đang tải dữ liệu đại lý…</div> : overview.isError ? <div className="agent-panel agent-error" role="alert">Không tải được dữ liệu. Kiểm tra trạng thái tài khoản rồi thử lại.</div> : null}

        {!overview.isLoading && !overview.isError && activeNav === HOME && profile && <>
          <section className="agent-overview-grid">
            <article className="agent-welcome-card"><div className="agent-welcome-copy"><div className="agent-settlement-cycle" title="Kết thúc 00:00 ngày 01/12/2026 (giờ Việt Nam)"><span className="agent-live-dot" aria-hidden="true" /><b role="timer" aria-label={`Đếm ngược kết toán tháng 11: ${countdown}`}>{countdown}</b></div><span className="agent-eyebrow">TÀI KHOẢN ĐẠI LÝ</span><h1>{profile.username.toUpperCase()}</h1><div className="agent-referral-row"><span>Liên kết giới thiệu</span><code>{profile.referralLink || "Chưa được quản trị viên cấu hình"}</code><button type="button" disabled={!profile.referralLink} onClick={() => void copyLink()}>{copied ? <Check size={14} /> : <Copy size={14} />}{copied ? "Đã sao chép" : "Sao chép"}</button></div></div>{profile.referralLink ? <div className="agent-qr"><QRCodeSVG value={profile.referralLink} size={104} level="M" marginSize={2} /><small>MÃ QR GIỚI THIỆU</small></div> : <div className="agent-qr agent-qr-empty"><CircleHelp size={25} /><small>CHƯA CÓ LIÊN KẾT</small></div>}</article>
          </section>
          <AgentPerformance month={performanceMonth} onMonthChange={changeActivityMonth} cacheKey={cacheKey} />
        </>}

        {!overview.isLoading && !overview.isError && activeNav === MEMBERS && <MemberList />}
        {activeNav === POLICY && <AgentPolicy />}
        {activeNav === WITHDRAW && <BankWithdrawalInfo />}
        {activeNav === REPORTS && <AgentReports key={cacheKey} month={reportMonth} onMonthChange={changeActivityMonth} cacheKey={cacheKey} />}
        <footer className="agent-footer"><span className="agent-footer-brand">© V79 ĐẠI LÝ</span><span className="agent-footer-update">Số liệu sẽ cập nhật sau 120 phút</span><button type="button" aria-label="Đăng xuất" title="Đăng xuất" onClick={() => void signOut()}><LogOut size={14} aria-hidden="true" /></button></footer>
      </div>
      <AgentAccountDialogs key={cacheKey} cacheKey={cacheKey} mode={accountDialogMode} onClose={() => setAccountDialogMode(null)}
        onRestoreFocus={() => (accountDialogSource.current === "bell" ? notificationButtonRef : accountButtonRef).current?.focus()} />
    </main>
  );
}
