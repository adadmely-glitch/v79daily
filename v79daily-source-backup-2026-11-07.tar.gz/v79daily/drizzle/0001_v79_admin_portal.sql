CREATE TABLE `agency_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`username` varchar(48) NOT NULL,
	`phone` varchar(32) NOT NULL,
	`full_name` varchar(200) NOT NULL,
	`status` enum('pending','approved','rejected','locked') NOT NULL DEFAULT 'pending',
	`referral_link` varchar(2048),
	`reviewed_at` timestamp,
	`reviewed_by` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agency_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `agency_profiles_user_id_uq` UNIQUE(`user_id`),
	CONSTRAINT `agency_profiles_username_uq` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actor_user_id` int,
	`action` varchar(100) NOT NULL,
	`entity_type` varchar(80) NOT NULL,
	`entity_id` int,
	`details` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `balance_credits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`amount_vnd` bigint NOT NULL,
	`reason` varchar(500) NOT NULL,
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `balance_credits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bank_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`owner_name` varchar(200) NOT NULL,
	`account_number` varchar(64) NOT NULL,
	`bank_name` varchar(120) NOT NULL,
	`branch` varchar(200) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bank_accounts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `member_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`username` varchar(64) NOT NULL,
	`full_name` varchar(200) NOT NULL,
	`phone` varchar(32),
	`joined_at` timestamp NOT NULL DEFAULT (now()),
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `member_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `member_agency_username_uq` UNIQUE(`agency_id`,`username`)
);
--> statement-breakpoint
CREATE TABLE `member_monthly_bets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`member_id` int NOT NULL,
	`month_key` varchar(7) NOT NULL,
	`amount_vnd` bigint NOT NULL,
	`updated_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `member_monthly_bets_id` PRIMARY KEY(`id`),
	CONSTRAINT `member_monthly_bet_uq` UNIQUE(`member_id`,`month_key`)
);
--> statement-breakpoint
CREATE TABLE `member_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`member_id` int NOT NULL,
	`kind` enum('deposit','withdrawal') NOT NULL,
	`amount_vnd` bigint NOT NULL,
	`occurred_at` timestamp NOT NULL,
	`note` varchar(500),
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `member_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `withdrawal_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`bank_account_id` int NOT NULL,
	`owner_name` varchar(200) NOT NULL,
	`account_number` varchar(64) NOT NULL,
	`bank_name` varchar(120) NOT NULL,
	`branch` varchar(200) NOT NULL,
	`amount_vnd` bigint NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`requested_at` timestamp NOT NULL DEFAULT (now()),
	`reviewed_at` timestamp,
	`reviewed_by` int,
	`decision_note` varchar(500),
	CONSTRAINT `withdrawal_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `agency_profiles` ADD CONSTRAINT `agency_profiles_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `agency_profiles` ADD CONSTRAINT `agency_profiles_reviewed_by_users_id_fk` FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_actor_user_id_users_id_fk` FOREIGN KEY (`actor_user_id`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `balance_credits` ADD CONSTRAINT `balance_credits_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `balance_credits` ADD CONSTRAINT `balance_credits_created_by_users_id_fk` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `bank_accounts` ADD CONSTRAINT `bank_accounts_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_accounts` ADD CONSTRAINT `member_accounts_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_accounts` ADD CONSTRAINT `member_accounts_created_by_users_id_fk` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_monthly_bets` ADD CONSTRAINT `member_monthly_bets_member_id_member_accounts_id_fk` FOREIGN KEY (`member_id`) REFERENCES `member_accounts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_monthly_bets` ADD CONSTRAINT `member_monthly_bets_updated_by_users_id_fk` FOREIGN KEY (`updated_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_transactions` ADD CONSTRAINT `member_transactions_member_id_member_accounts_id_fk` FOREIGN KEY (`member_id`) REFERENCES `member_accounts`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `member_transactions` ADD CONSTRAINT `member_transactions_created_by_users_id_fk` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD CONSTRAINT `withdrawal_requests_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD CONSTRAINT `withdrawal_requests_bank_account_id_bank_accounts_id_fk` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `withdrawal_requests` ADD CONSTRAINT `withdrawal_requests_reviewed_by_users_id_fk` FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `agency_profiles_status_idx` ON `agency_profiles` (`status`);--> statement-breakpoint
CREATE INDEX `audit_entity_idx` ON `audit_logs` (`entity_type`,`entity_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `audit_actor_idx` ON `audit_logs` (`actor_user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `balance_credits_agency_idx` ON `balance_credits` (`agency_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `bank_accounts_agency_idx` ON `bank_accounts` (`agency_id`);--> statement-breakpoint
CREATE INDEX `member_agency_joined_idx` ON `member_accounts` (`agency_id`,`joined_at`);--> statement-breakpoint
CREATE INDEX `member_monthly_bet_month_idx` ON `member_monthly_bets` (`month_key`);--> statement-breakpoint
CREATE INDEX `member_transactions_member_date_idx` ON `member_transactions` (`member_id`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `member_transactions_kind_date_idx` ON `member_transactions` (`kind`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `withdrawals_agency_idx` ON `withdrawal_requests` (`agency_id`,`requested_at`);--> statement-breakpoint
CREATE INDEX `withdrawals_status_idx` ON `withdrawal_requests` (`status`,`requested_at`);