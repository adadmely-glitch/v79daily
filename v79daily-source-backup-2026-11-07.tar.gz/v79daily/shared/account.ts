import { z } from "zod";

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Vui lòng nhập mật khẩu cũ.").max(128, "Mật khẩu cũ tối đa 128 ký tự."),
  newPassword: z.string().min(8, "Mật khẩu mới phải có ít nhất 8 ký tự.").max(128, "Mật khẩu mới tối đa 128 ký tự."),
  confirmPassword: z.string().min(1, "Vui lòng nhập lại mật khẩu mới.").max(128, "Mật khẩu xác nhận tối đa 128 ký tự."),
}).strict().refine((input) => input.newPassword === input.confirmPassword, {
  message: "Mật khẩu mới và mật khẩu nhập lại không khớp.", path: ["confirmPassword"],
}).refine((input) => input.newPassword !== input.currentPassword, {
  message: "Mật khẩu mới phải khác mật khẩu cũ.", path: ["newPassword"],
});
