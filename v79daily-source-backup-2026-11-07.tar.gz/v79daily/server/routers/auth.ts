import { createHash, randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import { COOKIE_NAME } from "@shared/const";
import { agencyCredentials, agencyProfiles, users } from "../../drizzle/schema";
import { getDb } from "../db";
import { getSessionCookieOptions } from "../_core/cookies";
import { hashPassword, verifyPassword } from "../_core/password";
import { sdk } from "../_core/sdk";
import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";

const MAX_LOGIN_FAILURES = 8;
const THROTTLE_WINDOW_MS = 15 * 60 * 1000;
const LOCAL_SESSION_MS = 7 * 24 * 60 * 60 * 1000;
type AttemptState = { count: number; resetAt: number };
const attemptStates = new Map<string, AttemptState>();
let dummyHashPromise: Promise<string> | undefined;

function loginAttemptKey(address: string, username: string) {
  return createHash("sha256").update(`${address}\0${username}`).digest("hex");
}
function checkThrottle(key: string, now: number) {
  const state = attemptStates.get(key);
  if (state && state.resetAt > now && state.count >= MAX_LOGIN_FAILURES) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Không thể đăng nhập lúc này. Vui lòng thử lại sau ít phút." });
  }
  if (!state || state.resetAt <= now) attemptStates.set(key, { count: 0, resetAt: now + THROTTLE_WINDOW_MS });
}
function recordFailure(key: string, now: number) {
  const current = attemptStates.get(key);
  if (!current || current.resetAt <= now) attemptStates.set(key, { count: 1, resetAt: now + THROTTLE_WINDOW_MS });
  else current.count += 1;
  if (attemptStates.size > 5_000) {
    for (const [entryKey, entry] of attemptStates) {
      if (entry.resetAt <= now) attemptStates.delete(entryKey);
    }
  }
}
const loginInput = z.object({ username: z.string().trim().min(3).max(32).regex(/^[a-zA-Z0-9._-]+$/), password: z.string().min(8).max(128) });

export const authRouter = router({
  me: publicProcedure.query(({ ctx }) => ctx.user),
  loginWithPassword: publicProcedure.input(loginInput).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Dịch vụ đăng nhập tạm thời không khả dụng." });
    const username = input.username.toLowerCase();
    const address = ctx.req.ip || ctx.req.socket.remoteAddress || "unknown";
    const attemptKey = loginAttemptKey(address, username);
    const now = Date.now();
    checkThrottle(attemptKey, now);

    const result = await db.transaction(async (tx) => {
      // Khóa credentials: tránh mất bộ đếm khi nhiều instance/login/reset đồng thời.
      const [account] = await tx.select({
        userId: users.id, agencyId: agencyProfiles.id, openId: users.openId, name: agencyProfiles.fullName,
        role: users.role, status: agencyProfiles.status, passwordHash: agencyCredentials.passwordHash,
        passwordVersion: agencyCredentials.passwordVersion, failedAttempts: agencyCredentials.failedAttempts,
        loginBlockedUntil: agencyCredentials.loginBlockedUntil,
      }).from(agencyProfiles).innerJoin(agencyCredentials, eq(agencyCredentials.agencyId, agencyProfiles.id))
        .innerJoin(users, eq(users.id, agencyProfiles.userId)).where(eq(agencyProfiles.username, username)).limit(1).for("update");
      if (!account) return { error: "missing" } as const;
      if (account.loginBlockedUntil && account.loginBlockedUntil.getTime() > now) return { error: "blocked" } as const;
      if (account.role === "admin") return { error: "admin" } as const;
      if (!await verifyPassword(input.password, account.passwordHash)) {
        const expired = account.loginBlockedUntil && account.loginBlockedUntil.getTime() <= now;
        const failures = (expired ? 0 : account.failedAttempts) + 1;
        const lockedUntil = failures >= MAX_LOGIN_FAILURES ? new Date(now + THROTTLE_WINDOW_MS) : null;
        await tx.update(agencyCredentials).set({ failedAttempts: lockedUntil ? 0 : failures, loginBlockedUntil: lockedUntil })
          .where(eq(agencyCredentials.agencyId, account.agencyId));
        // Không throw ở đây: bộ đếm sai cần commit trước khi trả lỗi xác thực.
        return { error: "incorrect" } as const;
      }
      await tx.update(agencyCredentials).set({ failedAttempts: 0, loginBlockedUntil: null }).where(eq(agencyCredentials.agencyId, account.agencyId));
      await tx.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, account.userId));
      return { openId: account.openId, name: account.name, status: account.status, passwordVersion: account.passwordVersion } as const;
    });

    if ("error" in result) {
      if (result.error === "blocked") throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Không thể đăng nhập lúc này. Vui lòng thử lại sau ít phút." });
      if (result.error === "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Tài khoản quản trị chỉ đăng nhập bằng Manus." });
      if (result.error === "missing") {
        dummyHashPromise ??= hashPassword(randomUUID());
        await verifyPassword(input.password, await dummyHashPromise);
      }
      recordFailure(attemptKey, now);
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Tên đăng nhập hoặc mật khẩu không chính xác." });
    }
    attemptStates.delete(attemptKey);
    const token = await sdk.createSessionToken(result.openId, { name: result.name, expiresInMs: LOCAL_SESSION_MS, passwordVersion: result.passwordVersion });
    ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: LOCAL_SESSION_MS });
    return { success: true, status: result.status } as const;
  }),
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),
});
