ALTER TABLE `member_accounts` ADD `deleted_at` timestamp;--> statement-breakpoint
CREATE INDEX `member_agency_deleted_idx` ON `member_accounts` (`agency_id`,`deleted_at`);