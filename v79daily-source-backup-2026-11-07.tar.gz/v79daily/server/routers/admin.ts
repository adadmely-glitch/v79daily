import { TRPCError } from "@trpc/server";
import { and, count, desc, eq, gte, inArray, isNotNull, isNull, lt, ne, sum } from "drizzle-orm";
import { z } from "zod";
import { agencyProfiles, auditLogs, balanceCredits, memberAccounts, memberMonthlyBets, memberMonthlyValidity, memberReportAdjustments, memberTransactions, users, withdrawalRequests } from "../../drizzle/schema";
import { getDb } from "../db";
import { adminProcedure, router } from "../_core/trpc";
import { parseVietnamDateTime, safeVndTotal } from "../reporting-utils";
import { calculateMonthlyWinLossVnd, memberPeriodInputSchema, reportMonthSchema, saveMemberMonthSchema, vietnamMonthBounds, vietnamMonthKey } from "../../shared/monthly-report";
import { addExactVnd, getMemberPeriodTotals, recalculateMemberMonthlyWinLoss, zeroMonthlyTotals } from "../member-report-totals";
import { getMemberMonthValidity } from "../member-month-validity";

const monthSchema = reportMonthSchema;
const positiveVnd = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);

function currentVietnamMonth() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit",
  }).formatToParts(new Date());
  const year = parts.find((part) => part.type === "year")?.value ?? "2026";
  const month = parts.find((part) => part.type === "month")?.value ?? "01";
  return `${year}-${month}`;
}

export const adminRouter = router({
  overview: adminProcedure.input(z.object({ month: monthSchema.optional() }).optional()).query(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    const [pendingRows, agencyRows, memberRows, withdrawalRows] = await Promise.all([
      db.select({ total: count() }).from(agencyProfiles).where(eq(agencyProfiles.status, "pending")),
      db.select({ total: count() }).from(agencyProfiles),
      db.select({ total: count() }).from(memberAccounts),
      db.select({ total: count() }).from(withdrawalRequests).where(eq(withdrawalRequests.status, "pending")),
    ]);
    return {
      pendingRegistrations: Number(pendingRows[0]?.total ?? 0),
      agencies: Number(agencyRows[0]?.total ?? 0),
      members: Number(memberRows[0]?.total ?? 0),
      pendingWithdrawals: Number(withdrawalRows[0]?.total ?? 0),
      activityMonth: input?.month ?? currentVietnamMonth(),
    };
  }),

  agencies: adminProcedure.input(z.object({ month: monthSchema.optional() }).optional()).query(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    const activityMonth = input?.month ?? currentVietnamMonth();
    const monthBounds = vietnamMonthBounds(activityMonth);
        const [profiles, credits, held, memberCounts, monthlyDeposits, monthlyMemberWithdrawals, monthlyBets, monthlyAdjustments, monthlyDepositsByMember, monthlyDepositAdjustmentsByMember, monthlyValidity] = await Promise.all([
      db.select({
        id: agencyProfiles.id,
        userId: agencyProfiles.userId,
        username: agencyProfiles.username,
        fullName: agencyProfiles.fullName,
        phone: agencyProfiles.phone,
        status: agencyProfiles.status,
        referralLink: agencyProfiles.referralLink,
        createdAt: agencyProfiles.createdAt,
        email: users.email,
        lastSignedIn: users.lastSignedIn,
      }).from(agencyProfiles).innerJoin(users, eq(agencyProfiles.userId, users.id)).orderBy(desc(agencyProfiles.createdAt)),
      db.select({ agencyId: balanceCredits.agencyId, total: sum(balanceCredits.amountVnd) }).from(balanceCredits).groupBy(balanceCredits.agencyId),
      db.select({ agencyId: withdrawalRequests.agencyId, total: sum(withdrawalRequests.amountVnd) })
        .from(withdrawalRequests).where(inArray(withdrawalRequests.status, ["pending", "approved"])).groupBy(withdrawalRequests.agencyId),
        db.select({ agencyId: memberAccounts.agencyId, total: count() }).from(memberAccounts)
          .where(isNull(memberAccounts.deletedAt)).groupBy(memberAccounts.agencyId),
      db.select({ agencyId: memberAccounts.agencyId, total: sum(memberTransactions.amountVnd) })
        .from(memberTransactions).innerJoin(memberAccounts, eq(memberTransactions.memberId, memberAccounts.id))
        .where(and(isNull(memberAccounts.deletedAt), eq(memberTransactions.kind, "deposit"), gte(memberTransactions.occurredAt, monthBounds.start), lt(memberTransactions.occurredAt, monthBounds.end)))
        .groupBy(memberAccounts.agencyId),
      db.select({ agencyId: memberAccounts.agencyId, total: sum(memberTransactions.amountVnd) })
        .from(memberTransactions).innerJoin(memberAccounts, eq(memberTransactions.memberId, memberAccounts.id))
        .where(and(isNull(memberAccounts.deletedAt), eq(memberTransactions.kind, "withdrawal"), gte(memberTransactions.occurredAt, monthBounds.start), lt(memberTransactions.occurredAt, monthBounds.end)))
        .groupBy(memberAccounts.agencyId),
        db.select({ agencyId: memberAccounts.agencyId, total: sum(memberMonthlyBets.amountVnd), validBetTotal: sum(memberMonthlyBets.validBetVnd), promotionTotal: sum(memberMonthlyBets.promotionVnd), refundTotal: sum(memberMonthlyBets.refundVnd) })
            .from(memberMonthlyBets).innerJoin(memberAccounts, eq(memberMonthlyBets.memberId, memberAccounts.id))
            .where(and(isNull(memberAccounts.deletedAt), eq(memberMonthlyBets.monthKey, activityMonth))).groupBy(memberAccounts.agencyId),
          db.select({ agencyId: memberAccounts.agencyId, depositDeltaVnd: sum(memberReportAdjustments.depositDeltaVnd), withdrawalDeltaVnd: sum(memberReportAdjustments.withdrawalDeltaVnd) })
            .from(memberReportAdjustments).innerJoin(memberAccounts, eq(memberReportAdjustments.memberId, memberAccounts.id))
            .where(and(isNull(memberAccounts.deletedAt), eq(memberReportAdjustments.monthKey, activityMonth))).groupBy(memberAccounts.agencyId),
          db.select({ agencyId: memberAccounts.agencyId, memberId: memberTransactions.memberId, total: sum(memberTransactions.amountVnd) })
            .from(memberTransactions).innerJoin(memberAccounts, eq(memberTransactions.memberId, memberAccounts.id))
            .where(and(isNull(memberAccounts.deletedAt), eq(memberTransactions.kind, "deposit"), gte(memberTransactions.occurredAt, monthBounds.start), lt(memberTransactions.occurredAt, monthBounds.end)))
            .groupBy(memberAccounts.agencyId, memberTransactions.memberId),
          db.select({ agencyId: memberAccounts.agencyId, memberId: memberReportAdjustments.memberId, depositDeltaVnd: sum(memberReportAdjustments.depositDeltaVnd) })
            .from(memberReportAdjustments).innerJoin(memberAccounts, eq(memberReportAdjustments.memberId, memberAccounts.id))
            .where(and(isNull(memberAccounts.deletedAt), eq(memberReportAdjustments.monthKey, activityMonth))).groupBy(memberAccounts.agencyId, memberReportAdjustments.memberId),
          db.select({ agencyId: memberAccounts.agencyId, total: count() })
            .from(memberMonthlyValidity).innerJoin(memberAccounts, eq(memberMonthlyValidity.memberId, memberAccounts.id))
            .where(and(isNull(memberAccounts.deletedAt), eq(memberMonthlyValidity.monthKey, activityMonth), eq(memberMonthlyValidity.isValid, 1)))
            .groupBy(memberAccounts.agencyId),
        ]);
    const numericMap = (rows: Array<{ agencyId: number; total: string | number | null }>) =>
      new Map(rows.map((row) => [row.agencyId, safeVndTotal(row.total)]));
    const creditMap = numericMap(credits);
    const heldMap = numericMap(held);
    const memberMap = numericMap(memberCounts);
    const depositMap = numericMap(monthlyDeposits);
    const withdrawalMap = numericMap(monthlyMemberWithdrawals);
        const betMap = numericMap(monthlyBets);
        const validBetMap = numericMap(monthlyBets.map((row) => ({ agencyId: row.agencyId, total: row.validBetTotal })));
        const promotionMap = numericMap(monthlyBets.map((row) => ({ agencyId: row.agencyId, total: row.promotionTotal })));
        const refundMap = numericMap(monthlyBets.map((row) => ({ agencyId: row.agencyId, total: row.refundTotal })));
        const depositDeltaMap = numericMap(monthlyAdjustments.map((row) => ({ agencyId: row.agencyId, total: row.depositDeltaVnd })));
        const withdrawalDeltaMap = numericMap(monthlyAdjustments.map((row) => ({ agencyId: row.agencyId, total: row.withdrawalDeltaVnd })));
        const depositorTotals = new Map<number, { agencyId: number; total: number }>();
        for (const row of monthlyDepositsByMember) {
          const existing = depositorTotals.get(row.memberId);
          depositorTotals.set(row.memberId, {
            agencyId: row.agencyId,
            total: addExactVnd(existing?.total ?? 0, safeVndTotal(row.total)),
          });
        }
        for (const row of monthlyDepositAdjustmentsByMember) {
          const existing = depositorTotals.get(row.memberId);
          depositorTotals.set(row.memberId, {
            agencyId: row.agencyId,
            total: addExactVnd(existing?.total ?? 0, safeVndTotal(row.depositDeltaVnd)),
          });
        }
        const depositorCountMap = new Map<number, number>();
        for (const { agencyId, total } of depositorTotals.values()) {
          if (total > 0) depositorCountMap.set(agencyId, (depositorCountMap.get(agencyId) ?? 0) + 1);
        }
        const validMemberCountMap = new Map(monthlyValidity.map((row) => [row.agencyId, Number(row.total ?? 0)]));
        return profiles.map((profile) => {
          const monthDepositVnd = addExactVnd(depositMap.get(profile.id) ?? 0, depositDeltaMap.get(profile.id) ?? 0);
          const monthMemberWithdrawalVnd = addExactVnd(withdrawalMap.get(profile.id) ?? 0, withdrawalDeltaMap.get(profile.id) ?? 0);
          const monthWinLossVnd = calculateMonthlyWinLossVnd({
            totalDepositVnd: monthDepositVnd,
            totalWithdrawalVnd: monthMemberWithdrawalVnd,
            totalPromotionVnd: promotionMap.get(profile.id) ?? 0,
            totalRefundVnd: refundMap.get(profile.id) ?? 0,
          });
          if (monthWinLossVnd === null) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Tổng tiền vượt phạm vi xử lý chính xác." });
          return {
            ...profile,
            activityMonth,
            creditedVnd: creditMap.get(profile.id) ?? 0,
            reservedVnd: heldMap.get(profile.id) ?? 0,
            availableVnd: Math.max(0, (creditMap.get(profile.id) ?? 0) - (heldMap.get(profile.id) ?? 0)),
            memberCount: memberMap.get(profile.id) ?? 0,
            monthDepositVnd,
            monthMemberWithdrawalVnd,
            monthBetsVnd: betMap.get(profile.id) ?? 0,
            monthPromotionVnd: promotionMap.get(profile.id) ?? 0,
            monthRefundVnd: refundMap.get(profile.id) ?? 0,
            monthPromotionRefundVnd: addExactVnd(promotionMap.get(profile.id) ?? 0, refundMap.get(profile.id) ?? 0),
            monthDepositorCount: depositorCountMap.get(profile.id) ?? 0,
            monthValidMemberCount: validMemberCountMap.get(profile.id) ?? 0,
            monthValidBetsVnd: validBetMap.get(profile.id) ?? 0,
            monthWinLossVnd,
          };
        });
  }),

  reviewRegistration: adminProcedure.input(z.object({
    agencyId: z.number().int().positive(),
    decision: z.enum(["approved", "rejected"]),
    note: z.string().trim().max(500).optional(),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [profile] = await tx.select().from(agencyProfiles).where(eq(agencyProfiles.id, input.agencyId)).for("update");
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hồ sơ đăng ký." });
      if (profile.status !== "pending") throw new TRPCError({ code: "CONFLICT", message: "Hồ sơ không còn ở trạng thái chờ duyệt." });
      const reviewedAt = new Date();
      await tx.update(agencyProfiles).set({ status: input.decision, reviewedAt, reviewedBy: ctx.user.id }).where(eq(agencyProfiles.id, profile.id));
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id,
        action: `agency.registration_${input.decision}`,
        entityType: "agency_profile",
        entityId: profile.id,
        details: JSON.stringify({ from: profile.status, to: input.decision, note: input.note ?? null }),
      });
      return { success: true as const, status: input.decision };
    });
  }),

  setAgencyLock: adminProcedure.input(z.object({ agencyId: z.number().int().positive(), locked: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
      return db.transaction(async (tx) => {
        const [profile] = await tx.select().from(agencyProfiles).where(eq(agencyProfiles.id, input.agencyId)).for("update");
        if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy đại lý." });
        const nextStatus = input.locked ? "locked" : "approved";
        if (input.locked && profile.status !== "approved") throw new TRPCError({ code: "CONFLICT", message: "Chỉ có thể khóa đại lý đã được duyệt." });
        if (!input.locked && profile.status !== "locked") throw new TRPCError({ code: "CONFLICT", message: "Đại lý hiện không ở trạng thái khóa." });
        await tx.update(agencyProfiles).set({ status: nextStatus }).where(eq(agencyProfiles.id, profile.id));
        await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: input.locked ? "agency.locked" : "agency.unlocked", entityType: "agency_profile", entityId: profile.id, details: JSON.stringify({ from: profile.status, to: nextStatus }) });
        return { success: true as const, status: nextStatus };
      });
    }),

  updateReferralLink: adminProcedure.input(z.object({
    agencyId: z.number().int().positive(),
    referralLink: z.string().trim().max(2048).url().refine((value) => value.startsWith("https://"), "Chỉ chấp nhận liên kết HTTPS"),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [profile] = await tx.select({ id: agencyProfiles.id, referralLink: agencyProfiles.referralLink }).from(agencyProfiles).where(eq(agencyProfiles.id, input.agencyId)).for("update");
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy đại lý." });
      await tx.update(agencyProfiles).set({ referralLink: input.referralLink }).where(eq(agencyProfiles.id, profile.id));
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "agency.referral_link_updated", entityType: "agency_profile", entityId: profile.id, details: JSON.stringify({ previous: profile.referralLink, updated: input.referralLink }) });
      return { success: true as const };
    });
  }),

  addBalanceCredit: adminProcedure.input(z.object({
    agencyId: z.number().int().positive(),
    amountVnd: positiveVnd,
    reason: z.string().trim().min(3).max(500),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [profile] = await tx.select({ id: agencyProfiles.id, status: agencyProfiles.status }).from(agencyProfiles)
        .where(eq(agencyProfiles.id, input.agencyId)).for("update");
      if (!profile || profile.status !== "approved") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Chỉ có thể cộng số dư cho đại lý đang hoạt động." });
      const [created] = await tx.insert(balanceCredits).values({ agencyId: profile.id, amountVnd: input.amountVnd, reason: input.reason, createdBy: ctx.user.id }).$returningId();
      const id = Number(created.id);
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "agency.balance_credited", entityType: "balance_credit", entityId: id, details: JSON.stringify({ agencyId: profile.id, amountVnd: input.amountVnd, reason: input.reason }) });
      return { success: true as const, id };
    });
  }),

  withdrawals: adminProcedure.input(z.object({ status: z.enum(["pending", "approved", "rejected", "all"]).default("all") }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
      const status = input?.status ?? "all";
      const query = db.select({
        id: withdrawalRequests.id,
        agencyId: agencyProfiles.id,
        agencyUsername: agencyProfiles.username,
        agencyName: agencyProfiles.fullName,
        amountVnd: withdrawalRequests.amountVnd,
        destinationType: withdrawalRequests.destinationType,
        walletNetwork: withdrawalRequests.walletNetwork,
        walletAddress: withdrawalRequests.walletAddress,
        bankName: withdrawalRequests.bankName,
        accountNumber: withdrawalRequests.accountNumber,
        ownerName: withdrawalRequests.ownerName,
        branch: withdrawalRequests.branch,
        status: withdrawalRequests.status,
        requestedAt: withdrawalRequests.requestedAt,
        decisionNote: withdrawalRequests.decisionNote,
      }).from(withdrawalRequests).innerJoin(agencyProfiles, eq(withdrawalRequests.agencyId, agencyProfiles.id));
      const rows = status === "all" ? await query.orderBy(desc(withdrawalRequests.requestedAt)) : await query
        .where(eq(withdrawalRequests.status, status)).orderBy(desc(withdrawalRequests.requestedAt));
      return rows.map((row) => ({ ...row, amountVnd: safeVndTotal(row.amountVnd) }));
    }),

  reviewWithdrawal: adminProcedure.input(z.object({
    withdrawalId: z.number().int().positive(),
    decision: z.enum(["approved", "rejected"]),
    note: z.string().trim().max(500).optional(),
  })).mutation(async ({ ctx, input }) => {
    if (input.decision === "rejected" && !input.note?.trim()) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Nhập lý do từ chối lệnh rút." });
    }
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [request] = await tx.select().from(withdrawalRequests).where(eq(withdrawalRequests.id, input.withdrawalId)).for("update");
      if (!request) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy lệnh rút." });
      if (request.status !== "pending") throw new TRPCError({ code: "CONFLICT", message: "Lệnh rút đã được xử lý." });
      const reviewedAt = new Date();
      await tx.update(withdrawalRequests).set({ status: input.decision, reviewedAt, reviewedBy: ctx.user.id, decisionNote: input.note ?? null }).where(eq(withdrawalRequests.id, request.id));
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: `withdrawal.${input.decision}`, entityType: "withdrawal_request", entityId: request.id, details: JSON.stringify({ agencyId: request.agencyId, amountVnd: request.amountVnd, note: input.note ?? null, realPaymentSent: false }) });
      return { success: true as const, status: input.decision };
    });
  }),

  members: adminProcedure.input(memberPeriodInputSchema).query(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    const query = db.select({
      id: memberAccounts.id,
      agencyId: memberAccounts.agencyId,
      agencyUsername: agencyProfiles.username,
      agencyName: agencyProfiles.fullName,
      username: memberAccounts.username,
      fullName: memberAccounts.fullName,
      phone: memberAccounts.phone,
      isValid: memberAccounts.isValid,
      deletedAt: memberAccounts.deletedAt,
      joinedAt: memberAccounts.joinedAt,
    }).from(memberAccounts).innerJoin(agencyProfiles, eq(memberAccounts.agencyId, agencyProfiles.id));
    const bounds = input?.month ? vietnamMonthBounds(input.month) : undefined;
    const members = await query.where(and(
      input?.agencyId ? eq(memberAccounts.agencyId, input.agencyId) : undefined,
      input?.includeDeleted === true ? isNotNull(memberAccounts.deletedAt) : isNull(memberAccounts.deletedAt),
      input?.joinedInMonth && bounds ? gte(memberAccounts.joinedAt, bounds.start) : undefined,
      input?.joinedInMonth && bounds ? lt(memberAccounts.joinedAt, bounds.end) : undefined,
    )).orderBy(desc(memberAccounts.joinedAt));
    if (!members.length) return [];
    const ids = members.map((member) => member.id);
    const totals = await getMemberPeriodTotals(db, ids, input?.month);
    const monthlyValidity = input?.month ? await getMemberMonthValidity(db, ids, input.month) : undefined;
    return members.map((member) => {
      const monthlyTotals = totals.get(member.id) ?? zeroMonthlyTotals();
      const netWinLossVnd = calculateMonthlyWinLossVnd(monthlyTotals);
      if (netWinLossVnd === null) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Tổng tiền vượt phạm vi xử lý chính xác." });
      return { ...member, ...(monthlyValidity ? { isValid: monthlyValidity.get(member.id) ?? 0 } : {}), ...monthlyTotals, netWinLossVnd };
    });
  }),

  createMember: adminProcedure.input(z.object({
    agencyId: z.number().int().positive(),
    username: z.string().trim().min(2).max(64).regex(/^[a-zA-Z0-9._-]+$/),
    fullName: z.string().trim().min(2).max(200).optional(),
    phone: z.string().trim().max(32).optional().nullable(),
    joinedAt: z.date().optional(),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [agency] = await tx.select({ id: agencyProfiles.id, status: agencyProfiles.status }).from(agencyProfiles)
        .where(eq(agencyProfiles.id, input.agencyId)).limit(1).for("update");
      if (!agency || agency.status !== "approved") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Chỉ gắn hội viên vào đại lý đã duyệt và đang hoạt động." });
      const [usernameOwner] = await tx.select({ id: memberAccounts.id }).from(memberAccounts)
        .where(eq(memberAccounts.username, input.username)).limit(1);
      if (usernameOwner) throw new TRPCError({ code: "CONFLICT", message: "Tên đăng nhập hội viên đã được sử dụng." });
      const [created] = await tx.insert(memberAccounts).values({
        agencyId: input.agencyId,
        username: input.username,
        fullName: input.fullName ?? "",
        phone: input.phone?.trim() || null,
        joinedAt: input.joinedAt ?? new Date(),
        createdBy: ctx.user.id,
      }).$returningId();
      const id = Number(created.id);
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "member.created", entityType: "member_account", entityId: id, details: JSON.stringify({ agencyId: input.agencyId, username: input.username, fullName: input.fullName ?? "" }) });
      return { success: true as const, id };
    });
  }),

  updateMember: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    username: z.string().trim().min(2).max(64).regex(/^[a-zA-Z0-9._-]+$/),
    fullName: z.string().trim().max(200).optional(),
    phone: z.string().trim().max(32).optional().nullable(),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [member] = await tx.select().from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const [usernameOwner] = await tx.select({ id: memberAccounts.id }).from(memberAccounts)
        .where(and(eq(memberAccounts.username, input.username), ne(memberAccounts.id, member.id))).limit(1);
      if (usernameOwner) throw new TRPCError({ code: "CONFLICT", message: "Tên đăng nhập hội viên đã được sử dụng." });
      const next = { username: input.username, fullName: input.fullName ?? member.fullName,
        phone: input.phone === undefined ? member.phone : input.phone?.trim() || null };
      await tx.update(memberAccounts).set(next).where(eq(memberAccounts.id, member.id));
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "member.updated", entityType: "member_account", entityId: member.id, details: JSON.stringify({ before: { username: member.username, fullName: member.fullName, phone: member.phone }, after: next }) });
      return { success: true as const };
    });
  }),

  setMemberArchived: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    archived: z.boolean(),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [member] = await tx.select().from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const deletedAt = input.archived ? new Date() : null;
      await tx.update(memberAccounts).set({ deletedAt }).where(eq(memberAccounts.id, member.id));
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id,
        action: input.archived ? "member.archived" : "member.restored",
        entityType: "member_account",
        entityId: member.id,
        details: JSON.stringify({
          agencyId: member.agencyId,
          username: member.username,
          fromDeletedAt: member.deletedAt,
          toDeletedAt: deletedAt,
        }),
      });
      return { success: true as const, archived: input.archived };
    });
  }),

  setMemberValidity: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    isValid: z.boolean(),
    month: monthSchema.optional(),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [member] = await tx.select().from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const isValid = input.isValid ? 1 : 0;
      if (input.month) {
        const [existing] = await tx.select({
          id: memberMonthlyValidity.id,
          isValid: memberMonthlyValidity.isValid,
        }).from(memberMonthlyValidity).where(and(
          eq(memberMonthlyValidity.memberId, member.id),
          eq(memberMonthlyValidity.monthKey, input.month),
        )).for("update");
        if (existing?.isValid === isValid) return { success: true as const, month: input.month };

        let entityId = existing?.id;
        if (existing) {
          await tx.update(memberMonthlyValidity).set({ isValid, updatedBy: ctx.user.id })
            .where(eq(memberMonthlyValidity.id, existing.id));
        } else {
          const [created] = await tx.insert(memberMonthlyValidity).values({
            memberId: member.id,
            monthKey: input.month,
            isValid,
            updatedBy: ctx.user.id,
          }).$returningId();
          entityId = Number(created.id);
        }
        await tx.insert(auditLogs).values({
          actorUserId: ctx.user.id,
          action: "member.monthly_validity_updated",
          entityType: "member_monthly_validity",
          entityId,
          details: JSON.stringify({
            agencyId: member.agencyId,
            username: member.username,
            month: input.month,
            previous: existing ? existing.isValid === 1 : null,
            isValid: input.isValid,
          }),
        });
        return { success: true as const, month: input.month };
      }
      if (member.isValid === isValid) return { success: true as const };
      await tx.update(memberAccounts).set({ isValid }).where(eq(memberAccounts.id, member.id));
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id, action: "member.validity_updated", entityType: "member_account", entityId: member.id,
        details: JSON.stringify({ agencyId: member.agencyId, username: member.username, previous: member.isValid === 1, isValid: input.isValid }),
      });
      return { success: true as const };
    });
  }),

  addMemberTransaction: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    kind: z.enum(["deposit", "withdrawal"]),
    amountVnd: positiveVnd,
    occurredAt: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/),
    note: z.string().trim().min(2).max(500),
  })).mutation(async ({ ctx, input }) => {
    const occurredAt = parseVietnamDateTime(input.occurredAt);
    if (!occurredAt) throw new TRPCError({ code: "BAD_REQUEST", message: "Ngày giờ giao dịch không hợp lệ." });
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [member] = await tx.select({ id: memberAccounts.id, agencyId: memberAccounts.agencyId, username: memberAccounts.username })
        .from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).limit(1).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const [created] = await tx.insert(memberTransactions).values({
        memberId: member.id, kind: input.kind, amountVnd: input.amountVnd, occurredAt, note: input.note, createdBy: ctx.user.id,
      }).$returningId();
      const id = Number(created.id);
      await recalculateMemberMonthlyWinLoss(tx, member.id, vietnamMonthKey(occurredAt), ctx.user.id);
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: `member_transaction.${input.kind}_recorded`, entityType: "member_transaction", entityId: id, details: JSON.stringify({ memberId: member.id, agencyId: member.agencyId, username: member.username, amountVnd: input.amountVnd, occurredAt: occurredAt.toISOString(), note: input.note }) });
      return { success: true as const, id };
    });
  }),

  addMemberTransactions: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    depositVnd: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).optional(),
    withdrawalVnd: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).optional(),
  }).strict().refine((value) => (value.depositVnd ?? 0) > 0 || (value.withdrawalVnd ?? 0) > 0, {
    message: "Nhập ít nhất một khoản nạp hoặc rút lớn hơn 0.",
  })).mutation(async ({ ctx, input }) => {
    const occurredAt = new Date();
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [member] = await tx.select({ id: memberAccounts.id, agencyId: memberAccounts.agencyId, username: memberAccounts.username })
        .from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const ids: number[] = [];
      for (const [kind, amountVnd] of [["deposit", input.depositVnd ?? 0], ["withdrawal", input.withdrawalVnd ?? 0]] as const) {
        if (!amountVnd) continue;
        const [created] = await tx.insert(memberTransactions).values({
          memberId: member.id, kind, amountVnd, occurredAt, note: "Admin ghi dữ liệu nạp/rút chung", createdBy: ctx.user.id,
        }).$returningId();
        ids.push(Number(created.id));
        await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: `member_transaction.${kind}_recorded`,
          entityType: "member_transaction", entityId: Number(created.id), details: JSON.stringify({
            memberId: member.id, agencyId: member.agencyId, username: member.username, amountVnd,
            occurredAt: occurredAt.toISOString(), source: "combined_deposit_withdrawal",
          }) });
      }
      await recalculateMemberMonthlyWinLoss(tx, member.id, vietnamMonthKey(occurredAt), ctx.user.id);
      return { success: true as const, ids };
    });
  }),

  memberTransactions: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    month: monthSchema,
  })).query(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    const bounds = vietnamMonthBounds(input.month);
    const rows = await db.select({
      id: memberTransactions.id,
      memberId: memberTransactions.memberId,
      kind: memberTransactions.kind,
      amountVnd: memberTransactions.amountVnd,
      occurredAt: memberTransactions.occurredAt,
      note: memberTransactions.note,
      createdBy: memberTransactions.createdBy,
      createdAt: memberTransactions.createdAt,
    }).from(memberTransactions).where(and(
      eq(memberTransactions.memberId, input.memberId),
      gte(memberTransactions.occurredAt, bounds.start),
      lt(memberTransactions.occurredAt, bounds.end),
    )).orderBy(desc(memberTransactions.occurredAt), desc(memberTransactions.id));
    return rows.map((row) => ({ ...row, amountVnd: safeVndTotal(row.amountVnd) }));
  }),

  updateMemberTransaction: adminProcedure.input(z.object({
    transactionId: z.number().int().positive(),
    amountVnd: positiveVnd,
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [transaction] = await tx.select().from(memberTransactions)
        .where(eq(memberTransactions.id, input.transactionId)).limit(1).for("update");
      if (!transaction) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy giao dịch." });
      const [member] = await tx.select({ id: memberAccounts.id, agencyId: memberAccounts.agencyId, username: memberAccounts.username })
        .from(memberAccounts).where(eq(memberAccounts.id, transaction.memberId)).limit(1).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên của giao dịch." });
      await tx.update(memberTransactions).set({ amountVnd: input.amountVnd }).where(eq(memberTransactions.id, transaction.id));
      await recalculateMemberMonthlyWinLoss(tx, member.id, vietnamMonthKey(transaction.occurredAt), ctx.user.id);
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id,
        action: "member_transaction.updated",
        entityType: "member_transaction",
        entityId: transaction.id,
        details: JSON.stringify({
          memberId: member.id,
          agencyId: member.agencyId,
          username: member.username,
          kind: transaction.kind,
          occurredAt: transaction.occurredAt.toISOString(),
          beforeAmountVnd: transaction.amountVnd,
          afterAmountVnd: input.amountVnd,
        }),
      });
      return { success: true as const };
    });
  }),

  saveMemberMonth: adminProcedure.input(saveMemberMonthSchema).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      const [member] = await tx.select({ id: memberAccounts.id, agencyId: memberAccounts.agencyId, username: memberAccounts.username })
        .from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const before = (await getMemberPeriodTotals(tx, [member.id], input.month)).get(member.id) ?? zeroMonthlyTotals();
      const after = { totalDepositVnd: input.totalDepositVnd, totalWithdrawalVnd: input.totalWithdrawalVnd,
        totalBetsVnd: input.totalBetsVnd, totalPromotionVnd: input.totalPromotionVnd };
      const keys = Object.keys(after) as Array<keyof typeof after>;
      if (input.expected && keys.some((key) => input.expected![key] !== before[key])) {
        throw new TRPCError({ code: "CONFLICT", message: "Dữ liệu tháng đã thay đổi. Tải lại bảng và mở form sửa mới trước khi lưu." });
      }
      const [existing] = await tx.select().from(memberMonthlyBets).where(and(
        eq(memberMonthlyBets.memberId, member.id), eq(memberMonthlyBets.monthKey, input.month),
      )).for("update");
      const existingValidBetVnd = existing ? safeVndTotal(existing.validBetVnd) : 0;
      if (existingValidBetVnd > after.totalBetsVnd) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Tổng cược không được thấp hơn cược hợp lệ đã lưu." });
      }
      const changed = keys.some((key) => before[key] !== after[key]) || !existing;
      if (!changed) return { success: true as const, memberId: member.id, month: input.month, changed: false };
      const depositDeltaVnd = safeVndTotal((BigInt(after.totalDepositVnd) - BigInt(before.totalDepositVnd)).toString());
      const withdrawalDeltaVnd = safeVndTotal((BigInt(after.totalWithdrawalVnd) - BigInt(before.totalWithdrawalVnd)).toString());
      if (depositDeltaVnd || withdrawalDeltaVnd) {
        await tx.insert(memberReportAdjustments).values({ memberId: member.id, monthKey: input.month,
          depositDeltaVnd, withdrawalDeltaVnd, reason: input.reason, createdBy: ctx.user.id });
      }
      let entityId = existing?.id;
      if (existing) {
        await tx.update(memberMonthlyBets).set({ amountVnd: after.totalBetsVnd, promotionVnd: after.totalPromotionVnd,
          updatedBy: ctx.user.id }).where(eq(memberMonthlyBets.id, existing.id));
      } else {
        const [created] = await tx.insert(memberMonthlyBets).values({ memberId: member.id, monthKey: input.month,
          amountVnd: after.totalBetsVnd, promotionVnd: after.totalPromotionVnd, validBetVnd: 0, netWinLossVnd: 0,
          updatedBy: ctx.user.id }).$returningId();
        entityId = created.id;
      }
      const netWinLossVnd = await recalculateMemberMonthlyWinLoss(tx, member.id, input.month, ctx.user.id, { id: Number(entityId) });
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "member.monthly_report_corrected",
        entityType: "member_monthly_bet", entityId, details: JSON.stringify({
          memberId: member.id, agencyId: member.agencyId, username: member.username, month: input.month,
          before, after, netWinLossVnd, depositDeltaVnd, withdrawalDeltaVnd, reason: input.reason,
        }) });
      return { success: true as const, memberId: member.id, month: input.month, changed: true };
    });
  }),

  upsertMonthlyBet: adminProcedure.input(z.object({
    memberId: z.number().int().positive(),
    month: monthSchema,
    amountVnd: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
    validBetVnd: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).optional(),
    promotionVnd: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).optional(),
    refundVnd: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).optional(),
    netWinLossVnd: z.number().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER).optional(),
  }).refine((value) => value.validBetVnd === undefined || value.validBetVnd <= value.amountVnd, { path: ["validBetVnd"], message: "Cược hợp lệ không được vượt tổng cược." })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.transaction(async (tx) => {
      // Serialize even first inserts for this member, independent of gap-lock semantics.
      const [member] = await tx.select({ id: memberAccounts.id, agencyId: memberAccounts.agencyId, username: memberAccounts.username })
        .from(memberAccounts).where(eq(memberAccounts.id, input.memberId)).for("update");
      if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hội viên." });
      const [existing] = await tx.select().from(memberMonthlyBets).where(and(
        eq(memberMonthlyBets.memberId, member.id), eq(memberMonthlyBets.monthKey, input.month),
      )).for("update");
      // Omitted fields from older clients preserve existing metrics, never reset them.
      const existingAmountVnd = existing ? safeVndTotal(existing.amountVnd) : 0;
      const existingValidBetVnd = existing ? safeVndTotal(existing.validBetVnd) : 0;
      const existingPromotionVnd = existing ? safeVndTotal(existing.promotionVnd) : 0;
      const existingRefundVnd = existing ? safeVndTotal(existing.refundVnd) : 0;
      const existingNetWinLossVnd = existing ? safeVndTotal(existing.netWinLossVnd) : 0;
      const validBetVnd = input.validBetVnd ?? existingValidBetVnd;
      const promotionVnd = input.promotionVnd ?? existingPromotionVnd;
      const refundVnd = input.refundVnd ?? existingRefundVnd;
      if (validBetVnd > input.amountVnd) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Tổng cược không được thấp hơn cược hợp lệ đã lưu. Hãy cập nhật cả cược hợp lệ nếu cần thay đổi." });
      }
      let entityId = existing?.id;
      if (existing) {
        await tx.update(memberMonthlyBets).set({
          amountVnd: input.amountVnd,
          validBetVnd,
          promotionVnd,
          refundVnd,
          updatedBy: ctx.user.id,
        }).where(eq(memberMonthlyBets.id, existing.id));
      } else {
        const [created] = await tx.insert(memberMonthlyBets).values({
          memberId: member.id,
          monthKey: input.month,
          amountVnd: input.amountVnd,
          validBetVnd,
          promotionVnd,
          refundVnd,
          netWinLossVnd: 0,
          updatedBy: ctx.user.id,
        }).$returningId();
        entityId = created.id;
      }
      const netWinLossVnd = await recalculateMemberMonthlyWinLoss(tx, member.id, input.month, ctx.user.id, { id: Number(entityId) });
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id,
        action: "member.monthly_bet_updated",
        entityType: "member_monthly_bet",
        entityId,
        details: JSON.stringify({
          memberId: member.id,
          agencyId: member.agencyId,
          username: member.username,
          month: input.month,
          previous: existing ? { amountVnd: existingAmountVnd, validBetVnd: existingValidBetVnd, promotionVnd: existingPromotionVnd, refundVnd: existingRefundVnd, netWinLossVnd: existingNetWinLossVnd } : null,
          updated: { amountVnd: input.amountVnd, validBetVnd, promotionVnd, refundVnd, netWinLossVnd },
        }),
      });
      return { success: true as const };
    });
  }),

  audit: adminProcedure.input(z.object({ limit: z.number().int().min(1).max(200).default(100) }).optional()).query(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    return db.select({
      id: auditLogs.id,
      actorUserId: auditLogs.actorUserId,
      actorEmail: users.email,
      actorName: users.name,
      action: auditLogs.action,
      entityType: auditLogs.entityType,
      entityId: auditLogs.entityId,
      details: auditLogs.details,
      createdAt: auditLogs.createdAt,
    }).from(auditLogs).leftJoin(users, eq(auditLogs.actorUserId, users.id))
      .orderBy(desc(auditLogs.createdAt)).limit(input?.limit ?? 100);
  }),
});
