export type AdminMemberViewRow = {
  id: number;
  agencyId: number;
  totalDepositVnd: number;
  isValid: number;
};

export type MemberDepositSort = "default" | "desc" | "asc";

export type AdminMemberSummary = {
  depositingCustomerCount: number;
  validCustomerCount: number;
};

/** Count each selected-agency member ID once, using the API's period totals and validity flag. */
export function summarizeAdminMemberRows(
  rows: readonly AdminMemberViewRow[],
  agencyId: number
): AdminMemberSummary {
  const depositingIds = new Set<number>();
  const validIds = new Set<number>();

  for (const row of rows) {
    if (row.agencyId !== agencyId) continue;
    if (row.totalDepositVnd > 0) depositingIds.add(row.id);
    if (row.isValid === 1) validIds.add(row.id);
  }

  return {
    depositingCustomerCount: depositingIds.size,
    validCustomerCount: validIds.size,
  };
}

/** Return a new array; ties retain their original order and the source array is never mutated. */
export function sortAdminMemberRowsByDeposit<
  T extends Pick<AdminMemberViewRow, "totalDepositVnd">,
>(rows: readonly T[], sort: MemberDepositSort): T[] {
  const indexedRows = rows.map((row, index) => ({ row, index }));
  if (sort === "default") return indexedRows.map(({ row }) => row);

  const direction = sort === "desc" ? -1 : 1;
  return indexedRows
    .sort((left, right) => {
      if (left.row.totalDepositVnd === right.row.totalDepositVnd)
        return left.index - right.index;
      return left.row.totalDepositVnd > right.row.totalDepositVnd
        ? direction
        : -direction;
    })
    .map(({ row }) => row);
}
