import { beforeEach, describe, expect, it, vi } from "vitest";
import type { SQL } from "drizzle-orm";
import { getMemberMonthValidity } from "./member-month-validity";
import { adminRouter } from "./routers/admin";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));

function context(role: "admin" | "user" = "admin"): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "test",
      email: null,
      name: "Test",
      loginMethod: "password",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function fakeDb(resultSets: unknown[][]) {
  const queries: Array<{
    fields: Record<string, unknown>;
    filters: SQL[];
    locked: boolean;
  }> = [];
  const updates: unknown[] = [];
  const inserts: unknown[] = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const result = resultSets.shift() ?? [];
      const entry = { fields, filters: [] as SQL[], locked: false };
      queries.push(entry);
      const chain: any = {
        from: () => chain,
        innerJoin: () => chain,
        where: (filter: SQL) => {
          entry.filters.push(filter);
          return chain;
        },
        orderBy: () => chain,
        groupBy: () => chain,
        for: () => {
          entry.locked = true;
          return chain;
        },
        then: (resolve: (rows: unknown[]) => unknown) =>
          Promise.resolve(result).then(resolve),
      };
      return chain;
    }),
    update: vi.fn(() => ({
      set: (values: unknown) => {
        updates.push(values);
        return { where: vi.fn(async () => undefined) };
      },
    })),
    insert: vi.fn(() => ({
      values: (values: unknown) => {
        inserts.push(values);
        return {
          $returningId: async () => [{ id: 999 }],
          then: (resolve: (value: undefined) => unknown) =>
            Promise.resolve(undefined).then(resolve),
        };
      },
    })),
    transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) => fn(db)),
  };
  mock.getDb.mockResolvedValue(db);
  return { db, queries, updates, inserts };
}

beforeEach(() => vi.clearAllMocks());

describe("getMemberMonthValidity", () => {
  it("returns only explicit marks and leaves missing months absent", async () => {
    const rows = [
      { memberId: 1, isValid: 1 },
      { memberId: 2, isValid: 0 },
    ];
    const db = {
      select: vi.fn(() => ({
        from: () => ({
          where: () => Promise.resolve(rows),
        }),
      })),
    } as any;
    const result = await getMemberMonthValidity(db, [1, 2, 3], "2026-10");
    expect(result).toEqual(
      new Map([
        [1, 1],
        [2, 0],
      ])
    );
    expect(result.has(3)).toBe(false);
  });

  it("does not issue a query for an empty member list", async () => {
    const select = vi.fn();
    await expect(
      getMemberMonthValidity({ select } as any, [], "2026-10")
    ).resolves.toEqual(new Map());
    expect(select).not.toHaveBeenCalled();
  });
});

describe("Admin monthly validity", () => {
  it("inserts a month-scoped mark without changing the legacy global flag", async () => {
    const { queries, updates, inserts } = fakeDb([
      [{ id: 7, agencyId: 8, username: "member01", isValid: 1 }],
      [],
    ]);
    const result = await adminRouter
      .createCaller(context())
      .setMemberValidity({ memberId: 7, month: "2026-10", isValid: true });
    expect(result).toEqual({ success: true, month: "2026-10" });
    expect(queries[0].locked).toBe(true);
    expect(updates).toEqual([]);
    expect(inserts[0]).toMatchObject({
      memberId: 7,
      monthKey: "2026-10",
      isValid: 1,
      updatedBy: 42,
    });
    expect(inserts[1]).toMatchObject({
      action: "member.monthly_validity_updated",
      entityType: "member_monthly_validity",
      entityId: 999,
    });
    expect(JSON.parse((inserts[1] as any).details)).toMatchObject({
      month: "2026-10",
      previous: null,
      isValid: true,
    });
  });

  it("updates an existing month mark idempotently and records the previous state", async () => {
    const { updates, inserts } = fakeDb([
      [{ id: 7, agencyId: 8, username: "member01", isValid: 0 }],
      [{ id: 91, isValid: 1 }],
    ]);
    await adminRouter
      .createCaller(context())
      .setMemberValidity({ memberId: 7, month: "2026-10", isValid: false });
    expect(updates).toEqual([{ isValid: 0, updatedBy: 42 }]);
    expect(inserts).toHaveLength(1);
    const details = JSON.parse((inserts[0] as any).details);
    expect(details).toMatchObject({
      month: "2026-10",
      previous: true,
      isValid: false,
    });
  });

  it("keeps the legacy no-month mutation path available", async () => {
    const { updates, inserts } = fakeDb([
      [{ id: 7, agencyId: 8, username: "member01", isValid: 0 }],
    ]);
    await adminRouter
      .createCaller(context())
      .setMemberValidity({ memberId: 7, isValid: true });
    expect(updates).toEqual([{ isValid: 1 }]);
    expect(inserts[0]).toMatchObject({
      action: "member.validity_updated",
      entityType: "member_account",
    });
  });

  it("uses the selected month mark in Admin member rows without joining money sources", async () => {
    const { queries } = fakeDb([
      [
        {
          id: 7,
          agencyId: 8,
          agencyUsername: "agency01",
          agencyName: "Agency",
          username: "member01",
          fullName: "Member",
          phone: null,
          isValid: 1,
          joinedAt: new Date("2026-01-01"),
        },
      ],
      [],
      [],
      [],
      [],
      [{ memberId: 7, isValid: 0 }],
    ]);
    const rows = await adminRouter
      .createCaller(context())
      .members({ month: "2026-10" });
    expect(rows[0]).toMatchObject({
      id: 7,
      isValid: 0,
      totalDepositVnd: 0,
      totalWithdrawalVnd: 0,
      totalBetsVnd: 0,
      totalPromotionVnd: 0,
    });
    expect(queries).toHaveLength(6);
    expect(queries[5].locked).toBe(false);
  });

  it("rejects non-admin monthly writes before accessing the database", async () => {
    await expect(
      adminRouter
        .createCaller(context("user"))
        .setMemberValidity({ memberId: 7, month: "2026-10", isValid: true })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
});
