import { systemRouter } from "./_core/systemRouter";
import { router } from "./_core/trpc";
import { authRouter } from "./routers/auth";
import { adminRouter } from "./routers/admin";
import { agentRouter } from "./routers/agent";
import { registrationRouter } from "./routers/registration";
import { reportsRouter } from "./routers/reports";
import { accountRouter } from "./routers/account";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  registration: registrationRouter,
  agent: agentRouter,
  reports: reportsRouter,
  admin: adminRouter,
  auth: authRouter,
  account: accountRouter,

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
