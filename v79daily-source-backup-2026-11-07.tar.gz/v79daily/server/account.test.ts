import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { accountRouter } from "./routers/account";
import { authRouter } from "./routers/auth";
import { hashPassword, verifyPassword } from "./_core/password";
import { auditLogs, agencyCredentials, agencyNotifications, agencyNotificationReads } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn(), createSessionToken: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
vi.mock("./_core/sdk", () => ({ sdk: { createSessionToken: mock.createSessionToken } }));
const dialect = new MySqlDialect();
const oldPassword = "Old-secret-unit-42";
const newPassword = "New-secret-unit-73";
const input = { currentPassword: oldPassword, newPassword, confirmPassword: newPassword };
const resetInput = { agencyId: 8, newPassword, confirmPassword: newPassword, reason: "Đại lý quên mật khẩu" };
let oldHash: string;
beforeAll(async () => { oldHash = await hashPassword(oldPassword); });
beforeEach(() => { vi.clearAllMocks(); mock.createSessionToken.mockResolvedValue("new-session-unit-only"); });

function context(role: "user" | "admin" = "user", loginMethod = role === "admin" ? "google" : "password"): TrpcContext {
  return { user: { id: 42, openId: "agency-unit-test", name: "Unit", email: null, role, loginMethod, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { headers: {}, ip: "unit-address", socket: { remoteAddress: "unit-address" } } as TrpcContext["req"],
    res: { cookie: vi.fn() } as unknown as TrpcContext["res"] };
}
function account(extra: Record<string, unknown> = {}) {
  return { agencyId: 8, fullName: "Unit", status: "approved", role: "user", loginMethod: "password", passwordHash: oldHash, passwordVersion: 0, failedAttempts: 0, loginBlockedUntil: null, ...extra };
}
function fakeDb(results: unknown[][], failAudit = false) {
  const queries: Array<{ fields: Record<string, unknown>; filters: SQL[]; joins: SQL[]; locked: boolean; limit?: number }> = [];
  const updates: Array<{ table: unknown; values: any; filter?: SQL }> = [];
  const inserts: Array<{ table: unknown; values: any; duplicateSet?: Record<string, unknown> }> = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const result = results.shift() ?? [];
      const entry: typeof queries[number] = { fields, filters: [], joins: [], locked: false }; queries.push(entry);
      const chain: any = { from: () => chain, innerJoin: () => chain, leftJoin: (_table: unknown, join: SQL) => { entry.joins.push(join); return chain; },
        where: (filter: SQL) => { entry.filters.push(filter); return chain; },
        orderBy: () => chain, limit: (limit: number) => { entry.limit = limit; return chain; },
        for: () => { entry.locked = true; return chain; }, then: (resolve: (value: unknown[]) => unknown) => Promise.resolve(result).then(resolve) };
      return chain;
    }),
    update: vi.fn((table: unknown) => ({ set: (values: unknown) => { const update = { table, values } as typeof updates[number]; updates.push(update); return { where: async (filter: SQL) => { update.filter = filter; } }; } })),
    insert: vi.fn((table: unknown) => ({ values: (values: unknown) => {
      if (failAudit && table === auditLogs) throw new Error("unit-audit-failure");
      const entry: typeof inserts[number] = { table, values }; inserts.push(entry);
      return { $returningId: async () => [{ id: 123 }], then: (resolve: (value: undefined) => unknown) => Promise.resolve(undefined).then(resolve),
        onDuplicateKeyUpdate: ({ set }: { set: Record<string, unknown> }) => { entry.duplicateSet = set; return Promise.resolve(undefined); } };
    } })),
    transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) => {
      const u = updates.length, i = inserts.length;
      try { return await fn(db); } catch (error) { updates.splice(u); inserts.splice(i); throw error; }
    }),
  };
  mock.getDb.mockResolvedValue(db);
  return { db, queries, updates, inserts };
}
function params(filter: SQL) { return dialect.sqlToQuery(filter).params; }

 describe("agency password changes", () => {
  it("blocks guests, OAuth users and admins before touching credentials", async () => {
    await expect(accountRouter.createCaller({ ...context(), user: null }).changePassword(input)).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(accountRouter.createCaller(context("admin")).changePassword(input)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(accountRouter.createCaller(context("user", "google")).changePassword(input)).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it("rejects short/mismatched/reused passwords and caller-supplied agency IDs", async () => {
    const caller = accountRouter.createCaller(context());
    for (const invalid of [ { ...input, newPassword: "short", confirmPassword: "short" }, { ...input, confirmPassword: "different-unit" }, { ...input, newPassword: oldPassword, confirmPassword: oldPassword }, { ...input, agencyId: 99 } ]) {
      await expect(caller.changePassword(invalid as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    }
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it.each(["pending", "locked", "rejected"])("does not change credentials for a %s agency", async (status) => {
    const { updates } = fakeDb([[account({ status })]]);
    await expect(accountRouter.createCaller(context()).changePassword(input)).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(updates).toHaveLength(0);
  });
  it("persists the wrong-password counter without changing the hash/version or cookie", async () => {
    const ctx = context(); const { updates, inserts, queries } = fakeDb([[account()]]);
    await expect(accountRouter.createCaller(ctx).changePassword({ ...input, currentPassword: "Wrong-unit-secret" })).rejects.toMatchObject({ code: "BAD_REQUEST", message: "Mật khẩu cũ không chính xác." });
    expect(updates[0].values).toEqual({ failedAttempts: 1, loginBlockedUntil: null });
    expect(params(updates[0].filter!)).toEqual([8]);
    expect(params(queries[0].filters[0])).toEqual([42]);
    expect(queries[0].locked).toBe(true); expect(inserts).toHaveLength(0); expect(ctx.res.cookie).not.toHaveBeenCalled();
  });
  it("locks for fifteen minutes on the eighth failure and refuses already blocked accounts", async () => {
    const before = Date.now(); const { updates } = fakeDb([[account({ failedAttempts: 7 })]]);
    await expect(accountRouter.createCaller(context()).changePassword({ ...input, currentPassword: "Wrong-unit-secret" })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(updates[0].values.failedAttempts).toBe(0);
    expect(updates[0].values.loginBlockedUntil.getTime()).toBeGreaterThanOrEqual(before + 15 * 60 * 1000);
    const blocked = fakeDb([[account({ loginBlockedUntil: new Date(Date.now() + 60000) })]]);
    await expect(accountRouter.createCaller(context()).changePassword(input)).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(blocked.updates).toHaveLength(0);
  });
  it("stores a salted hash, increments version, audits no secret and rotates only the current session", async () => {
    const ctx = context(); const { updates, inserts, queries } = fakeDb([[account({ passwordVersion: 2 })]]);
    expect(await accountRouter.createCaller(ctx).changePassword(input)).toEqual({ success: true });
    const stored = updates[0].values;
    expect(updates[0].table).toBe(agencyCredentials); expect(stored.passwordVersion).toBe(3);
    expect(stored.passwordHash).toMatch(/^scrypt\$/); expect(stored.passwordHash).not.toBe(oldHash);
    expect(await verifyPassword(newPassword, stored.passwordHash)).toBe(true);
    expect(await verifyPassword(oldPassword, stored.passwordHash)).toBe(false);
    expect(queries[0].locked).toBe(true);
    expect(inserts[0].values).toMatchObject({ action: "agency.password_changed", actorUserId: 42, entityId: 8 });
    for (const secret of [oldPassword, newPassword, oldHash, stored.passwordHash]) expect(JSON.stringify(inserts.map((entry) => entry.values))).not.toContain(secret);
    expect(mock.createSessionToken).toHaveBeenCalledWith("agency-unit-test", expect.objectContaining({ passwordVersion: 3 }));
    expect(ctx.res.cookie).toHaveBeenCalledWith(expect.any(String), "new-session-unit-only", expect.objectContaining({ httpOnly: true, secure: true, sameSite: "none" }));
  });
  it("rolls back the credential update if the audit fails", async () => {
    const ctx = context(); const { updates, inserts } = fakeDb([[account()]], true);
    await expect(accountRouter.createCaller(ctx).changePassword(input)).rejects.toThrow("unit-audit-failure");
    expect(updates).toHaveLength(0); expect(inserts).toHaveLength(0); expect(ctx.res.cookie).not.toHaveBeenCalled();
  });
  it("signs password login sessions with the existing credential version", async () => {
    const ctx = context(); fakeDb([[{ ...account(), userId: 42, openId: "agency-unit-test", name: "Unit", passwordVersion: 4 }]]);
    await authRouter.createCaller(ctx).loginWithPassword({ username: "unitagency", password: oldPassword });
    expect(mock.createSessionToken).toHaveBeenCalledWith("agency-unit-test", expect.objectContaining({ passwordVersion: 4 }));
  });
  it("locks login counters and commits an eighth failed attempt without issuing a session", async () => {
    const ctx = context(); const { updates, queries, inserts } = fakeDb([[account({ failedAttempts: 7 })]]);
    await expect(authRouter.createCaller(ctx).loginWithPassword({ username: "unitloginlocked", password: "Wrong-unit-password" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(queries[0].locked).toBe(true);
    expect(updates[0].values.failedAttempts).toBe(0);
    expect(updates[0].values.loginBlockedUntil.getTime()).toBeGreaterThan(Date.now());
    expect(params(updates[0].filter!)).toEqual([8]);
    expect(inserts).toHaveLength(0); expect(ctx.res.cookie).not.toHaveBeenCalled();
  });
});

 describe("admin password recovery", () => {
  it("blocks guests/agencies and password-authenticated admin sessions", async () => {
    await expect(accountRouter.createCaller({ ...context(), user: null }).resetAgencyPassword(resetInput)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(accountRouter.createCaller(context()).resetAgencyPassword(resetInput)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(accountRouter.createCaller(context("admin", "password")).resetAgencyPassword(resetInput)).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it("requires matching new passwords and rejects a reason containing the secret", async () => {
    for (const invalid of [{ ...resetInput, confirmPassword: "different" }, { ...resetInput, reason: `Forgot ${newPassword}` }]) {
      await expect(accountRouter.createCaller(context("admin")).resetAgencyPassword(invalid)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    }
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it("resets without knowing the old password, clears throttling and leaves profile lock unchanged", async () => {
    const ctx = context("admin"); const { updates, inserts, queries } = fakeDb([[account({ status: "locked", passwordVersion: 4, failedAttempts: 7 })]]);
    expect(await accountRouter.createCaller(ctx).resetAgencyPassword(resetInput)).toEqual({ success: true });
    expect(queries[0].locked).toBe(true); expect(params(queries[0].filters[0])).toEqual([8]);
    expect(updates).toHaveLength(1); expect(updates[0].table).toBe(agencyCredentials);
    expect(updates[0].values).toMatchObject({ passwordVersion: 5, failedAttempts: 0, loginBlockedUntil: null });
    expect(await verifyPassword(newPassword, updates[0].values.passwordHash)).toBe(true);
    expect(inserts[0].values).toMatchObject({ action: "agency.password_reset", actorUserId: 42, entityId: 8 });
    expect(JSON.parse(inserts[0].values.details)).toMatchObject({ allSessionsRevoked: true, reason: resetInput.reason });
    for (const secret of [newPassword, oldPassword, oldHash]) expect(JSON.stringify(inserts.map((entry) => entry.values))).not.toContain(secret);
    expect(mock.createSessionToken).not.toHaveBeenCalled(); expect(ctx.res.cookie).not.toHaveBeenCalled();
  });
  it("refuses missing/OAuth/admin target accounts", async () => {
    fakeDb([[]]); await expect(accountRouter.createCaller(context("admin")).resetAgencyPassword(resetInput)).rejects.toMatchObject({ code: "NOT_FOUND" });
    const { updates } = fakeDb([[account({ role: "admin", loginMethod: "google" })]]);
    await expect(accountRouter.createCaller(context("admin")).resetAgencyPassword(resetInput)).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(updates).toHaveLength(0);
  });
});

 describe("scoped persistent notifications", () => {
  it("prevents agencies/guests from sending messages or reading admin history", async () => {
    const caller = accountRouter.createCaller(context());
    await expect(caller.sendNotification({ agencyId: 8, title: "Tin mới", body: "Unit message" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.sentNotifications()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(accountRouter.createCaller({ ...context(), user: null }).notifications(undefined)).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it("persists the intended agency recipient and sender, together with an audit", async () => {
    const { inserts, queries } = fakeDb([[{ id: 8 }]]);
    expect(await accountRouter.createCaller(context("admin")).sendNotification({ agencyId: 8, title: " Tin riêng ", body: " Nội dung riêng " })).toEqual({ id: 123, imageStored: true });
    expect(params(queries[0].filters[0])).toEqual([8]);
    expect(inserts[0]).toEqual({ table: agencyNotifications, values: { agencyId: 8, title: "Tin riêng", body: "Nội dung riêng", imageKey: null, createdBy: 42 } });
    expect(inserts[1].values).toMatchObject({ action: "agency.notification_sent", entityId: 123 });
  });
  it("stores a broadcast once and rejects non-existent recipients without inserts", async () => {
    const broad = fakeDb([]);
    await accountRouter.createCaller(context("admin")).sendNotification({ agencyId: null, title: "Tin chung", body: "Nội dung" });
    expect(broad.queries).toHaveLength(0); expect(broad.inserts[0].values.agencyId).toBeNull();
    const missing = fakeDb([[]]);
    await expect(accountRouter.createCaller(context("admin")).sendNotification({ agencyId: 999, title: "Tin riêng", body: "Nội dung" })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(missing.inserts).toHaveLength(0);
  });
  it("filters notices by this agency OR broadcasts, and all money events by this agency alone", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }],
      [{ id: 1, title: "Thông báo", body: "Tin chung\nDòng 2", imageKey: "malformed/unsafe-path", createdAt: new Date("2026-10-14T00:00:00Z") }],
      [{ id: 2, amountVnd: 1000, reason: "Hoa hồng", createdAt: new Date("2026-10-14T01:00:00Z") }],
      [{ id: 3, amountVnd: 1000, status: "approved", requestedAt: new Date("2026-10-14T02:00:00Z"), reviewedAt: new Date("2026-10-14T03:00:00Z") }]]);
    const result = await accountRouter.createCaller(context()).notifications(undefined);
    expect(params(queries[0].filters[0])).toEqual([42]);
    const scope = dialect.sqlToQuery(queries[1].filters[0]);
    expect(scope.sql).toContain("or"); expect(scope.sql).toContain("is null"); expect(scope.params).toEqual([8]);
    expect(params(queries[2].filters[0])).toEqual([8]); expect(params(queries[3].filters[0])).toEqual([8]);
    expect(result.map((item) => item.id)).toEqual(["withdrawal-3", "credit-2", "notice-1"]);
    expect(result[0].message).not.toMatch(/đã chuyển|đã chi trả/); expect(result[2].amountVnd).toBeNull();
    expect(Object.keys(queries[1].fields).sort()).toEqual(["body", "createdAt", "id", "imageKey", "readAt", "title"]);
    expect(result.find((item) => item.id === "notice-1")?.imageAvailable).toBe(false);
    expect(result.find((item) => item.id === "notice-1")).not.toHaveProperty("imageKey");
  });
  it("returns an empty feed honestly and blocks unapproved agencies", async () => {
    fakeDb([[{ id: 8, status: "approved" }], [], [], []]); expect(await accountRouter.createCaller(context()).notifications(undefined)).toEqual([]);
    const locked = fakeDb([[{ id: 8, status: "locked" }]]);
    await expect(accountRouter.createCaller(context()).notifications(undefined)).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(locked.queries).toHaveLength(1);
  });
  it("rolls back a sent message if the audit fails", async () => {
    const { inserts } = fakeDb([], true);
    await expect(accountRouter.createCaller(context("admin")).sendNotification({ agencyId: null, title: "Tin chung", body: "Unit" })).rejects.toThrow("unit-audit-failure");
    expect(inserts).toHaveLength(0);
  });
});

describe("unread notification counts and receipts", () => {
  const profile = { id: 8, status: "approved" };
  it("blocks guests, OAuth users and admins before notification access", async () => {
    await expect(accountRouter.createCaller({ ...context(), user: null }).notificationUnreadCount(undefined)).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    for (const ctx of [context("admin"), context("user", "google")]) {
      await expect(accountRouter.createCaller(ctx).notificationUnreadCount(undefined)).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(accountRouter.createCaller(ctx).markNotificationsRead({ eventKeys: ["notice-1"] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it.each(["pending", "rejected", "locked"])("blocks count/read for a %s agency", async (status) => {
    fakeDb([[{ ...profile, status }]]);
    await expect(accountRouter.createCaller(context()).notificationUnreadCount(undefined)).rejects.toMatchObject({ code: "FORBIDDEN" });
    const { inserts } = fakeDb([[{ ...profile, status }]]);
    await expect(accountRouter.createCaller(context()).markNotificationsRead({ eventKeys: ["notice-1"] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(inserts).toHaveLength(0);
  });
  it("counts all sources beyond the 30-row feed and isolates receipts by agency", async () => {
    const { queries } = fakeDb([[profile], [{ count: 120 }], [{ count: "7" }], [{ count: 3 }]]);
    expect(await accountRouter.createCaller(context()).notificationUnreadCount({ cacheKey: 999 })).toEqual({ count: 130 });
    expect(params(queries[0].filters[0])).toEqual([42]);
    for (const query of queries.slice(1)) {
      expect(query.limit).toBeUndefined();
      expect(params(query.joins[0])).toEqual([8]);
      const filter = dialect.sqlToQuery(query.filters[0]);
      expect(filter.params).toEqual([8]); expect(filter.sql).toContain("is null");
    }
    expect(dialect.sqlToQuery(queries[3].joins[0]).sql).toContain("status");
  });
  it("returns zero honestly and refuses invalid/overflow counts", async () => {
    fakeDb([[profile], [{ count: 0 }], [{ count: 0 }], [{ count: 0 }]]);
    expect(await accountRouter.createCaller(context()).notificationUnreadCount(undefined)).toEqual({ count: 0 });
    fakeDb([[profile], [{ count: -1 }], [{ count: 0 }], [{ count: 0 }]]);
    await expect(accountRouter.createCaller(context()).notificationUnreadCount(undefined)).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
    fakeDb([[profile], [{ count: Number.MAX_SAFE_INTEGER }], [{ count: 1 }], [{ count: 0 }]]);
    await expect(accountRouter.createCaller(context()).notificationUnreadCount(undefined)).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });
  it("adds read metadata while retaining old feed IDs and scopes unread-only queries", async () => {
    const date = new Date("2026-10-16T00:00:00Z");
    const { queries } = fakeDb([[profile], [{ id: 1, title: "Tin", body: "Nội dung", createdAt: date, readAt: date }], [],
      [{ id: 3, amountVnd: 1000, status: "approved", requestedAt: date, reviewedAt: date, readAt: null }]]);
    const result = await accountRouter.createCaller(context()).notifications({ unreadOnly: true, cacheKey: 999 });
    expect(result.find((item) => item.id === "notice-1")).toMatchObject({ eventKey: "notice-1", isRead: true, readAt: date });
    expect(result.find((item) => item.id === "withdrawal-3")).toMatchObject({ eventKey: "withdrawal-3-approved", isRead: false, readAt: null });
    for (const query of queries.slice(1)) {
      expect(query.limit).toBe(30); expect(params(query.joins[0])).toEqual([8]);
      expect(dialect.sqlToQuery(query.filters[0]).sql).toContain("is null");
    }
  });
  it("validates the batch and rejects recipient/agency spoofing before DB access", async () => {
    const caller = accountRouter.createCaller(context());
    for (const eventKeys of [[], Array.from({ length: 31 }, (_, i) => `notice-${i + 1}`), ["notice-0"], ["withdrawal-1-paid"], ["arbitrary"], ["notice-1; drop table users"]]) {
      await expect(caller.markNotificationsRead({ eventKeys })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    }
    await expect(caller.markNotificationsRead({ eventKeys: ["notice-1"], agencyId: 99 } as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
  it("rechecks the profile under lock and refuses newly locked accounts", async () => {
    const { inserts, queries } = fakeDb([[profile], [{ ...profile, status: "locked" }]]);
    await expect(accountRouter.createCaller(context()).markNotificationsRead({ eventKeys: ["notice-1"] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(queries[1].locked).toBe(true); expect(params(queries[1].filters[0])).toEqual([8, 42]);
    expect(inserts).toHaveLength(0);
  });
  it("only upserts the viewed keys for this agency and keeps original readAt on retries", async () => {
    const { inserts, queries } = fakeDb([[profile], [profile], [{ id: 1 }], [{ id: 2 }], [{ id: 3, status: "approved" }]]);
    const keys = ["notice-1", "credit-2", "withdrawal-3-approved"];
    expect(await accountRouter.createCaller(context()).markNotificationsRead({ eventKeys: [...keys, "notice-1"] })).toEqual({ markedKeys: keys });
    expect(inserts).toHaveLength(1); expect(inserts[0].table).toBe(agencyNotificationReads);
    expect(inserts[0].values).toEqual(keys.map((eventKey) => ({ agencyId: 8, eventKey })));
    expect(dialect.sqlToQuery(inserts[0].duplicateSet!.readAt as SQL).sql).toContain("read_at");
    expect(params(queries[2].filters[0])).toEqual([8, 1]);
    expect(params(queries[3].filters[0])).toEqual([8, 2]); expect(params(queries[4].filters[0])).toEqual([8, 3]);
    expect(queries[1].locked).toBe(true); expect(queries[4].locked).toBe(true);
  });
  it("cannot mark another agency's message or money event as read", async () => {
    for (const key of ["notice-99", "credit-99", "withdrawal-99-pending"]) {
      const { inserts } = fakeDb([[profile], [profile], []]);
      await expect(accountRouter.createCaller(context()).markNotificationsRead({ eventKeys: [key] })).rejects.toMatchObject({ code: "NOT_FOUND" });
      expect(inserts).toHaveLength(0);
    }
  });
  it("rejects stale/future withdrawal states instead of pre-reading the approval", async () => {
    for (const [key, status] of [["withdrawal-3-approved", "pending"], ["withdrawal-3-pending", "approved"]]) {
      const { inserts } = fakeDb([[profile], [profile], [{ id: 3, status }]]);
      await expect(accountRouter.createCaller(context()).markNotificationsRead({ eventKeys: [key] })).rejects.toMatchObject({ code: "CONFLICT" });
      expect(inserts).toHaveLength(0);
    }
  });
  it("stores pending and later approved as separate events", async () => {
    const { inserts } = fakeDb([[profile], [profile], [{ id: 3, status: "pending" }], [profile], [profile], [{ id: 3, status: "approved" }]]);
    const caller = accountRouter.createCaller(context());
    await caller.markNotificationsRead({ eventKeys: ["withdrawal-3-pending"] });
    await caller.markNotificationsRead({ eventKeys: ["withdrawal-3-approved"] });
    expect(inserts.map((entry) => entry.values[0].eventKey)).toEqual(["withdrawal-3-pending", "withdrawal-3-approved"]);
  });
});
