import { useEffect } from "react";
import { useLocation } from "wouter";
import { Activity, ArrowRight, LoaderCircle, LogOut, ShieldCheck } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { V79_LOGO_SRC } from "@/brand";
import "@/styles/auth.css";

export default function AdminLogin() {
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const denied = typeof window !== "undefined" && new URLSearchParams(window.location.search).get("denied") === "1";

  useEffect(() => {
    if (auth.user?.role === "admin") setLocation("/admin");
  }, [auth.user?.role, setLocation]);

  function beginAdminLogin() {
    try {
      startLogin();
    } catch {
      // A failed navigation leaves the sign-in action available for retry.
    }
  }

  return (
    <main className="admin-login-screen">
      <section className="admin-login-card" aria-label="Đăng nhập quản trị V79">
        <img src={V79_LOGO_SRC} alt="V79" className="admin-login-logo" />
        <div className="admin-login-icon"><ShieldCheck size={24} /></div>
        <h1>Quản trị V79</h1>
        <p className="admin-login-copy">Khu vực này chỉ dành cho tài khoản quản trị viên đã được cấp quyền.</p>
        {auth.loading ? (
          <div className="admin-login-message" role="status"><LoaderCircle className="auth-spin" size={18} /> Đang xác minh phiên Manus…</div>
        ) : auth.user?.role === "admin" ? (
          <div className="admin-login-message admin-login-success"><ShieldCheck size={18} /> Đã xác minh quyền quản trị.<button type="button" onClick={() => setLocation("/admin")}>Mở trang admin <ArrowRight size={15} /></button></div>
        ) : auth.user ? (
          <div className="admin-login-message admin-login-denied" role="alert">
            <ShieldCheck size={18} /> Tài khoản đang đăng nhập không có quyền quản trị.
            <button type="button" className="admin-login-secondary" onClick={() => void auth.logout().then(() => setLocation("/admin/login"))}><LogOut size={15} /> Đăng xuất phiên hiện tại</button>
          </div>
        ) : (
          <>
            {(denied || auth.error) && <div className="admin-login-message admin-login-denied" role="alert">{denied ? "Tài khoản Manus này chưa được cấp quyền quản trị." : "Không thể xác minh phiên đăng nhập. Vui lòng thử lại."}</div>}
            <button type="button" className="oauth-main-button admin-login-button" onClick={beginAdminLogin}><ShieldCheck size={17} /> Đăng nhập bằng Manus <ArrowRight size={17} /></button>
          </>
        )}
        <div className="admin-login-footer"><Activity size={14} /> Quyền truy cập được kiểm tra ở máy chủ.</div>
      </section>
    </main>
  );
}
