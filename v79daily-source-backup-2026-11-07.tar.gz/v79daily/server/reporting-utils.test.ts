import { describe, expect, it } from "vitest";
import { parseVietnamDateTime, safeVndTotal } from "./reporting-utils";

describe("strict Vietnam transaction datetime", () => {
  it("rejects calendar rollover and invalid clock values", () => {
    for (const value of ["2024-02-31T23:30", "2024-04-31T00:00", "2026-02-29T12:00", "2026-10-01T24:00", "2026-10-01T12:60", "2026-13-01T12:00"]) {
      expect(parseVietnamDateTime(value)).toBeNull();
    }
  });
  it("accepts leap days and converts month boundaries to Vietnam UTC offset", () => {
    expect(parseVietnamDateTime("2024-02-29T00:00")?.toISOString()).toBe("2024-02-28T17:00:00.000Z");
    expect(parseVietnamDateTime("2026-11-01T00:00")?.toISOString()).toBe("2026-10-31T17:00:00.000Z");
  });
});

describe("precise VND totals", () => {
  it("accepts signed integers and empty totals", () => {
    expect(safeVndTotal("-200")).toBe(-200);
    expect(safeVndTotal(null)).toBe(0);
    expect(safeVndTotal(String(Number.MAX_SAFE_INTEGER))).toBe(Number.MAX_SAFE_INTEGER);
  });
  it("rejects unsafe totals rather than rounding financial results", () => {
    expect(() => safeVndTotal("9007199254740992")).toThrow();
    expect(() => safeVndTotal("invalid")).toThrow();
    expect(() => safeVndTotal("1.5")).toThrow();
  });
});
