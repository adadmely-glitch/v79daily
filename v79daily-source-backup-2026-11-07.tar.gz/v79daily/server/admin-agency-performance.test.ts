import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { adminRouter } from "./routers/admin";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
const dialect = new MySqlDialect();

type Query = {
  fields: Record<string, unknown>;
  filters: SQL[];
  joins: SQL[];
  grouped: boolean;
};

function context(role: "admin" | "user" = "admin"): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "test",
      email: null,
      name: "Test",
      loginMethod: "password",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function fakeDb(resultSets: unknown[][]) {
  const queries: Query[] = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const result = resultSets.shift() ?? [];
      const entry: Query = { fields, filters: [], joins: [], grouped: false };
      queries.push(entry);
      const chain: any = {
        from: () => chain,
        where: (filter: SQL) => {
          entry.filters.push(filter);
          return chain;
        },
        innerJoin: (_table: unknown, filter: SQL) => {
          entry.joins.push(filter);
          return chain;
        },
        groupBy: () => {
          entry.grouped = true;
          return chain;
        },
        orderBy: () => chain,
        then: (resolve: (rows: unknown[]) => unknown) =>
          Promise.resolve(result).then(resolve),
      };
      return chain;
    }),
  };
  mock.getDb.mockResolvedValue(db);
  return { queries };
}

const sqlQuery = (query: SQL) => dialect.sqlToQuery(query);
const monthStart = "2026-09-30T17:00:00.000Z";
const monthEnd = "2026-10-31T17:00:00.000Z";

function agencyResults(
  overrides: Partial<
    Record<
      | "profiles"
      | "credits"
      | "held"
      | "members"
      | "deposits"
      | "withdrawals"
      | "bets"
      | "adjustments"
      | "depositsByMember"
      | "depositAdjustmentsByMember"
      | "validity",
      unknown[]
    >
  > = {}
) {
  return [
    overrides.profiles ?? [
      {
        id: 8,
        userId: 80,
        username: "agency01",
        fullName: "Agency One",
        phone: "080",
        status: "approved",
        referralLink: null,
        createdAt: new Date("2026-01-01"),
        email: "one@example.com",
        lastSignedIn: null,
      },
      {
        id: 9,
        userId: 90,
        username: "agency02",
        fullName: "Agency Two",
        phone: "090",
        status: "approved",
        referralLink: null,
        createdAt: new Date("2026-01-02"),
        email: "two@example.com",
        lastSignedIn: null,
      },
      {
        id: 10,
        userId: 100,
        username: "agency03",
        fullName: "Agency Three",
        phone: "010",
        status: "approved",
        referralLink: null,
        createdAt: new Date("2026-01-03"),
        email: "three@example.com",
        lastSignedIn: null,
      },
    ],
    overrides.credits ?? [{ agencyId: 8, total: "100000" }],
    overrides.held ?? [{ agencyId: 8, total: "25000" }],
    overrides.members ?? [
      { agencyId: 8, total: 4 },
      { agencyId: 9, total: 1 },
    ],
    overrides.deposits ?? [
      { agencyId: 8, total: "1000" },
      { agencyId: 9, total: "900" },
    ],
    overrides.withdrawals ?? [{ agencyId: 8, total: "300" }],
    overrides.bets ?? [
      {
        agencyId: 8,
        total: "5000",
        validBetTotal: "4000",
        promotionTotal: "1234",
        winLossTotal: "-50",
      },
      {
        agencyId: 9,
        total: "100",
        validBetTotal: "80",
        promotionTotal: null,
        winLossTotal: "25",
      },
    ],
    overrides.adjustments ?? [
      { agencyId: 8, depositDeltaVnd: "50", withdrawalDeltaVnd: "-10" },
    ],
    overrides.depositsByMember ?? [
      { agencyId: 8, memberId: 1, total: "100" },
      { agencyId: 8, memberId: 1, total: "200" },
      { agencyId: 8, memberId: 4, total: "200" },
      { agencyId: 9, memberId: 5, total: "900" },
    ],
    overrides.depositAdjustmentsByMember ?? [
      { agencyId: 8, memberId: 1, depositDeltaVnd: "-300" },
      { agencyId: 8, memberId: 2, depositDeltaVnd: "25" },
      { agencyId: 8, memberId: 4, depositDeltaVnd: "-50" },
      { agencyId: 9, memberId: 5, depositDeltaVnd: "-900" },
    ],
    overrides.validity ?? [
      { agencyId: 8, total: 2 },
      { agencyId: 9, total: 1 },
    ],
  ];
}

beforeEach(() => vi.clearAllMocks());

describe("Admin agency performance", () => {
  it("returns selected-month promotion, unique positive depositors, monthly validity, and unchanged financial fields", async () => {
    const { queries } = fakeDb(agencyResults());
    const rows = await adminRouter
      .createCaller(context())
      .agencies({ month: "2026-10" });

    expect(rows[0]).toMatchObject({
      id: 8,
      activityMonth: "2026-10",
      creditedVnd: 100000,
      reservedVnd: 25000,
      availableVnd: 75000,
      memberCount: 4,
      monthDepositVnd: 1050,
      monthMemberWithdrawalVnd: 290,
      monthBetsVnd: 5000,
      monthPromotionVnd: 1234,
      monthDepositorCount: 2,
      monthValidMemberCount: 2,
      monthValidBetsVnd: 4000,
      monthWinLossVnd: -1994,
    });
    expect(rows[1]).toMatchObject({
      id: 9,
      memberCount: 1,
      monthPromotionVnd: 0,
      monthDepositorCount: 0,
      monthValidMemberCount: 1,
    });
    expect(rows[2]).toMatchObject({
      id: 10,
      creditedVnd: 0,
      reservedVnd: 0,
      availableVnd: 0,
      memberCount: 0,
      monthDepositVnd: 0,
      monthMemberWithdrawalVnd: 0,
      monthBetsVnd: 0,
      monthPromotionVnd: 0,
      monthDepositorCount: 0,
      monthValidMemberCount: 0,
      monthValidBetsVnd: 0,
      monthWinLossVnd: 0,
    });

    expect(queries).toHaveLength(11);
    expect(Object.keys(queries[6].fields).sort()).toEqual([
      "agencyId", "promotionTotal", "refundTotal", "total", "validBetTotal",
    ]);
    expect(sqlQuery(queries[6].filters[0]).params).toEqual(["2026-10"]);
    expect(sqlQuery(queries[8].filters[0]).params.slice(0, 1)).toEqual([
      "deposit",
    ]);
    expect(
      sqlQuery(queries[8].filters[0])
        .params.slice(1)
        .map((value: any) => new Date(value).toISOString())
    ).toEqual([monthStart, monthEnd]);
    expect(sqlQuery(queries[9].filters[0]).params).toEqual(["2026-10"]);
    expect(sqlQuery(queries[10].filters[0]).params).toEqual(["2026-10", 1]);
    expect(queries[8].grouped).toBe(true);
    expect(queries[9].grouped).toBe(true);
    expect(queries[10].grouped).toBe(true);
    expect(queries[8].joins).toHaveLength(1);
    expect(queries[9].joins).toHaveLength(1);
    expect(queries[10].joins).toHaveLength(1);
  });

  it("keeps validity month-scoped and returns zero for missing aggregate rows", async () => {
    const { queries } = fakeDb(
      agencyResults({
        bets: [
          {
            agencyId: 8,
            total: "0",
            validBetTotal: "0",
            promotionTotal: null,
            winLossTotal: "0",
          },
        ],
        validity: [],
      })
    );
    const rows = await adminRouter
      .createCaller(context())
      .agencies({ month: "2026-11" });

    expect(rows[0]).toMatchObject({
      activityMonth: "2026-11",
      monthPromotionVnd: 0,
      monthValidMemberCount: 0,
    });
    expect(queries[10].joins).toHaveLength(1);
    expect(sqlQuery(queries[10].filters[0]).params).toEqual(["2026-11", 1]);
  });

  it("rejects unsafe promotion and depositor money aggregates instead of rounding", async () => {
    fakeDb(
      agencyResults({
        bets: [
          {
            agencyId: 8,
            total: "0",
            validBetTotal: "0",
            promotionTotal: "9007199254740993",
            winLossTotal: "0",
          },
        ],
      })
    );
    await expect(
      adminRouter.createCaller(context()).agencies({ month: "2026-10" })
    ).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });

    fakeDb(
      agencyResults({
        bets: [],
        depositsByMember: [
          { agencyId: 8, memberId: 1, total: "9007199254740991" },
        ],
        depositAdjustmentsByMember: [
          { agencyId: 8, memberId: 1, depositDeltaVnd: "1" },
        ],
      })
    );
    await expect(
      adminRouter.createCaller(context()).agencies({ month: "2026-10" })
    ).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("enforces Admin RBAC before reading agency performance", async () => {
    await expect(
      adminRouter.createCaller(context("user")).agencies({ month: "2026-10" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
});
