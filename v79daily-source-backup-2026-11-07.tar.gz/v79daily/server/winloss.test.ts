import { describe, expect, it } from "vitest";
import { winLossClass } from "../client/src/lib/winloss";

describe("win/loss sign colors", () => {
  it.each([1, 300000, Number.MAX_SAFE_INTEGER])("uses green for positive value %s", (value) => {
    expect(winLossClass(value)).toBe("win-loss-positive");
  });

  it.each([-1, -300000, Number.MIN_SAFE_INTEGER])("uses red for negative value %s", (value) => {
    expect(winLossClass(value)).toBe("win-loss-negative");
  });

  it.each([0, -0, null, undefined, Number.NaN, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY])("keeps the base color for neutral/missing value %s", (value) => {
    expect(winLossClass(value)).toBe("win-loss-neutral");
  });
});
