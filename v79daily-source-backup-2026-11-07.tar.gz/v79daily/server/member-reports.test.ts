import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { adminRouter } from "./routers/admin";
import { reportsRouter } from "./routers/reports";
import { agentRouter } from "./routers/agent";
import type { TrpcContext } from "./_core/context";
import { MIN_BANK_WITHDRAWAL_VND, MIN_USDT_WITHDRAWAL_VND, withdrawalMinimumMessage } from "../shared/withdrawal-limits";
import { calculateMonthlyWinLossVnd, vietnamMonthKey } from "../shared/monthly-report";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
const dialect = new MySqlDialect();

function context(role: "admin" | "user" = "user"): TrpcContext {
  return {
    user: { id: 42, openId: "test", email: null, name: "Test", loginMethod: "password", role,
      createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function fakeDb(resultSets: unknown[][]) {
  const queries: Array<{ fields: Record<string, unknown>; filters: SQL[]; joins: SQL[]; grouped: boolean; locked: boolean }> = [];
  const updates: unknown[] = [];
  const inserts: unknown[] = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const result = resultSets.shift() ?? [];
      const entry = { fields, filters: [] as SQL[], joins: [] as SQL[], grouped: false, locked: false };
      queries.push(entry);
      const chain: any = {
        from: () => chain,
        where: (filter: SQL) => { entry.filters.push(filter); return chain; },
        innerJoin: (_table: unknown, filter: SQL) => { entry.joins.push(filter); return chain; },
        leftJoin: (_table: unknown, filter: SQL) => { entry.joins.push(filter); return chain; },
        groupBy: () => { entry.grouped = true; return chain; },
        orderBy: () => chain,
        limit: () => chain,
        for: () => { entry.locked = true; return chain; },
        then: (resolve: (rows: unknown[]) => unknown) => Promise.resolve(result).then(resolve),
      };
      return chain;
    }),
    update: vi.fn(() => ({ set: (values: unknown) => { updates.push(values); return { where: vi.fn(async () => undefined) }; } })),
    insert: vi.fn(() => ({ values: (values: unknown) => { inserts.push(values); return { $returningId: async () => [{ id: 999 }], then: (resolve: (value: undefined) => unknown) => Promise.resolve(undefined).then(resolve) }; } })),
    transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) => fn(db)),
  };
  mock.getDb.mockResolvedValue(db);
  return { db, queries, updates, inserts };
}
function sqlQuery(sql: SQL) { return dialect.sqlToQuery(sql); }

beforeEach(() => { vi.clearAllMocks(); });

describe("withdrawal precision", () => {
  it("stores converted VND exactly once under the agency lock", async () => {
    const { queries, inserts } = fakeDb([
      [{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }],
      [{ id: 1, bankName: "QA", accountNumber: "0000", ownerName: "QA", branch: "QA" }],
      [{ total: "1000000" }], [{ total: "0" }],
    ]);
    await agentRouter.createCaller(context()).createWithdrawal({ bankAccountId: 1, amountVnd: 1000000 });
    expect(queries[1].locked).toBe(true);
    expect(inserts[0]).toMatchObject({ amountVnd: 1000000, agencyId: 8 });
    expect(JSON.parse((inserts[1] as any).details)).toMatchObject({ amountVnd: 1000000 });
  });

  it("refuses an unsafe balance aggregate before inserting a withdrawal", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], [{ id: 1 }], [{ total: "9007199254740993" }], [{ total: "0" }]]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ bankAccountId: 1, amountVnd: MIN_BANK_WITHDRAWAL_VND })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
    expect(inserts).toHaveLength(0);
  });

  it("refuses withdrawals above actual VND availability", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], [{ id: 1 }], [{ total: "1000000" }], [{ total: "500000" }]]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ bankAccountId: 1, amountVnd: 500001 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(inserts).toHaveLength(0);
  });

  it("refuses unsafe withdrawal values before returning agency or admin responses", async () => {
    fakeDb([[{ id: 8, status: "approved" }], [{ id: 1, amountVnd: Number.MAX_SAFE_INTEGER + 1 }]]);
    await expect(agentRouter.createCaller(context()).withdrawals()).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
    fakeDb([[{ id: 1, amountVnd: Number.MAX_SAFE_INTEGER + 1 }]]);
    await expect(adminRouter.createCaller(context("admin")).withdrawals()).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("refuses unsafe bet values before returning the monthly report", async () => {
    fakeDb([[{ id: 8, status: "approved" }], [{ memberId: 1, amountVnd: Number.MAX_SAFE_INTEGER + 1, validBetVnd: 0, netWinLossVnd: 0 }]]);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ kind: "bets", month: "2026-10" })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });
});

describe("monthly agency reports", () => {
  it("requires authentication and a selected month", async () => {
    const guest = reportsRouter.createCaller({ ...context(), user: null });
    await expect(guest.agentMonthly({ kind: "transactions", month: "2026-10" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    const caller = reportsRouter.createCaller(context());
    await expect(caller.agentMonthly({ kind: "transactions", month: "" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("blocks locked agencies", async () => {
    fakeDb([[{ id: 8, status: "locked" }]]);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ kind: "bets", month: "2026-10" }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("returns deposit minus withdrawal, including negative and zero balances", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }], [
      { memberId: 1, username: "a", totalDepositVnd: "1000", totalWithdrawalVnd: "300" },
      { memberId: 2, username: "b", totalDepositVnd: "100", totalWithdrawalVnd: "200" },
      { memberId: 3, username: "c", totalDepositVnd: null, totalWithdrawalVnd: null },
    ]]);
    const result = await reportsRouter.createCaller(context()).agentMonthly({ kind: "transactions", month: "2026-10" });
    expect(result.rows).toEqual([
      { memberId: 1, username: "a", totalDepositVnd: 1000, totalWithdrawalVnd: 300, differenceVnd: 700 },
      { memberId: 2, username: "b", totalDepositVnd: 100, totalWithdrawalVnd: 200, differenceVnd: -100 },
      { memberId: 3, username: "c", totalDepositVnd: 0, totalWithdrawalVnd: 0, differenceVnd: 0 },
    ]);
    expect(queries[1].grouped).toBe(true);
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8]);
    const join = sqlQuery(queries[1].joins[0]);
    expect(join.sql).toContain("`occurred_at` >= ?");
    expect(join.sql).toContain("`occurred_at` < ?");
    expect(join.params.map((date: any) => new Date(date).toISOString())).toEqual([
      "2026-09-30T17:00:00.000Z", "2026-10-31T17:00:00.000Z",
    ]);
    expect(sqlQuery(queries[1].fields.totalDepositVnd as SQL).sql).toContain("'deposit'");
    expect(sqlQuery(queries[1].fields.totalWithdrawalVnd as SQL).sql).toContain("'withdrawal'");
  });

  it("adds exact optional username filtering without dropping agency isolation", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }], []]);
    await reportsRouter.createCaller(context()).agentMonthly({ kind: "transactions", month: "2026-10", username: "member01" });
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8, "member01"]);
  });

  it("returns independent promotion data alongside legacy bet metrics for the selected member/month", async () => {
    const row = { memberId: 1, username: "member01", amountVnd: 1000, validBetVnd: 800, promotionVnd: 25, netWinLossVnd: 999999, updatedAt: new Date() };
    const { queries } = fakeDb([[{ id: 8, status: "approved" }], [row], [{ memberId: 1, total: "100" }],
      [{ memberId: 1, total: "75" }], [{ memberId: 1, total: "1000", promotionTotal: "25", refundTotal: "0" }], []]);
    const result = await reportsRouter.createCaller(context()).agentMonthly({ kind: "bets", month: "2026-10", username: "member01" });
    expect(result.rows).toEqual([{ ...row, netWinLossVnd: -50 }]);
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([8, "2026-10", "member01"]);
  });
});

describe("admin member data", () => {
  it("creates a username-only member without inventing a name or phone", async () => {
    const { inserts, queries } = fakeDb([[{ id: 8, status: "approved" }]]);
    const result = await adminRouter.createCaller(context("admin")).createMember({ agencyId: 8, username: "member_only" });
    expect(result).toEqual({ success: true, id: 999 });
    expect(inserts[0]).toMatchObject({ agencyId: 8, username: "member_only", fullName: "", phone: null, createdBy: 42 });
    expect((inserts[0] as any).joinedAt).toBeInstanceOf(Date);
    expect(sqlQuery(queries[0].filters[0]).params).toEqual([8]);
    expect(queries[0].locked).toBe(true);
    expect(inserts[1]).toMatchObject({ action: "member.created", actorUserId: 42, entityId: 999 });
  });

  it("keeps optional legacy contact information and selected join date when supplied", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }]]);
    const joinedAt = new Date("2026-10-15T17:00:00Z");
    await adminRouter.createCaller(context("admin")).createMember({ agencyId: 8, username: "member_old", fullName: "Existing Name", phone: "0000", joinedAt });
    expect(inserts[0]).toMatchObject({ fullName: "Existing Name", phone: "0000", joinedAt });
  });

  it("still blocks non-admin creation and invalid usernames before writing", async () => {
    await expect(adminRouter.createCaller(context()).createMember({ agencyId: 8, username: "member_only" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(adminRouter.createCaller(context("admin")).createMember({ agencyId: 8, username: "bad username!" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it.each(["pending", "locked", "rejected"])("refuses adding members to a %s agency", async (status) => {
    const { inserts } = fakeDb([[{ id: 8, status }]]);
    await expect(adminRouter.createCaller(context("admin")).createMember({ agencyId: 8, username: "member_only" })).rejects.toMatchObject({ code: "PRECONDITION_FAILED" });
    expect(inserts).toHaveLength(0);
  });

  it("updates only username without clearing existing member identity/contact data", async () => {
    const member = { id: 4, username: "member_old", fullName: "Existing Name", phone: "0000" };
    const { updates, inserts } = fakeDb([[member]]);
    await adminRouter.createCaller(context("admin")).updateMember({ memberId: 4, username: "member_updated" });
    expect(updates[0]).toEqual({ username: "member_updated", fullName: "Existing Name", phone: "0000" });
    expect(JSON.parse((inserts[0] as any).details).after).toEqual(updates[0]);
  });

  it("returns lifetime totals using independent grouped queries without transaction/bet join multiplication", async () => {
    const { queries } = fakeDb([
      [{ id: 1, agencyId: 8, username: "member01" }, { id: 2, agencyId: 8, username: "member02" }, { id: 3, agencyId: 8, username: "member03" }],
      [{ memberId: 1, total: "2500000" }, { memberId: 2, total: "1234" }],
      [{ memberId: 1, total: "500000" }],
      [{ memberId: 1, total: "8000000", promotionTotal: "25000" }, { memberId: 2, total: "0", promotionTotal: null }],
    ]);
    const rows = await adminRouter.createCaller(context("admin")).members({ agencyId: 8 });
    expect(rows[0]).toMatchObject({ totalDepositVnd: 2500000, totalWithdrawalVnd: 500000, totalBetsVnd: 8000000, totalPromotionVnd: 25000 });
    expect(rows[1]).toMatchObject({ totalDepositVnd: 1234, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0 });
    expect(rows[2]).toMatchObject({ totalDepositVnd: 0, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0 });
    expect(sqlQuery(queries[0].filters[0]).params).toEqual([8]);
    expect(sqlQuery(queries[1].filters[0]).params).toEqual([1, 2, 3, "deposit"]);
    expect(sqlQuery(queries[2].filters[0]).params).toEqual([1, 2, 3, "withdrawal"]);
    expect(sqlQuery(queries[3].filters[0]).params).toEqual([1, 2, 3]);
    expect(sqlQuery(queries[3].fields.promotionTotal as SQL).sql).toContain("promotion_vnd");
    for (const query of queries.slice(1)) {
      expect(query.grouped).toBe(true); expect(query.joins).toHaveLength(0);
      expect(sqlQuery(query.filters[0]).sql).not.toMatch(/month_key|occurred_at/);
    }
  });

  it("does not query unrelated totals for an empty filtered member list", async () => {
    const { queries } = fakeDb([[]]);
    expect(await adminRouter.createCaller(context("admin")).members({ agencyId: 8 })).toEqual([]);
    expect(queries).toHaveLength(1);
  });

  it("rejects an unsafe cumulative member total rather than rounding it", async () => {
    fakeDb([[{ id: 1 }], [{ memberId: 1, total: "9007199254740993" }], [], []]);
    await expect(adminRouter.createCaller(context("admin")).members()).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("rejects an unsafe cumulative promotion rather than returning rounded points", async () => {
    fakeDb([[{ id: 1 }], [], [], [{ memberId: 1, total: "0", promotionTotal: "9007199254740993" }]]);
    await expect(adminRouter.createCaller(context("admin")).members({ agencyId: 8 })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("keeps promotion totals isolated by member even when bet totals are equal", async () => {
    fakeDb([
      [{ id: 1 }, { id: 2 }], [], [],
      [{ memberId: 1, total: "100000", promotionTotal: "1234" }, { memberId: 2, total: "100000", promotionTotal: "5678" }],
    ]);
    const rows = await adminRouter.createCaller(context("admin")).members();
    expect(rows.map((row) => ({ id: row.id, promotion: row.totalPromotionVnd }))).toEqual([
      { id: 1, promotion: 1234 }, { id: 2, promotion: 5678 },
    ]);
  });

  it("does not allow agencies to read the Admin promotion list", async () => {
    await expect(adminRouter.createCaller(context()).members()).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("blocks agencies from writing validity and monthly bet data", async () => {
    const caller = adminRouter.createCaller(context());
    await expect(caller.setMemberValidity({ memberId: 1, isValid: true })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 1, validBetVnd: 1, netWinLossVnd: 0 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("persists manual validity and creates an audit entry", async () => {
    const { updates, inserts } = fakeDb([[{ id: 1, agencyId: 8, username: "member01", isValid: 0 }]]);
    await adminRouter.createCaller(context("admin")).setMemberValidity({ memberId: 1, isValid: true });
    expect(updates).toEqual([{ isValid: 1 }]);
    expect(inserts[0]).toMatchObject({ actorUserId: 42, action: "member.validity_updated", entityId: 1 });
    expect(JSON.parse((inserts[0] as any).details)).toMatchObject({ previous: false, isValid: true, agencyId: 8 });
  });

  it("rejects invalid supplied bet metrics without writing to the database", async () => {
    const caller = adminRouter.createCaller(context("admin"));
    await expect(caller.upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 100, validBetVnd: -1, netWinLossVnd: 0 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 100, validBetVnd: 101, netWinLossVnd: 0 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 100, netWinLossVnd: null } as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("accepts a legacy total-only request and creates missing metrics as zero", async () => {
    const { inserts } = fakeDb([[{ id: 1, agencyId: 8, username: "member01" }], []]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 100 });
    expect(inserts[0]).toMatchObject({ amountVnd: 100, validBetVnd: 0, netWinLossVnd: 0 });
    expect(JSON.parse((inserts[1] as any).details).updated).toEqual({ amountVnd: 100, validBetVnd: 0, promotionVnd: 0, refundVnd: 0, netWinLossVnd: 0 });
  });

  it("preserves existing optional metrics when only total bet is updated", async () => {
    const { updates, inserts } = fakeDb([[{ id: 1, agencyId: 8, username: "member01" }], [{ id: 9, amountVnd: 100, validBetVnd: 90, netWinLossVnd: -5 }]]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 200 });
    expect(updates[0]).toEqual({ amountVnd: 200, validBetVnd: 90, promotionVnd: 0, refundVnd: 0, updatedBy: 42 });
    expect(updates[1]).toMatchObject({ netWinLossVnd: 0, updatedBy: 42 });
    expect(JSON.parse((inserts[0] as any).details).updated).toEqual({ amountVnd: 200, validBetVnd: 90, promotionVnd: 0, refundVnd: 0, netWinLossVnd: 0 });
  });

  it("updates a supplied metric and preserves the omitted metric", async () => {
    const { updates } = fakeDb([[{ id: 1, agencyId: 8, username: "member01" }], [{ id: 9, amountVnd: 100, validBetVnd: 90, netWinLossVnd: -5 }]]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 200, netWinLossVnd: 50 });
    expect(updates[0]).toEqual({ amountVnd: 200, validBetVnd: 90, promotionVnd: 0, refundVnd: 0, updatedBy: 42 });
  });

  it("allows explicit zeros to replace prior nonzero metrics", async () => {
    const { updates } = fakeDb([[{ id: 1, agencyId: 8, username: "member01" }], [{ id: 9, amountVnd: 100, validBetVnd: 90, netWinLossVnd: -5 }]]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 0, validBetVnd: 0, netWinLossVnd: 0 });
    expect(updates[0]).toEqual({ amountVnd: 0, validBetVnd: 0, promotionVnd: 0, refundVnd: 0, updatedBy: 42 });
  });

  it("rejects a total below the preserved valid bet without writes", async () => {
    const { updates, inserts } = fakeDb([[{ id: 1, agencyId: 8, username: "member01" }], [{ id: 9, amountVnd: 100, validBetVnd: 90, netWinLossVnd: -5 }]]);
    await expect(adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 80 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(updates).toHaveLength(0);
    expect(inserts).toHaveLength(0);
  });

  it("stores signed win/loss and all metrics together and audits previous values", async () => {
    const { updates, inserts, queries } = fakeDb([
      [{ id: 1, agencyId: 8, username: "member01" }],
      [{ id: 9, amountVnd: 100, validBetVnd: 90, netWinLossVnd: 5 }],
    ]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 200, validBetVnd: 180, netWinLossVnd: -20 });
    expect(updates[0]).toEqual({ amountVnd: 200, validBetVnd: 180, promotionVnd: 0, refundVnd: 0, updatedBy: 42 });
    const details = JSON.parse((inserts[0] as any).details);
    expect(details.previous).toEqual({ amountVnd: 100, validBetVnd: 90, promotionVnd: 0, refundVnd: 0, netWinLossVnd: 5 });
    expect(details.updated).toEqual({ amountVnd: 200, validBetVnd: 180, promotionVnd: 0, refundVnd: 0, netWinLossVnd: 0 });
    expect(queries[0].locked).toBe(true);
    expect(inserts[0]).toMatchObject({ entityId: 9 });
  });

  it("records the new monthly bet ID in the audit and serializes first writes", async () => {
    const { inserts, queries } = fakeDb([[{ id: 1, agencyId: 8, username: "member01" }], []]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 100, validBetVnd: 80, netWinLossVnd: 10 });
    expect(queries[0].locked).toBe(true);
    expect(inserts[0]).toMatchObject({ memberId: 1, monthKey: "2026-10", amountVnd: 100, validBetVnd: 80, netWinLossVnd: 0 });
    expect(inserts[1]).toMatchObject({ action: "member.monthly_bet_updated", entityId: 999 });
  });
});

describe("monthly member promotions", () => {
  it("stores promotion separately without replacing valid bets or net win/loss", async () => {
    const { updates, inserts, queries } = fakeDb([
      [{ id: 1, agencyId: 8, username: "member01" }],
      [{ id: 9, amountVnd: 500000, validBetVnd: 400000, promotionVnd: 10000, refundVnd: 9000, netWinLossVnd: 300000 }],
      [], [], [{ memberId: 1, total: "500000", promotionTotal: "25000", refundTotal: "30000" }], [],
    ]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000, promotionVnd: 25000, refundVnd: 30000 });
    expect(updates[0]).toEqual({ amountVnd: 500000, validBetVnd: 400000, promotionVnd: 25000, refundVnd: 30000, updatedBy: 42 });
    const details = JSON.parse((inserts[0] as any).details);
    expect(details.previous.promotionVnd).toBe(10000);
    expect(details.previous.refundVnd).toBe(9000);
    expect(details.updated.promotionVnd).toBe(25000);
    expect(details.updated.refundVnd).toBe(30000);
    expect(queries[0].locked).toBe(true);
    expect(updates).toHaveLength(2); expect(updates[1]).toMatchObject({ netWinLossVnd: -55000, updatedBy: 42 }); expect(inserts).toHaveLength(1);
  });

  it("preserves an existing promotion when an older client omits the new field", async () => {
    const { updates } = fakeDb([[{ id: 1 }], [{ id: 9, validBetVnd: 0, promotionVnd: 25000, netWinLossVnd: -1000 }], [], [], [{ memberId: 1, total: "0", promotionTotal: "25000", refundTotal: "0" }], []]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000 });
    expect(updates[0]).toMatchObject({ promotionVnd: 25000 });
    expect(updates[1]).toMatchObject({ netWinLossVnd: -25000 });
  });

  it("preserves existing refund when omitted and allows an explicit zero", async () => {
    const { updates } = fakeDb([[{ id: 1 }], [{ id: 9, validBetVnd: 0, promotionVnd: 25000, refundVnd: 14000, netWinLossVnd: -1000 }]]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000 });
    expect(updates[0]).toMatchObject({ promotionVnd: 25000, refundVnd: 14000 });
    const { updates: resetUpdates } = fakeDb([[{ id: 1 }], [{ id: 9, validBetVnd: 0, promotionVnd: 25000, refundVnd: 14000, netWinLossVnd: -1000 }]]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000, refundVnd: 0 });
    expect(resetUpdates[0]).toMatchObject({ promotionVnd: 25000, refundVnd: 0 });
  });

  it.each([-1, 0.5, Number.MAX_SAFE_INTEGER + 1, null])("rejects invalid refund %s before accessing DB", async (refundVnd) => {
    await expect(adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000, refundVnd } as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("allows explicit zero to reset a promotion while preserving legacy metrics", async () => {
    const { updates } = fakeDb([[{ id: 1 }], [{ id: 9, validBetVnd: 1000, promotionVnd: 25000, netWinLossVnd: -1000 }]]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000, promotionVnd: 0 });
    expect(updates[0]).toMatchObject({ validBetVnd: 1000, promotionVnd: 0, refundVnd: 0 });
  });

  it.each([-1, 0.5, Number.MAX_SAFE_INTEGER + 1, null])("refuses invalid promotion %s before accessing DB", async (promotionVnd) => {
    await expect(adminRouter.createCaller(context("admin")).upsertMonthlyBet({ memberId: 1, month: "2026-10", amountVnd: 500000, promotionVnd } as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("does not reinterpret valid bet data as a promotion when none is recorded", async () => {
    fakeDb([[{ id: 8, status: "approved" }], [{ memberId: 1, username: "member01", amountVnd: 500000, validBetVnd: 450000, promotionVnd: 0, refundVnd: 0, netWinLossVnd: 300000 }]]);
    const result = await reportsRouter.createCaller(context()).agentMonthly({ kind: "bets", month: "2026-10" });
    expect(result.rows[0]).toMatchObject({ validBetVnd: 450000, promotionVnd: 0 });
  });

  it("refuses unsafe stored promotion totals in the agency report", async () => {
    fakeDb([[{ id: 8, status: "approved" }], [{ memberId: 1, amountVnd: 500000, validBetVnd: 0, promotionVnd: Number.MAX_SAFE_INTEGER + 1, netWinLossVnd: 300000 }]]);
    await expect(reportsRouter.createCaller(context()).agentMonthly({ kind: "bets", month: "2026-10" })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });
});

describe("agency overview cards", () => {
  it("returns current-month valid bets and signed win/loss separately for each agency in Admin", async () => {
    const { queries } = fakeDb([
      [{ id: 8, username: "agency01" }, { id: 9, username: "agency02" }, { id: 10, username: "agency03" }],
      [], [], [], [], [],
      [{ agencyId: 8, total: "1000", validBetTotal: "800", promotionTotal: "0", refundTotal: "0" }, { agencyId: 9, total: "2000", validBetTotal: "1500", promotionTotal: "0", refundTotal: "0" }],
    ]);
    const rows = await adminRouter.createCaller(context("admin")).agencies(undefined);
    expect(rows[0]).toMatchObject({ monthBetsVnd: 1000, monthPromotionVnd: 0, monthValidBetsVnd: 800, monthWinLossVnd: 0 });
    expect(rows[1]).toMatchObject({ monthBetsVnd: 2000, monthPromotionVnd: 0, monthValidBetsVnd: 1500, monthWinLossVnd: 0 });
    expect(rows[2]).toMatchObject({ monthBetsVnd: 0, monthValidBetsVnd: 0, monthWinLossVnd: 0 });
    expect(sqlQuery(queries[6].filters[0]).params).toEqual([rows[0].activityMonth]);
    expect(queries[6].grouped).toBe(true);
    expect(Object.keys(queries[6].fields).sort()).toEqual(["agencyId", "promotionTotal", "refundTotal", "total", "validBetTotal"]);
  });

  it("keeps member personal details out of agency responses and search", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }], []]);
    await agentRouter.createCaller(context()).members({ search: "member01", joinedDay: "2026-10-14" });
    expect(Object.keys(queries[1].fields).sort()).toEqual(["id", "isValid", "joinedAt", "username"]);
    const filter = sqlQuery(queries[1].filters[0]);
    expect(filter.params.slice(0, 2)).toEqual([8, "%member01%"]);
    expect(filter.sql).not.toContain("full_name");
    expect(filter.sql).not.toContain("phone");
  });

  it("uses only this agency's marked members and current Vietnam month win/loss", async () => {
    const { queries } = fakeDb([
      [{ id: 8, status: "approved", username: "agency01" }], [{ total: "100" }], [{ total: "20" }],
      [{ total: 3 }], [{ total: 1 }], [{ id: 1 }], [{ memberId: 1, total: "100" }], [{ memberId: 1, total: "20" }],
      [{ memberId: 1, total: "0", promotionTotal: "120", refundTotal: "0" }], [], [{ total: 2 }],
    ]);
    const result = await agentRouter.createCaller(context()).overview();
    expect(result.availableVnd).toBe(80);
    expect(result.totalWinLossVnd).toBe(-200);
    expect(result.validMemberCount).toBe(2);
    expect(sqlQuery(queries[8].filters[0]).params).toEqual([1, result.activityMonth]);
    expect(sqlQuery(queries[10].filters[0]).params).toEqual([8, 1]);
  });
});

describe("bank and USDT withdrawal destinations", () => {
  it("rejects a bank withdrawal below 200 points before reading balance or writing", async () => {
    const { queries, inserts } = fakeDb([
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 1, bankName: "QA Bank", accountNumber: "01234567", ownerName: "QA recipient", branch: "QA branch" }],
    ]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ bankAccountId: 1, amountVnd: MIN_BANK_WITHDRAWAL_VND - 1 }))
      .rejects.toMatchObject({ code: "BAD_REQUEST", message: withdrawalMinimumMessage("bank") });
    expect(queries).toHaveLength(3);
    expect(inserts).toHaveLength(0);
  });

  it("rejects a USDT withdrawal below 1,000 points before reading balance or writing", async () => {
    const { queries, inserts } = fakeDb([
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 12, agencyId: 8, asset: "USDT", network: "TRC20", address: "dia-chi-vi-cua-toi" }],
    ]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ walletAccountId: 12, amountVnd: MIN_USDT_WITHDRAWAL_VND - 1 }))
      .rejects.toMatchObject({ code: "BAD_REQUEST", message: withdrawalMinimumMessage("usdt") });
    expect(queries).toHaveLength(3);
    expect(inserts).toHaveLength(0);
  });

  it("accepts the exact bank minimum when the available balance is sufficient", async () => {
    const { inserts } = fakeDb([
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 1, bankName: "QA Bank", accountNumber: "01234567", ownerName: "QA recipient", branch: "QA branch" }],
      [{ total: String(MIN_BANK_WITHDRAWAL_VND) }], [{ total: "0" }],
    ]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ bankAccountId: 1, amountVnd: MIN_BANK_WITHDRAWAL_VND }))
      .resolves.toEqual({ id: 999, status: "pending" });
    expect(inserts[0]).toMatchObject({ amountVnd: MIN_BANK_WITHDRAWAL_VND, destinationType: "bank" });
  });

  it("accepts the exact USDT minimum when the available balance is sufficient", async () => {
    const { inserts } = fakeDb([
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 12, agencyId: 8, asset: "USDT", network: "TRC20", address: "dia-chi-vi-cua-toi" }],
      [{ total: String(MIN_USDT_WITHDRAWAL_VND) }], [{ total: "0" }],
    ]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ walletAccountId: 12, amountVnd: MIN_USDT_WITHDRAWAL_VND }))
      .resolves.toEqual({ id: 999, status: "pending" });
    expect(inserts[0]).toMatchObject({ amountVnd: MIN_USDT_WITHDRAWAL_VND, destinationType: "usdt" });
  });

  it.each([{}, { bankAccountId: 1, walletAccountId: 2 }])("requires exactly one destination before DB access", async (choice) => {
    await expect(agentRouter.createCaller(context()).createWithdrawal({ ...choice, amountVnd: MIN_BANK_WITHDRAWAL_VND })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it.each(["TRC20", "ERC20"] as const)("stores a %s wallet snapshot and reserves the exact VND equivalent", async (network) => {
    const { queries, inserts } = fakeDb([
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 12, agencyId: 8, asset: "USDT", network, address: "dia-chi-vi-cua-toi" }],
      [{ total: "2500000" }], [{ total: "1000000" }],
    ]);
    expect(await agentRouter.createCaller(context()).createWithdrawal({ walletAccountId: 12, amountVnd: MIN_USDT_WITHDRAWAL_VND })).toEqual({ id: 999, status: "pending" });
    expect(queries[1].locked).toBe(true);
    expect(sqlQuery(queries[2].filters[0]).params).toEqual([12, 8]);
    expect(inserts[0]).toMatchObject({ agencyId: 8, destinationType: "usdt", bankAccountId: null, walletAccountId: 12, walletNetwork: network, walletAddress: "dia-chi-vi-cua-toi", ownerName: "QA agency", amountVnd: MIN_USDT_WITHDRAWAL_VND, status: "pending" });
    expect(JSON.parse((inserts[1] as any).details)).toEqual({ agencyId: 8, amountVnd: MIN_USDT_WITHDRAWAL_VND, destinationType: "usdt", bankAccountId: null, walletAccountId: 12 });
    expect(JSON.stringify(inserts[1])).not.toContain("dia-chi-vi-cua-toi");
  });

  it("preserves the selected bank recipient instead of taking the agency name", async () => {
    const { inserts } = fakeDb([
      [{ id: 8, status: "approved", fullName: "QA agency" }], [{ id: 8, status: "approved", fullName: "QA agency" }],
      [{ id: 1, bankName: "QA Bank", ownerName: "QA recipient", accountNumber: "01234567", branch: "QA branch" }],
      [{ total: "1000000" }], [{ total: "0" }],
    ]);
    await agentRouter.createCaller(context()).createWithdrawal({ bankAccountId: 1, amountVnd: 1000000 });
    expect(inserts[0]).toMatchObject({ destinationType: "bank", ownerName: "QA recipient", accountNumber: "01234567", bankName: "QA Bank", branch: "QA branch", walletAccountId: null, walletAddress: null });
  });

  it("cannot withdraw to another agency's wallet and does not insert anything", async () => {
    const { queries, inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], []]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ walletAccountId: 99, amountVnd: MIN_USDT_WITHDRAWAL_VND })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(sqlQuery(queries[2].filters[0]).params).toEqual([99, 8]);
    expect(inserts).toHaveLength(0);
  });

  it("checks the current profile lock status before creating a USDT request", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "locked" }]]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ walletAccountId: 12, amountVnd: MIN_USDT_WITHDRAWAL_VND })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(inserts).toHaveLength(0);
  });

  it("does not overspend the same balance when the destination is a wallet", async () => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [{ id: 8, status: "approved" }], [{ id: 12, network: "TRC20", address: "qa" }], [{ total: "1000000" }], [{ total: "900000" }]]);
    await expect(agentRouter.createCaller(context()).createWithdrawal({ walletAccountId: 12, amountVnd: MIN_USDT_WITHDRAWAL_VND + 1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(inserts).toHaveLength(0);
  });

  it("returns recipient and USDT destination snapshots directly from the request, without wallet/bank joins", async () => {
    const row = { id: 1, amountVnd: 1000000, destinationType: "usdt", walletNetwork: "ERC20", walletAddress: "saved-wallet-address", ownerName: "Saved recipient" };
    const { queries } = fakeDb([[row]]);
    expect(await adminRouter.createCaller(context("admin")).withdrawals()).toEqual([row]);
    expect(queries[0].joins).toHaveLength(1);
    expect(sqlQuery(queries[0].joins[0]).sql).toContain("agency_profiles");
    expect(Object.keys(queries[0].fields)).toEqual(expect.arrayContaining(["ownerName", "accountNumber", "walletAddress", "walletNetwork", "amountVnd", "destinationType"]));
    await expect(adminRouter.createCaller(context()).withdrawals()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("Admin monthly member totals and corrections", () => {
  it("filters money by month while retaining older members, then applies exact correction deltas", async () => {
    const { queries } = fakeDb([
      [{ id: 1, joinedAt: new Date("2026-01-01") }],
      [{ memberId: 1, total: "1000000" }], [{ memberId: 1, total: "200000" }],
      [{ memberId: 1, total: "500000", promotionTotal: "5000" }],
      [{ memberId: 1, depositDeltaVnd: "-100000", withdrawalDeltaVnd: "25000" }],
    ]);
    const rows = await adminRouter.createCaller(context("admin")).members({ agencyId: 8, month: "2026-10" });
    expect(rows[0]).toMatchObject({ totalDepositVnd: 900000, totalWithdrawalVnd: 225000, totalBetsVnd: 500000, totalPromotionVnd: 5000, totalRefundVnd: 0, netWinLossVnd: -680000 });
    expect(sqlQuery(queries[0].filters[0]).params).toEqual([8]);
    expect(sqlQuery(queries[0].filters[0]).sql).not.toContain("joined_at");
    const deposit = sqlQuery(queries[1].filters[0]);
    expect(deposit.sql).toContain("`occurred_at` >= ?");
    expect(deposit.sql).toContain("`occurred_at` < ?");
    expect(deposit.params.slice(2).map((v: any) => new Date(v).toISOString())).toEqual(["2026-09-30T17:00:00.000Z", "2026-10-31T17:00:00.000Z"]);
    expect(sqlQuery(queries[3].filters[0]).params).toEqual([1, "2026-10"]);
    expect(sqlQuery(queries[4].filters[0]).params).toEqual([1, "2026-10"]);
  });

  it("only restricts join dates when the joined-in-month option is selected, across a year boundary", async () => {
    const { queries } = fakeDb([[]]);
    await adminRouter.createCaller(context("admin")).members({ agencyId: 8, month: "2026-12", joinedInMonth: true });
    const query = sqlQuery(queries[0].filters[0]);
    expect(query.params[0]).toBe(8);
    expect(query.params.slice(1).map((v: any) => new Date(v).toISOString())).toEqual(["2026-11-30T17:00:00.000Z", "2026-12-31T17:00:00.000Z"]);
    expect(query.sql).toContain("`joined_at` >= ?");
    expect(query.sql).toContain("`joined_at` < ?");
    expect(queries).toHaveLength(1);
  });

  it("rejects invalid or missing required filter months before reading DB", async () => {
    const caller = adminRouter.createCaller(context("admin"));
    for (const input of [{ month: "" }, { month: "2026-13" }, { month: "9999-12" }, { joinedInMonth: true }]) {
      await expect(caller.members(input)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    }
    expect(mock.getDb).not.toHaveBeenCalled();
  });

  it("corrects all four totals atomically without updating original transactions or legacy metrics", async () => {
    const { queries, updates, inserts } = fakeDb([
      [{ id: 1, agencyId: 8, username: "monthly01" }],
      [{ memberId: 1, total: "1000000" }], [{ memberId: 1, total: "200000" }],
      [{ memberId: 1, total: "500000", promotionTotal: "5000" }], [],
      [{ id: 9, validBetVnd: 400000, netWinLossVnd: -1000 }],
      [{ memberId: 1, total: "1000000" }], [{ memberId: 1, total: "200000" }],
      [{ memberId: 1, total: "600000", promotionTotal: "7000", refundTotal: "0" }],
      [{ memberId: 1, depositDeltaVnd: "-100000", withdrawalDeltaVnd: "25000" }],
    ]);
    const result = await adminRouter.createCaller(context("admin")).saveMemberMonth({
      memberId: 1, month: "2026-10", totalDepositVnd: 900000, totalWithdrawalVnd: 225000,
      totalBetsVnd: 600000, totalPromotionVnd: 7000, reason: "Correct monthly figures",
      expected: { totalDepositVnd: 1000000, totalWithdrawalVnd: 200000, totalBetsVnd: 500000, totalPromotionVnd: 5000 },
    });
    expect(result).toEqual({ success: true, month: "2026-10", memberId: 1, changed: true });
    expect(queries[0].locked).toBe(true); expect(queries[5].locked).toBe(true);
    expect(inserts[0]).toMatchObject({ memberId: 1, monthKey: "2026-10", depositDeltaVnd: -100000, withdrawalDeltaVnd: 25000, createdBy: 42 });
    expect(updates).toEqual([{ amountVnd: 600000, promotionVnd: 7000, updatedBy: 42 }, { netWinLossVnd: -682000, updatedBy: 42 }]);
    expect(inserts[1]).toMatchObject({ action: "member.monthly_report_corrected", entityId: 9, actorUserId: 42 });
    const detail = JSON.parse((inserts[1] as any).details);
    expect(detail.before.totalDepositVnd).toBe(1000000); expect(detail.after.totalDepositVnd).toBe(900000);
    expect(detail.netWinLossVnd).toBe(-682000);
    expect(detail.reason).toBe("Correct monthly figures");
  });

  it("refuses stale data and does not create a correction or audit", async () => {
    const { updates, inserts } = fakeDb([[{ id: 1 }], [], [], [], []]);
    await expect(adminRouter.createCaller(context("admin")).saveMemberMonth({ memberId: 1, month: "2026-10",
      totalDepositVnd: 100, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0, reason: "Correction",
      expected: { totalDepositVnd: 99, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0 },
    })).rejects.toMatchObject({ code: "CONFLICT" });
    expect(updates).toHaveLength(0); expect(inserts).toHaveLength(0);
  });

  it("creates a previously empty month without rewriting transaction history", async () => {
    const { inserts } = fakeDb([[{ id: 1, agencyId: 8 }], [], [], [], [], []]);
    await adminRouter.createCaller(context("admin")).saveMemberMonth({ memberId: 1, month: "2026-10",
      totalDepositVnd: 0, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0, reason: "Confirmed zero month" });
    expect(inserts[0]).toMatchObject({ memberId: 1, monthKey: "2026-10", amountVnd: 0, promotionVnd: 0, validBetVnd: 0, netWinLossVnd: 0 });
    expect(inserts[1]).toMatchObject({ action: "member.monthly_report_corrected", entityId: 999 });
  });

  it("does not audit or adjust again when the same saved totals are resubmitted", async () => {
    const { updates, inserts } = fakeDb([[{ id: 1 }], [], [], [{ memberId: 1, total: "0", promotionTotal: "0" }], [], [{ id: 9, validBetVnd: 0 }]]);
    expect(await adminRouter.createCaller(context("admin")).saveMemberMonth({ memberId: 1, month: "2026-10",
      totalDepositVnd: 0, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0, reason: "Confirmed values" })).toMatchObject({ changed: false });
    expect(updates).toHaveLength(0); expect(inserts).toHaveLength(0);
  });

  it("includes corrections in the agency monthly report without cross-member joins", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }],
      [{ memberId: 1, username: "monthly01", totalDepositVnd: "1000000", totalWithdrawalVnd: "200000" }],
      [{ memberId: 1, depositDeltaVnd: "-100000", withdrawalDeltaVnd: "25000" }],
    ]);
    const result = await reportsRouter.createCaller(context()).agentMonthly({ kind: "transactions", month: "2026-10", username: "monthly01" });
    expect(result.rows[0]).toMatchObject({ totalDepositVnd: 900000, totalWithdrawalVnd: 225000, differenceVnd: 675000 });
    expect(sqlQuery(queries[2].filters[0]).params).toEqual([1, "2026-10"]);
    expect(queries[2].joins).toHaveLength(0);
  });

  it("blocks non-admin correction and validates nonnegative safe values/reason", async () => {
    const input = { memberId: 1, month: "2026-10", totalDepositVnd: 0, totalWithdrawalVnd: 0, totalBetsVnd: 0, totalPromotionVnd: 0, reason: "Correction" };
    await expect(adminRouter.createCaller(context()).saveMemberMonth(input)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(adminRouter.createCaller(context("admin")).saveMemberMonth({ ...input, totalDepositVnd: -1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(adminRouter.createCaller(context("admin")).saveMemberMonth({ ...input, totalPromotionVnd: Number.MAX_SAFE_INTEGER + 1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(adminRouter.createCaller(context("admin")).saveMemberMonth({ ...input, reason: "" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
});

describe("combined member deposit and withdrawal", () => {
  it("writes both amounts and their audits under one member lock and transaction", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-10-31T16:59:00.000Z"));
    try {
    const { db, queries, inserts } = fakeDb([
      [{ id: 1, agencyId: 8, username: "monthly01" }],
      [{ memberId: 1, total: "1000000" }], [{ memberId: 1, total: "200000" }], [], [], [],
    ]);
    const result = await adminRouter.createCaller(context("admin")).addMemberTransactions({ memberId: 1, depositVnd: 1000000, withdrawalVnd: 200000 });
    expect(db.transaction).toHaveBeenCalledTimes(1); expect(queries[0].locked).toBe(true);
    expect(result.ids).toHaveLength(2);
    expect(inserts[0]).toMatchObject({ memberId: 1, kind: "deposit", amountVnd: 1000000 });
    expect(inserts[2]).toMatchObject({ memberId: 1, kind: "withdrawal", amountVnd: 200000 });
    expect((inserts[0] as any).occurredAt.toISOString()).toBe("2026-10-31T16:59:00.000Z");
    expect(inserts[1]).toMatchObject({ action: "member_transaction.deposit_recorded" });
    expect(inserts[3]).toMatchObject({ action: "member_transaction.withdrawal_recorded" });
    expect(inserts[4]).toMatchObject({ memberId: 1, monthKey: "2026-10", netWinLossVnd: -800000 });
    } finally {
      vi.useRealTimers();
    }
  });

  it("skips a blank/zero side rather than creating a zero transaction", async () => {
    const { inserts } = fakeDb([[{ id: 1 }], [], [{ memberId: 1, total: "500000" }], [], [], []]);
    const month = vietnamMonthKey(new Date());
    await adminRouter.createCaller(context("admin")).addMemberTransactions({ memberId: 1, depositVnd: 0, withdrawalVnd: 500000 });
    expect(inserts).toHaveLength(3); expect(inserts[0]).toMatchObject({ kind: "withdrawal", amountVnd: 500000 });
    expect(inserts[2]).toMatchObject({ memberId: 1, monthKey: month, netWinLossVnd: 500000 });
  });

  it("uses server current time when the Admin UI omits transaction datetime", async () => {
    const before = Date.now();
    const { inserts } = fakeDb([[{ id: 1, agencyId: 8, username: "monthly01" }]]);
    await adminRouter.createCaller(context("admin")).addMemberTransactions({ memberId: 1, depositVnd: 1000 });
    const after = Date.now();
    expect((inserts[0] as any).occurredAt).toBeInstanceOf(Date);
    expect((inserts[0] as any).occurredAt.getTime()).toBeGreaterThanOrEqual(before);
    expect((inserts[0] as any).occurredAt.getTime()).toBeLessThanOrEqual(after);
    expect(JSON.parse((inserts[1] as any).details).occurredAt).toBe((inserts[0] as any).occurredAt.toISOString());
  });

  it("blocks invalid/empty amounts, client-supplied timestamps and non-admins before DB", async () => {
    const input = { memberId: 1, depositVnd: 1 };
    await expect(adminRouter.createCaller(context()).addMemberTransactions(input)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(adminRouter.createCaller(context("admin")).addMemberTransactions({ ...input, depositVnd: 0 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(adminRouter.createCaller(context("admin")).addMemberTransactions({ ...input, depositVnd: -1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(adminRouter.createCaller(context("admin")).addMemberTransactions({ ...input, occurredAt: "2026-10-31T23:59" } as any)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
});

describe("authoritative monthly win-loss formula", () => {
  it.each([
    [{ totalDepositVnd: 1_000_000, totalPromotionVnd: 25_000, totalRefundVnd: 5_000, totalWithdrawalVnd: 300_000 }, -730_000],
    [{ totalDepositVnd: 100, totalPromotionVnd: 0, totalRefundVnd: 0, totalWithdrawalVnd: 250 }, 150],
    [{ totalDepositVnd: 300_000, totalPromotionVnd: 20_000, totalRefundVnd: 0, totalWithdrawalVnd: 200_000 }, -120_000],
    [{ totalDepositVnd: 300, totalPromotionVnd: 20, totalRefundVnd: 5, totalWithdrawalVnd: 325 }, 0],
  ] as const)("calculates exact positive, negative, and zero totals", (input, expected) => {
    expect(calculateMonthlyWinLossVnd(input)).toBe(expected);
  });

  it("ignores a forged legacy netWinLossVnd during upsert", async () => {
    const { updates, inserts } = fakeDb([
      [{ id: 1, agencyId: 8, username: "formula01" }],
      [{ id: 9, amountVnd: 100, validBetVnd: 0, promotionVnd: 0, refundVnd: 0, netWinLossVnd: 999999 }],
      [{ memberId: 1, total: "1000000" }], [{ memberId: 1, total: "300000" }],
      [{ memberId: 1, total: "500", promotionTotal: "25000", refundTotal: "5000" }], [],
    ]);
    await adminRouter.createCaller(context("admin")).upsertMonthlyBet({
      memberId: 1, month: "2026-10", amountVnd: 500, netWinLossVnd: -999999,
    });
    expect(updates[1]).toMatchObject({ netWinLossVnd: -730000, updatedBy: 42 });
    expect(JSON.parse((inserts[0] as any).details).updated.netWinLossVnd).toBe(-730000);
  });

  it("rejects an exact formula overflow instead of rounding", async () => {
    const { inserts } = fakeDb([
      [{ id: 1, agencyId: 8, username: "formula-overflow" }], [],
      [{ memberId: 1, total: String(Number.MAX_SAFE_INTEGER) }], [],
      [{ memberId: 1, total: "0", promotionTotal: "1", refundTotal: "0" }], [],
    ]);
    await expect(adminRouter.createCaller(context("admin")).upsertMonthlyBet({
      memberId: 1, month: "2026-10", amountVnd: 0, netWinLossVnd: 123,
    })).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
    expect(inserts[0]).toMatchObject({ netWinLossVnd: 0 });
  });

  it("recalculates the legacy single-transaction mutation in its Vietnam month", async () => {
    const { inserts } = fakeDb([
      [{ id: 1, agencyId: 8, username: "legacy-tx" }],
      [{ memberId: 1, total: "1234" }], [], [], [], [],
    ]);
    await adminRouter.createCaller(context("admin")).addMemberTransaction({
      memberId: 1, kind: "deposit", amountVnd: 1234, occurredAt: "2026-10-31T23:59", note: "Legacy timestamp",
    });
    expect((inserts[0] as any).occurredAt.toISOString()).toBe("2026-10-31T16:59:00.000Z");
    expect(inserts[1]).toMatchObject({ memberId: 1, monthKey: "2026-10", netWinLossVnd: -1234 });
    expect(inserts[2]).toMatchObject({ action: "member_transaction.deposit_recorded" });
  });
});

describe("selected Admin agency performance month", () => {
  it("uses requested month boundaries and corrections while balance/counts remain current", async () => {
    const { queries } = fakeDb([
      [{ id: 8, username: "agency01", status: "approved" }],
      [{ agencyId: 8, total: "1000000" }], [{ agencyId: 8, total: "300000" }], [{ agencyId: 8, total: 5 }],
      [{ agencyId: 8, total: "900000" }], [{ agencyId: 8, total: "200000" }],
      [{ agencyId: 8, total: "600000", validBetTotal: "500000", promotionTotal: "0", refundTotal: "0" }],
      [{ agencyId: 8, depositDeltaVnd: "100000", withdrawalDeltaVnd: "25000" }],
    ]);
    const [row] = await adminRouter.createCaller(context("admin")).agencies({ month: "2026-10" });
    expect(row).toMatchObject({ activityMonth: "2026-10", monthDepositVnd: 1000000, monthMemberWithdrawalVnd: 225000,
      monthBetsVnd: 600000, monthValidBetsVnd: 500000, monthWinLossVnd: -775000, availableVnd: 700000, memberCount: 5 });
    const filter = sqlQuery(queries[4].filters[0]);
    expect(filter.params[0]).toBe("deposit");
    expect(filter.params.slice(1).map((v: any) => new Date(v).toISOString())).toEqual(["2026-09-30T17:00:00.000Z", "2026-10-31T17:00:00.000Z"]);
    expect(sqlQuery(queries[6].filters[0]).params).toEqual(["2026-10"]);
    expect(sqlQuery(queries[7].filters[0]).params).toEqual(["2026-10"]);
    expect(queries[1].filters).toHaveLength(0); expect(queries[3].filters).toHaveLength(1);
  });
  it("returns selected overview activity month but keeps current administrative counts", async () => {
    fakeDb([[{ total: 2 }], [{ total: 8 }], [{ total: 30 }], [{ total: 1 }]]);
    expect(await adminRouter.createCaller(context("admin")).overview({ month: "2026-10" })).toEqual({
      pendingRegistrations: 2, agencies: 8, members: 30, pendingWithdrawals: 1, activityMonth: "2026-10",
    });
  });
  it("does not accept blank/invalid months or expose performance to an agency", async () => {
    const caller = adminRouter.createCaller(context("admin"));
    await expect(caller.agencies({ month: "" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.overview({ month: "2026-13" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(adminRouter.createCaller(context()).agencies({ month: "2026-10" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
  });
});
