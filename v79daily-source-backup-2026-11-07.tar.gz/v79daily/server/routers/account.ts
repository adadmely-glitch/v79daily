import { TRPCError } from "@trpc/server";
import { and, desc, eq, isNull, or } from "drizzle-orm";
import { z } from "zod";
import { changePasswordSchema } from "@shared/account";
import { COOKIE_NAME } from "@shared/const";
import { notificationCacheSchema, notificationFeedSchema, markNotificationsReadSchema } from "@shared/notifications";
import { agencyCredentials, agencyNotifications, agencyProfiles, auditLogs, users, type User } from "../../drizzle/schema";
import { getDb } from "../db";
import { getSessionCookieOptions } from "../_core/cookies";
import { hashPassword, verifyPassword } from "../_core/password";
import { sdk } from "../_core/sdk";
import { adminProcedure, protectedProcedure, router } from "../_core/trpc";
import { storageCreateKey, storagePutAtKey } from "../storage";
import { decodeNotificationImage, getNotificationFeed, getNotificationUnreadCount, markNotificationKeysRead, MAX_NOTIFICATION_IMAGE_BYTES, notificationImageContentType, readNotificationImage } from "../notification-service";

const MAX_FAILURES = 8;
const LOCKOUT_MS = 15 * 60 * 1000;
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;
const newPassword = z.string().min(8, "Mật khẩu mới phải có ít nhất 8 ký tự.").max(128, "Mật khẩu mới tối đa 128 ký tự.");
const resetPasswordSchema = z.object({
  agencyId: z.number().int().positive(), newPassword,
  confirmPassword: z.string().min(1).max(128), reason: z.string().trim().min(3, "Lý do cần ít nhất 3 ký tự.").max(500),
}).strict().refine((input) => input.newPassword === input.confirmPassword, { message: "Hai mật khẩu mới không khớp.", path: ["confirmPassword"] })
  .refine((input) => !input.reason.includes(input.newPassword), { message: "Không ghi mật khẩu trong lý do.", path: ["reason"] });

function nextVersion(version: number) {
  if (!Number.isInteger(version) || version < 0 || version >= 2_147_483_647) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Chưa thể đổi mật khẩu lúc này." });
  }
  return version + 1;
}

async function notificationAgency(user: User) {
  if (user.role === "admin" || user.loginMethod !== "password") throw new TRPCError({ code: "FORBIDDEN", message: "Thông báo này chỉ dành cho đại lý." });
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Không thể tải thông báo lúc này." });
  const [profile] = await db.select({ id: agencyProfiles.id, status: agencyProfiles.status }).from(agencyProfiles).where(eq(agencyProfiles.userId, user.id)).limit(1);
  if (!profile || profile.status !== "approved") throw new TRPCError({ code: "FORBIDDEN", message: "Tài khoản đại lý chưa được duyệt hoặc đang khóa." });
  return { db, agencyId: profile.id };
}

export const accountRouter = router({
  changePassword: protectedProcedure.input(changePasswordSchema).mutation(async ({ ctx, input }) => {
    if (ctx.user.role === "admin" || ctx.user.loginMethod !== "password") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Chức năng này chỉ dành cho tài khoản đại lý đăng nhập bằng mật khẩu." });
    }
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Chưa thể đổi mật khẩu lúc này. Vui lòng thử lại." });
    const result = await db.transaction(async (tx) => {
      const [account] = await tx.select({
        agencyId: agencyProfiles.id, fullName: agencyProfiles.fullName, status: agencyProfiles.status,
        passwordHash: agencyCredentials.passwordHash, passwordVersion: agencyCredentials.passwordVersion,
        failedAttempts: agencyCredentials.failedAttempts, loginBlockedUntil: agencyCredentials.loginBlockedUntil,
      }).from(agencyCredentials).innerJoin(agencyProfiles, eq(agencyCredentials.agencyId, agencyProfiles.id))
        .where(eq(agencyProfiles.userId, ctx.user.id)).limit(1).for("update");
      if (!account || account.status !== "approved") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Tài khoản đại lý chưa được duyệt hoặc đang khóa." });
      }
      const now = Date.now();
      if (account.loginBlockedUntil && account.loginBlockedUntil.getTime() > now) {
        throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Bạn đã nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút." });
      }
      if (!await verifyPassword(input.currentPassword, account.passwordHash)) {
        const expired = account.loginBlockedUntil && account.loginBlockedUntil.getTime() <= now;
        const failures = (expired ? 0 : account.failedAttempts) + 1;
        const blocked = failures >= MAX_FAILURES;
        await tx.update(agencyCredentials).set({ failedAttempts: blocked ? 0 : failures, loginBlockedUntil: blocked ? new Date(now + LOCKOUT_MS) : null })
          .where(eq(agencyCredentials.agencyId, account.agencyId));
        // Return a sentinel so the failed-attempt update commits, then reject outside.
        return { error: blocked ? "blocked" : "incorrect" } as const;
      }
      const version = nextVersion(account.passwordVersion);
      const passwordHash = await hashPassword(input.newPassword);
      await tx.update(agencyCredentials).set({ passwordHash, passwordVersion: version, failedAttempts: 0, loginBlockedUntil: null })
        .where(eq(agencyCredentials.agencyId, account.agencyId));
      await tx.insert(auditLogs).values({
        actorUserId: ctx.user.id, action: "agency.password_changed", entityType: "agency", entityId: account.agencyId,
        details: JSON.stringify({ passwordVersion: version, previousSessionsRevoked: true }),
      });
      return { version, name: account.fullName } as const;
    });
    if ("error" in result) {
      throw new TRPCError({ code: result.error === "blocked" ? "TOO_MANY_REQUESTS" : "BAD_REQUEST", message: result.error === "blocked" ? "Bạn đã nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút." : "Mật khẩu cũ không chính xác." });
    }
    const token = await sdk.createSessionToken(ctx.user.openId, { name: result.name, expiresInMs: SESSION_MS, passwordVersion: result.version });
    ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: SESSION_MS });
    return { success: true } as const;
  }),

  resetAgencyPassword: adminProcedure.input(resetPasswordSchema).mutation(async ({ ctx, input }) => {
    if (ctx.user.loginMethod === "password") throw new TRPCError({ code: "FORBIDDEN", message: "Quản trị viên phải đăng nhập bằng Manus." });
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Không thể đặt lại mật khẩu lúc này." });
    await db.transaction(async (tx) => {
      const [account] = await tx.select({ agencyId: agencyProfiles.id, passwordHash: agencyCredentials.passwordHash, passwordVersion: agencyCredentials.passwordVersion, role: users.role, loginMethod: users.loginMethod })
        .from(agencyCredentials).innerJoin(agencyProfiles, eq(agencyCredentials.agencyId, agencyProfiles.id))
        .innerJoin(users, eq(users.id, agencyProfiles.userId)).where(eq(agencyProfiles.id, input.agencyId)).limit(1).for("update");
      if (!account) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy tài khoản đại lý có mật khẩu." });
      if (account.role === "admin" || account.loginMethod !== "password") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Không thể đặt mật khẩu cho tài khoản Manus OAuth." });
      }
      if (await verifyPassword(input.newPassword, account.passwordHash)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Mật khẩu mới phải khác mật khẩu hiện tại." });
      }
      const version = nextVersion(account.passwordVersion);
      const passwordHash = await hashPassword(input.newPassword);
      await tx.update(agencyCredentials).set({ passwordHash, passwordVersion: version, failedAttempts: 0, loginBlockedUntil: null })
        .where(eq(agencyCredentials.agencyId, account.agencyId));
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "agency.password_reset", entityType: "agency", entityId: account.agencyId,
        details: JSON.stringify({ reason: input.reason, passwordVersion: version, allSessionsRevoked: true }) });
    });
    return { success: true } as const;
  }),

  sendNotification: adminProcedure.input(z.object({ agencyId: z.number().int().positive().nullable(), title: z.string().trim().min(3).max(160), body: z.string().trim().min(1).max(4000), image: z.object({ contentType: z.enum(["image/png", "image/jpeg", "image/webp"]), data: z.string().min(4).max(4 * Math.ceil(MAX_NOTIFICATION_IMAGE_BYTES / 3)).regex(/^[A-Za-z0-9+/]*={0,2}$/) }).strict().optional() }).strict()).mutation(async ({ ctx, input }) => {
    if (ctx.user.loginMethod === "password") throw new TRPCError({ code: "FORBIDDEN", message: "Quản trị viên phải đăng nhập bằng Manus." });
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Không thể gửi thông báo lúc này." });
    const decodedImage = decodeNotificationImage(input.image);
    if (input.agencyId !== null) {
      const [profile] = await db.select({ id: agencyProfiles.id }).from(agencyProfiles).where(eq(agencyProfiles.id, input.agencyId)).limit(1);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy đại lý nhận thông báo." });
    }
    const imageKey = decodedImage ? storageCreateKey(`agency-notifications/${crypto.randomUUID()}.${decodedImage.extension}`) : null;
    // Commit the indexed key first. If SQL fails, no object has been uploaded; after the
    // transaction succeeds, the object is always referenced by this notification record.
    const created = await db.transaction(async (tx) => {
      const [created] = await tx.insert(agencyNotifications).values({ agencyId: input.agencyId, title: input.title, body: input.body, imageKey, createdBy: ctx.user.id }).$returningId();
      await tx.insert(auditLogs).values({ actorUserId: ctx.user.id, action: "agency.notification_sent", entityType: "agency_notification", entityId: created.id,
        details: JSON.stringify({ agencyId: input.agencyId, audience: input.agencyId === null ? "all" : "agency", title: input.title, imageKey }) });
      return { id: created.id };
    });
    if (decodedImage && imageKey) {
      try {
        await storagePutAtKey(imageKey, decodedImage.bytes, decodedImage.contentType);
      } catch {
        // The row already owns this key, so even an ambiguous S3 timeout cannot create an
        // unindexed object. Return success with a warning instead of inviting a duplicate send.
        return { ...created, imageStored: false };
      }
    }
    return { ...created, imageStored: true };
  }),

  sentNotifications: adminProcedure.query(async ({ ctx }) => {
    if (ctx.user.loginMethod === "password") throw new TRPCError({ code: "FORBIDDEN", message: "Quản trị viên phải đăng nhập bằng Manus." });
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Không thể tải lịch sử thông báo." });
    const rows = await db.select({ id: agencyNotifications.id, agencyId: agencyNotifications.agencyId, title: agencyNotifications.title, body: agencyNotifications.body, imageKey: agencyNotifications.imageKey, createdAt: agencyNotifications.createdAt, agencyUsername: agencyProfiles.username, senderName: users.name })
      .from(agencyNotifications).leftJoin(agencyProfiles, eq(agencyNotifications.agencyId, agencyProfiles.id))
      .innerJoin(users, eq(agencyNotifications.createdBy, users.id)).orderBy(desc(agencyNotifications.createdAt)).limit(100);
    return rows.map(({ imageKey, ...row }) => ({ ...row, imageAvailable: Boolean(notificationImageContentType(imageKey)) }));
  }),

  notifications: protectedProcedure.input(notificationFeedSchema).query(async ({ ctx, input }) => {
    const { db, agencyId } = await notificationAgency(ctx.user);
    return getNotificationFeed(db, agencyId, input?.unreadOnly ?? false);
  }),

  notificationImage: protectedProcedure.input(z.object({ eventKey: z.string().regex(/^notice-[1-9]\d{0,9}$/), cacheKey: z.number().int().positive().optional() }).strict()).query(async ({ ctx, input }) => {
    const { db, agencyId } = await notificationAgency(ctx.user);
    const notificationId = Number(input.eventKey.slice("notice-".length));
    const [notice] = await db.select({ agencyId: agencyNotifications.agencyId, imageKey: agencyNotifications.imageKey })
      .from(agencyNotifications).where(and(eq(agencyNotifications.id, notificationId), or(eq(agencyNotifications.agencyId, agencyId), isNull(agencyNotifications.agencyId)))).limit(1);
    if (!notice || !notificationImageContentType(notice.imageKey)) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy ảnh thông báo." });
    ctx.res.setHeader("Cache-Control", "private, no-store");
    ctx.res.setHeader("X-Content-Type-Options", "nosniff");
    return { eventKey: input.eventKey, ...await readNotificationImage(notice.imageKey) };
  }),

  adminNotificationImage: adminProcedure.input(z.object({ id: z.number().int().positive() }).strict()).query(async ({ ctx, input }) => {
    if (ctx.user.loginMethod === "password") throw new TRPCError({ code: "FORBIDDEN", message: "Quản trị viên phải đăng nhập bằng Manus." });
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Không thể tải ảnh thông báo lúc này." });
    const [notice] = await db.select({ imageKey: agencyNotifications.imageKey }).from(agencyNotifications)
      .where(eq(agencyNotifications.id, input.id)).limit(1);
    if (!notice || !notificationImageContentType(notice.imageKey)) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy ảnh thông báo." });
    ctx.res.setHeader("Cache-Control", "private, no-store");
    ctx.res.setHeader("X-Content-Type-Options", "nosniff");
    return { id: input.id, ...await readNotificationImage(notice.imageKey) };
  }),

  notificationUnreadCount: protectedProcedure.input(notificationCacheSchema).query(async ({ ctx }) => {
    const { db, agencyId } = await notificationAgency(ctx.user);
    return getNotificationUnreadCount(db, agencyId);
  }),

  markNotificationsRead: protectedProcedure.input(markNotificationsReadSchema).mutation(async ({ ctx, input }) => {
    const { db, agencyId } = await notificationAgency(ctx.user);
    return markNotificationKeysRead(db, agencyId, ctx.user.id, input.eventKeys);
  }),
});
