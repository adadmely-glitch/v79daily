import { VND_PER_POINT } from "./money";

export const ACTIVITY_POINT_MARKS = [0, 5_000, 10_000, 30_000, 50_000, 100_000] as const;
export const ACTIVITY_SERIES = [
  { key: "totalDepositVnd", label: "Nạp", color: "#16a34a" },
  { key: "totalWithdrawalVnd", label: "Rút", color: "#f97316" },
  { key: "totalBetsVnd", label: "Cược", color: "#8b5cf6" },
  { key: "totalWinLossVnd", label: "Thắng thua", color: "#2563eb" },
  { key: "totalPromotionVnd", label: "Khuyến mãi", color: "#ec4899" },
  { key: "totalRefundVnd", label: "Hoàn trả", color: "#06b6d4" },
] as const;

export type ActivityTotals = Record<(typeof ACTIVITY_SERIES)[number]["key"], number>;
export type ActivityChartRow = (typeof ACTIVITY_SERIES)[number] & { valueVnd: number; points: number };

export function getActivityChartColor(row: ActivityChartRow): string {
  if (row.key !== "totalWinLossVnd") return row.color;
  if (row.valueVnd > 0) return "#16a34a";
  if (row.valueVnd < 0) return "#dc2626";
  return "#64748b";
}

export function createActivityChartRows(totals: ActivityTotals): ActivityChartRow[] {
  return ACTIVITY_SERIES.map((series) => {
    const valueVnd = totals[series.key];
    if (!Number.isSafeInteger(valueVnd)) throw new RangeError("Tổng biểu đồ phải là số VND nguyên an toàn.");
    return { ...series, valueVnd, points: valueVnd / VND_PER_POINT };
  });
}

function boundFor(points: number) {
  return ACTIVITY_POINT_MARKS.find((mark) => mark >= points)
    ?? Math.ceil(points / 100_000) * 100_000;
}

/** Linear coordinates: requested unequal numeric intervals are never made equally spaced. */
export function activityChartAxis(rows: ActivityChartRow[]) {
  const points = rows.map((row) => row.points);
  if (points.some((value) => !Number.isFinite(value))) throw new RangeError("Giá trị trục không hợp lệ.");
  const min = -boundFor(Math.abs(Math.min(0, ...points)));
  const max = Math.max(100_000, boundFor(Math.max(0, ...points)));
  const domain: [number, number] = [min === 0 ? 0 : min, max];
  const expanded = min < 0 || max > 100_000;
  if (!expanded) return { domain, ticks: [...ACTIVITY_POINT_MARKS], expanded };

  const span = max - min;
  const magnitude = 10 ** Math.floor(Math.log10(span / 5));
  const step = [1, 2, 5, 10].map((factor) => factor * magnitude).find((value) => value >= span / 5)!;
  const candidates = new Set<number>([0, min, max]);
  for (const mark of ACTIVITY_POINT_MARKS) {
    if (mark <= max) candidates.add(mark);
    if (-mark >= min) candidates.add(-mark);
  }
  for (let index = Math.ceil(min / step); index <= Math.floor(max / step); index++) {
    candidates.add(index * step);
  }
  // Very wide ranges need fewer axis labels; the full reference marks remain in the UI.
  const minimumGap = span * 12 / 280;
  const ticks = [0];
  for (const value of [min, max, ...[...candidates].sort((a, b) => Math.abs(a) - Math.abs(b))]) {
    if (ticks.every((selected) => Math.abs(selected - value) >= minimumGap)) ticks.push(value);
  }
  return { domain, ticks: ticks.sort((a, b) => a - b), expanded };
}

const axisFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
export const formatActivityAxisPoint = (value: number) => axisFormatter.format(value);
