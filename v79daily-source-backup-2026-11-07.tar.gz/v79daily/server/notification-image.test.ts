import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";

const mock = vi.hoisted(() => ({ getDb: vi.fn(), storageCreateKey: vi.fn(), storagePutAtKey: vi.fn(), storageGetSignedUrl: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));
vi.mock("./storage", () => ({ storageCreateKey: mock.storageCreateKey, storagePutAtKey: mock.storagePutAtKey, storageGetSignedUrl: mock.storageGetSignedUrl }));

import { accountRouter } from "./routers/account";
import { agencyNotifications, auditLogs } from "../drizzle/schema";
import { MAX_NOTIFICATION_IMAGE_BYTES, notificationImageContentType, readNotificationImage } from "./notification-service";
import type { TrpcContext } from "./_core/context";

const dialect = new MySqlDialect();
const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);
const pngData = png.toString("base64");
const imageKey = "agency-notifications/550e8400-e29b-41d4-a716-446655440000_abc12345.png";
const signedUrl = "https://signed.invalid/private-notification.png";

function context(role: "user" | "admin" = "admin", loginMethod = "google"): TrpcContext {
  return { user: { id: 42, openId: "image-unit-test", name: "Unit", email: null, role, loginMethod, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { headers: {}, ip: "unit-address", socket: { remoteAddress: "unit-address" } } as TrpcContext["req"],
    res: { setHeader: vi.fn() } as unknown as TrpcContext["res"] };
}

function fakeDb(results: unknown[][]) {
  const inserts: Array<{ table: unknown; values: any }> = [];
  const queries: Array<{ filters: SQL[] }> = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const result = results.shift() ?? [];
      const entry = { filters: [] as SQL[] }; queries.push(entry);
      const chain: any = { from: () => chain, innerJoin: () => chain, leftJoin: () => chain,
        where: (filter: SQL) => { entry.filters.push(filter); return chain; }, orderBy: () => chain,
        limit: () => chain, then: (resolve: (value: unknown[]) => unknown) => Promise.resolve(result).then(resolve) };
      void fields;
      return chain;
    }),
    insert: vi.fn((table: unknown) => ({ values: (values: unknown) => {
      const entry = { table, values }; inserts.push(entry);
      return { $returningId: async () => [{ id: 321 }], then: (resolve: (value: undefined) => unknown) => Promise.resolve(undefined).then(resolve) };
    } })),
    transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) => fn(db)),
  };
  mock.getDb.mockResolvedValue(db);
  return { db, inserts, queries };
}

function stubImageFetch(bytes = png) {
  const fetcher = vi.fn(async () => new Response(bytes, { status: 200, headers: { "content-type": "image/png" } }));
  vi.stubGlobal("fetch", fetcher);
  return fetcher;
}

function stubImageResponse(response: Response) {
  const fetcher = vi.fn(async () => response);
  vi.stubGlobal("fetch", fetcher);
  return fetcher;
}

describe("notification image upload and private reads", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mock.storageCreateKey.mockReturnValue(imageKey);
    mock.storagePutAtKey.mockResolvedValue({ key: imageKey, url: `/manus-storage/${imageKey}` });
    mock.storageGetSignedUrl.mockResolvedValue(signedUrl);
  });
  afterEach(() => vi.unstubAllGlobals());

  it("keeps Admin OAuth authorization and does not touch storage for agency callers", async () => {
    await expect(accountRouter.createCaller(context("user", "password")).sendNotification({ agencyId: 8, title: "Tin ảnh", body: "Nội dung", image: { contentType: "image/png", data: pngData } })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled(); expect(mock.storagePutAtKey).not.toHaveBeenCalled();
  });

  it.each([
    { contentType: "image/png", data: Buffer.from("not-png").toString("base64") },
    { contentType: "image/jpeg", data: pngData },
    { contentType: "image/png", data: `${pngData.slice(0, -2)}!!` },
  ] as const)("rejects invalid/cross-signature image payloads before storage", async (image) => {
    fakeDb([]);
    await expect(accountRouter.createCaller(context()).sendNotification({ agencyId: null, title: "Tin ảnh", body: "Nội dung", image })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.storagePutAtKey).not.toHaveBeenCalled();
  });

  it("commits the indexed key before network upload, outside the SQL transaction", async () => {
    const { db, inserts, queries } = fakeDb([[{ id: 8 }]]);
    mock.storagePutAtKey.mockImplementation(async () => {
      expect(db.transaction).toHaveBeenCalledTimes(1);
      return { key: imageKey, url: `/manus-storage/${imageKey}` };
    });
    const result = await accountRouter.createCaller(context()).sendNotification({ agencyId: 8, title: " Tin ảnh ", body: " Nội dung ", image: { contentType: "image/png", data: pngData } });
    expect(result).toEqual({ id: 321, imageStored: true });
    expect(mock.storageCreateKey).toHaveBeenCalledWith(expect.stringMatching(/^agency-notifications\/[0-9a-f-]+\.png$/));
    expect(mock.storagePutAtKey).toHaveBeenCalledWith(imageKey, png, "image/png");
    expect(db.transaction).toHaveBeenCalledTimes(1);
    expect(inserts[0]).toEqual({ table: agencyNotifications, values: { agencyId: 8, title: "Tin ảnh", body: "Nội dung", imageKey, createdBy: 42 } });
    expect(inserts[1].table).toBe(auditLogs);
    expect(JSON.parse(inserts[1].values.details)).toMatchObject({ imageKey });
    expect(dialect.sqlToQuery(queries[0].filters[0]).params).toEqual([8]);
  });

  it("rejects a missing target before calling mocked storage", async () => {
    fakeDb([[]]);
    await expect(accountRouter.createCaller(context()).sendNotification({ agencyId: 999, title: "Tin ảnh", body: "Nội dung", image: { contentType: "image/png", data: pngData } })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(mock.storagePutAtKey).not.toHaveBeenCalled();
  });

  it("does not upload an object if the notification SQL transaction fails", async () => {
    const { db } = fakeDb([[{ id: 8 }]]);
    db.transaction.mockRejectedValueOnce(new Error("SQL write failed"));
    await expect(accountRouter.createCaller(context()).sendNotification({ agencyId: 8, title: "Tin ảnh", body: "Nội dung", image: { contentType: "image/png", data: pngData } })).rejects.toThrow("SQL write failed");
    expect(mock.storageCreateKey).toHaveBeenCalledTimes(1);
    expect(mock.storagePutAtKey).not.toHaveBeenCalled();
  });

  it("keeps the generated key indexed when Storage reports an uncertain failure", async () => {
    const { db, inserts } = fakeDb([[{ id: 8 }]]);
    mock.storagePutAtKey.mockRejectedValue(new Error("Storage upload timed out"));
    const result = await accountRouter.createCaller(context()).sendNotification({ agencyId: 8, title: "Tin ảnh", body: "Nội dung", image: { contentType: "image/png", data: pngData } });
    expect(result).toEqual({ id: 321, imageStored: false });
    expect(db.transaction).toHaveBeenCalledTimes(1);
    expect(inserts[0].values.imageKey).toBe(imageKey);
  });

  it("does not return keys in the agency notification feed, including malformed legacy keys", async () => {
    const { queries } = fakeDb([[{ id: 8, status: "approved" }],
      [{ id: 5, title: "Tin có ảnh", body: "Nội dung", imageKey, createdAt: new Date("2026-11-01T00:00:00Z") },
        { id: 4, title: "Tin legacy", body: "Cũ", imageKey: "../../other-bucket/object.png", createdAt: new Date("2026-10-31T00:00:00Z") }], [], []]);
    const result = await accountRouter.createCaller(context("user", "password")).notifications(undefined);
    expect(result.map(({ id, imageAvailable }) => [id, imageAvailable])).toEqual([["notice-5", true], ["notice-4", false]]);
    expect(result.every((entry) => !Object.hasOwn(entry, "imageKey"))).toBe(true);
    expect(dialect.sqlToQuery(queries[1].filters[0]).params).toContain(8);
  });

  it("returns authorized agency image bytes, not a key or signed URL", async () => {
    const fetcher = stubImageFetch();
    fakeDb([[{ id: 8, status: "approved" }], [{ agencyId: 8, imageKey }]]);
    const ctx = context("user", "password");
    const result = await accountRouter.createCaller(ctx).notificationImage({ eventKey: "notice-321" });
    expect(result).toEqual({ eventKey: "notice-321", contentType: "image/png", data: pngData });
    expect(JSON.stringify(result)).not.toContain("agency-notifications/");
    expect(JSON.stringify(result)).not.toContain("signed.invalid");
    expect(mock.storageGetSignedUrl).toHaveBeenCalledWith(imageKey);
    expect(fetcher).toHaveBeenCalledWith(signedUrl, expect.objectContaining({ signal: expect.anything() }));
    expect(ctx.res.setHeader).toHaveBeenCalledWith("Cache-Control", "private, no-store");
    expect(ctx.res.setHeader).toHaveBeenCalledWith("X-Content-Type-Options", "nosniff");
  });

  it("prevents another agency from reading a targeted notice image before Storage access", async () => {
    fakeDb([[{ id: 9, status: "approved" }], []]);
    await expect(accountRouter.createCaller(context("user", "password")).notificationImage({ eventKey: "notice-321" })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(mock.storageGetSignedUrl).not.toHaveBeenCalled();
  });

  it("returns an image-availability flag, not a key, in Admin notification history", async () => {
    fakeDb([[{ id: 321, agencyId: 8, title: "Tin ảnh", body: "Nội dung", imageKey, createdAt: new Date("2026-11-01T00:00:00Z"), agencyUsername: "agency01", senderName: "Admin" }]]);
    const result = await accountRouter.createCaller(context("admin", "google")).sentNotifications();
    expect(result[0]).toMatchObject({ id: 321, imageAvailable: true, title: "Tin ảnh" });
    expect(result[0]).not.toHaveProperty("imageKey");
    expect(mock.storageGetSignedUrl).not.toHaveBeenCalled();
  });

  it("limits Admin image retrieval to OAuth and never returns object keys", async () => {
    const fetcher = stubImageFetch();
    await expect(accountRouter.createCaller(context("admin", "password")).adminNotificationImage({ id: 321 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mock.getDb).not.toHaveBeenCalled();
    fakeDb([[{ imageKey }]]);
    const result = await accountRouter.createCaller(context("admin", "google")).adminNotificationImage({ id: 321 });
    expect(result).toEqual({ id: 321, contentType: "image/png", data: pngData });
    expect(JSON.stringify(result)).not.toContain("agency-notifications/");
    expect(JSON.stringify(result)).not.toContain("signed.invalid");
    expect(fetcher).toHaveBeenCalledWith(signedUrl, expect.objectContaining({ signal: expect.anything() }));
  });

  it.each(["unsafe/path", "agency-notifications/../../image.png", "agency-notifications/random.png_abc123.png"])("rejects malformed persisted image keys before signed access (%s)", async (key) => {
    await expect(readNotificationImage(key)).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(mock.storageGetSignedUrl).not.toHaveBeenCalled();
  });

  it("rejects invalid stored bytes and never returns them to the caller", async () => {
    stubImageFetch(Buffer.from("not-a-png"));
    await expect(readNotificationImage(imageKey)).rejects.toMatchObject({ code: "SERVICE_UNAVAILABLE" });
    expect(mock.storageGetSignedUrl).toHaveBeenCalledWith(imageKey);
  });

  it("rejects an oversized Content-Length before opening the response body", async () => {
    const response = new Response(new ReadableStream<Uint8Array>({ pull(controller) { controller.error(new Error("body must not be read")); } }), {
      status: 200, headers: { "content-length": String(MAX_NOTIFICATION_IMAGE_BYTES + 1) },
    });
    stubImageResponse(response);
    await expect(readNotificationImage(imageKey)).rejects.toMatchObject({ code: "SERVICE_UNAVAILABLE" });
    expect(response.bodyUsed).toBe(false);
  });

  it("caps streamed bytes even when the response omits Content-Length", async () => {
    const response = new Response(new ReadableStream<Uint8Array>({
      start(controller) { controller.enqueue(png); controller.enqueue(new Uint8Array(MAX_NOTIFICATION_IMAGE_BYTES)); controller.close(); },
    }), { status: 200 });
    stubImageResponse(response);
    await expect(readNotificationImage(imageKey)).rejects.toMatchObject({ code: "SERVICE_UNAVAILABLE" });
    expect(response.bodyUsed).toBe(true);
  });

  it("maps only safe generated keys to image content types", () => {
    expect(notificationImageContentType(imageKey)).toBe("image/png");
    expect(notificationImageContentType(imageKey.replace(".png", ".webp"))).toBe("image/webp");
    expect(notificationImageContentType(null)).toBeNull();
    expect(notificationImageContentType("../../secret.png")).toBeNull();
  });
});
