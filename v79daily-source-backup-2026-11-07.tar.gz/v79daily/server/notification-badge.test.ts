import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import NotificationUnreadBadge from "../client/src/components/NotificationUnreadBadge";

describe("unread notification badge", () => {
  it.each([undefined, 0, -1, NaN, Infinity, 1.5])("hides missing/invalid/zero count %s", (count) => {
    expect(renderToStaticMarkup(createElement(NotificationUnreadBadge, { count }))).toBe("");
  });
  it.each([1, 9, 99])("shows the exact count %s", (count) => {
    expect(renderToStaticMarkup(createElement(NotificationUnreadBadge, { count }))).toContain(`>${count}</span>`);
  });
  it("caps the visual label at 99+ without making the number an extra accessible label", () => {
    const result = renderToStaticMarkup(createElement(NotificationUnreadBadge, { count: 130 }));
    expect(result).toContain('aria-hidden="true"'); expect(result).toContain(">99+</span>");
  });
});
