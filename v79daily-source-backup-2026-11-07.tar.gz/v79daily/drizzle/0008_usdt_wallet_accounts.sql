CREATE TABLE `wallet_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agency_id` int NOT NULL,
	`asset` enum('USDT') NOT NULL DEFAULT 'USDT',
	`network` enum('TRC20','ERC20') NOT NULL,
	`address` varchar(64) NOT NULL,
	`address_key` varchar(84) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wallet_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `wallet_accounts_agency_network_address_uq` UNIQUE(`agency_id`,`network`,`address_key`)
);
--> statement-breakpoint
ALTER TABLE `wallet_accounts` ADD CONSTRAINT `wallet_accounts_agency_id_agency_profiles_id_fk` FOREIGN KEY (`agency_id`) REFERENCES `agency_profiles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `wallet_accounts_agency_idx` ON `wallet_accounts` (`agency_id`,`created_at`);