import { describe, expect, it } from "vitest";
import { formatPointEquivalent, formatPointInput, formatVndAsPointNumber, formatVndAsPoints, pointsToVnd } from "../shared/money";

describe("points and VND", () => {
  it.each([
    ["1", 1000], ["1,000", 1000000], ["1000", 1000000],
    ["0.001", 1], ["1,000.123", 1000123], ["-25", -25000],
    ["-0.001", -1], [" 1,000 ", 1000000], ["0", 0], ["+1", 1000],
  ])("converts %s points to exact VND", (input, expected) => {
    expect(pointsToVnd(input)).toBe(expected);
  });

  it.each(["", "1,00", "1,5", "1.2345", "1e3", "NaN", "Infinity", "1 000", "1.000,00", "9,007,199,254,740.992", "9".repeat(65)])("rejects invalid or unsafe points %s", (input) => {
    expect(pointsToVnd(input)).toBeNull();
  });

  it("formats comma grouping and keeps VND precision in fractional points", () => {
    expect(formatVndAsPoints(1000000)).toBe("1,000 điểm");
    expect(formatVndAsPoints(1)).toBe("0.001 điểm");
    expect(formatVndAsPoints(-1234567)).toBe("-1,234.567 điểm");
    expect(formatVndAsPointNumber(-120000)).toBe("-120");
    expect(formatPointEquivalent(1000000)).toBe("1,000 điểm (1,000,000 VND)");
    expect(formatPointInput("1000")).toBe("1,000");
    expect(formatPointInput("1,00")).toBe("1,00");
  });

  it("round trips old VND values exactly without rounding or multiplying them again", () => {
    for (const value of [0, 1, 999, 1000, 1234567, -1, -1234567, Number.MAX_SAFE_INTEGER, Number.MIN_SAFE_INTEGER]) {
      expect(pointsToVnd(formatVndAsPointNumber(value))).toBe(value);
    }
    expect(formatVndAsPointNumber(Number.MAX_SAFE_INTEGER)).toBe("9,007,199,254,740.991");
  });
});
