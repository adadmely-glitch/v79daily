import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { agencyCredentials, agencyProfiles, auditLogs, users } from "../../drizzle/schema";
import { getDb } from "../db";
import { hashPassword } from "../_core/password";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";

const registrationInput = z.object({
  username: z.string().trim().min(3).max(32).regex(/^[a-zA-Z0-9._-]+$/).transform((value) => value.toLowerCase()),
  phone: z.string().trim().min(7).max(32),
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(320).transform((value) => value.toLowerCase()),
  password: z.string().min(8).max(128),
});

export const registrationRouter = router({
  status: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });
    const [profile] = await db.select({
      id: agencyProfiles.id,
      username: agencyProfiles.username,
      phone: agencyProfiles.phone,
      fullName: agencyProfiles.fullName,
      status: agencyProfiles.status,
      referralLink: agencyProfiles.referralLink,
      createdAt: agencyProfiles.createdAt,
    }).from(agencyProfiles).where(eq(agencyProfiles.userId, ctx.user.id)).limit(1);
    return profile ?? null;
  }),

  submit: publicProcedure.input(registrationInput).mutation(async ({ ctx, input }) => {
    if (ctx.user) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Hãy đăng xuất trước khi tạo hồ sơ đại lý mới." });
    }
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not available" });

    const passwordHash = await hashPassword(input.password);
    const openId = `v79-agent:${randomUUID()}`;
    try {
      return await db.transaction(async (tx) => {
        const [createdUser] = await tx.insert(users).values({
          openId,
          name: input.fullName,
          email: input.email,
          loginMethod: "password",
          role: "user",
        }).$returningId();
        const userId = Number(createdUser.id);

        const [createdProfile] = await tx.insert(agencyProfiles).values({
          userId,
          username: input.username,
          phone: input.phone,
          fullName: input.fullName,
          status: "pending",
        }).$returningId();
        const agencyId = Number(createdProfile.id);

        await tx.insert(agencyCredentials).values({ agencyId, passwordHash });
        await tx.insert(auditLogs).values({
          actorUserId: userId,
          action: "agency.registration_submitted",
          entityType: "agency_profile",
          entityId: agencyId,
          details: JSON.stringify({ username: input.username }),
        });
        return { status: "pending" as const };
      });
    } catch (error) {
      if (error instanceof TRPCError) throw error;
      const databaseCode = typeof error === "object" && error && "code" in error ? String(error.code) : "";
      if (databaseCode === "ER_DUP_ENTRY") {
        throw new TRPCError({ code: "CONFLICT", message: "Tên đăng nhập đã được sử dụng. Hãy chọn tên khác." });
      }
      console.error("[Registration] Failed to create agency profile", databaseCode || "database error");
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Không thể gửi hồ sơ lúc này. Vui lòng thử lại." });
    }
  }),
});
