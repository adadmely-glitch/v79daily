import { and, eq, inArray } from "drizzle-orm";
import { memberMonthlyValidity } from "../drizzle/schema";
import type { getDb } from "./db";

type ValidityDb = Pick<
  NonNullable<Awaited<ReturnType<typeof getDb>>>,
  "select"
>;

/**
 * Read only explicit monthly validity marks.
 *
 * A missing row intentionally means 0 (not valid). This helper never falls
 * back to member_accounts.is_valid, because that legacy flag has no month
 * scope and must not silently mark historical months.
 */
export async function getMemberMonthValidity(
  db: ValidityDb,
  memberIds: number[],
  month: string
): Promise<Map<number, number>> {
  const validity = new Map<number, number>();
  if (!memberIds.length) return validity;

  const rows = await db
    .select({
      memberId: memberMonthlyValidity.memberId,
      isValid: memberMonthlyValidity.isValid,
    })
    .from(memberMonthlyValidity)
    .where(
      and(
        inArray(memberMonthlyValidity.memberId, memberIds),
        eq(memberMonthlyValidity.monthKey, month)
      )
    );

  for (const row of rows) {
    validity.set(row.memberId, row.isValid ? 1 : 0);
  }
  return validity;
}
