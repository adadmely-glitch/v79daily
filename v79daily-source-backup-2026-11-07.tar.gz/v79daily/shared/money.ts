export const VND_PER_POINT = 1_000;
export const POINT_RATE_TEXT = "1 điểm = 1,000 VND";
const groupedInteger = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const maxSafeVnd = BigInt(Number.MAX_SAFE_INTEGER);

/** Commas group thousands; a decimal point allows up to three digits (1 VND). */
export function pointsToVnd(input: string): number | null {
  const value = input.trim();
  if (value.length > 64) return null;
  if (!/^[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,3})?$/.test(value)) return null;
  const negative = value.startsWith("-");
  const unsigned = value.replace(/^[+-]/, "").replace(/,/g, "");
  const [whole, fraction = ""] = unsigned.split(".");
  const absolute = BigInt(whole) * BigInt(VND_PER_POINT) + BigInt(fraction.padEnd(3, "0"));
  if (absolute > maxSafeVnd) return null;
  return Number(negative ? -absolute : absolute);
}

export function formatVndAsPointNumber(vnd: number): string {
  if (!Number.isSafeInteger(vnd)) throw new RangeError("Số VND phải là số nguyên an toàn.");
  const value = BigInt(vnd);
  const absolute = value < 0n ? -value : value;
  const whole = groupedInteger.format(absolute / BigInt(VND_PER_POINT));
  const fraction = (absolute % BigInt(VND_PER_POINT)).toString().padStart(3, "0").replace(/0+$/, "");
  return `${value < 0n ? "-" : ""}${whole}${fraction ? `.${fraction}` : ""}`;
}

export function formatVndAsPoints(vnd: number): string {
  return `${formatVndAsPointNumber(vnd)} điểm`;
}

export function formatVnd(vnd: number): string {
  if (!Number.isSafeInteger(vnd)) throw new RangeError("Số VND phải là số nguyên an toàn.");
  return `${groupedInteger.format(vnd)} VND`;
}

export function formatPointInput(input: string): string {
  const vnd = pointsToVnd(input);
  return vnd === null ? input : formatVndAsPointNumber(vnd);
}

export function formatPointEquivalent(vnd: number): string {
  return `${formatVndAsPoints(vnd)} (${formatVnd(vnd)})`;
}

export const pointMoney = { format: formatVndAsPoints };
