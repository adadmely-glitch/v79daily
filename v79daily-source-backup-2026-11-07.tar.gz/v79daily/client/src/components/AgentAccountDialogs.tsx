import { useEffect, useRef, useState, type FormEvent } from "react";
import { Bell, CheckCircle2, Eye, EyeOff, KeyRound, RefreshCw } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { changePasswordSchema } from "@shared/account";
import AgentNotificationItem, { type AgencyNotification } from "@/components/AgentNotificationItem";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import "@/styles/account.css";

export type AccountDialogMode = "notifications" | "password" | null;
const emptyPassword = { currentPassword: "", newPassword: "", confirmPassword: "" };
const fields = [
  { id: "currentPassword", label: "Mật khẩu cũ", autoComplete: "current-password" },
  { id: "newPassword", label: "Mật khẩu mới", autoComplete: "new-password" },
  { id: "confirmPassword", label: "Nhập lại mật khẩu mới", autoComplete: "new-password" },
] as const;

export default function AgentAccountDialogs({ mode, cacheKey, onClose, onRestoreFocus }: {
  mode: AccountDialogMode; cacheKey: number | undefined; onClose: () => void; onRestoreFocus: () => void;
}) {
  const utils = trpc.useUtils();
  const [form, setForm] = useState(emptyPassword);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [readError, setReadError] = useState("");
  const [expandedKey, setExpandedKey] = useState<string | null>(null);
  const awaitingPage = useRef(true);
  const changePassword = trpc.account.changePassword.useMutation({
    onSuccess: () => { setForm(emptyPassword); setShowPassword(false); setError(""); setSuccess(true); },
    onError: (result) => setError(result.message),
  });
  const notifications = trpc.account.notifications.useQuery({ cacheKey, unreadOnly }, {
    enabled: mode === "notifications" && Boolean(cacheKey), refetchOnWindowFocus: true,
  });
  const [openedNotifications, setOpenedNotifications] = useState<NonNullable<typeof notifications.data>>([]);
  const expandedImageNotice = openedNotifications.find((entry) => entry.eventKey === expandedKey && entry.kind === "admin" && entry.imageAvailable);
  const notificationImage = trpc.account.notificationImage.useQuery({ eventKey: expandedImageNotice?.eventKey ?? "notice-1", cacheKey }, {
    enabled: mode === "notifications" && Boolean(expandedImageNotice), retry: false,
  });
  const markRead = trpc.account.markNotificationsRead.useMutation({
    onSuccess: (result) => {
      setReadError("");
      const keys = new Set(result.markedKeys);
      const readTime = new Date();
      // Keep a viewed snapshot for reading; the unread cache must still obey its filter.
      setOpenedNotifications((current) => current.map((entry) => keys.has(entry.eventKey) ? { ...entry, isRead: true, readAt: readTime } : entry));
      for (const filter of [false, true]) {
        utils.account.notifications.setData({ cacheKey, unreadOnly: filter }, (current) => filter
          ? current?.filter((entry) => !keys.has(entry.eventKey))
          : current?.map((entry) => keys.has(entry.eventKey) ? { ...entry, isRead: true, readAt: readTime } : entry));
      }
      void utils.account.notificationUnreadCount.invalidate({ cacheKey }).catch(() => undefined);
    },
    onError: () => setReadError("Không thể cập nhật trạng thái đã đọc. Bấm Thử lại hoặc mở lại thông báo."),
  });
  const busy = mode === "password" && changePassword.isPending;

  useEffect(() => {
    setForm(emptyPassword); setShowPassword(false); setError(""); setSuccess(false);
    setUnreadOnly(false); setReadError(""); setExpandedKey(null);
    awaitingPage.current = true; setOpenedNotifications([]);
    changePassword.reset();
  }, [mode]);

  useEffect(() => {
    if (mode !== "notifications") return;
    if (notifications.isFetching) { awaitingPage.current = true; return; }
    if (!notifications.isError && notifications.data && awaitingPage.current) {
      awaitingPage.current = false;
      setOpenedNotifications(notifications.data);
    }
  }, [mode, unreadOnly, notifications.data, notifications.isFetching, notifications.isError]);

  function markNotificationRead(eventKey: string) {
    const item = openedNotifications.find((entry) => entry.eventKey === eventKey);
    if (!cacheKey || markRead.isPending || item?.isRead !== false) return;
    setReadError("");
    markRead.mutate({ eventKeys: [eventKey] });
  }

  function toggleNotification(item: AgencyNotification) {
    if (markRead.isPending) return;
    setReadError("");
    if (expandedKey === item.eventKey) { setExpandedKey(null); return; }
    setExpandedKey(item.eventKey);
    if (item.isRead === false) markNotificationRead(item.eventKey);
  }

  function refreshNotifications() {
    awaitingPage.current = true;
    setExpandedKey(null);
    setReadError("");
    void notifications.refetch();
  }

  function openUnreadNotifications() {
    awaitingPage.current = true; setExpandedKey(null); setReadError("");
    if (unreadOnly) void notifications.refetch();
    else setUnreadOnly(true);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (changePassword.isPending) return;
    const result = changePasswordSchema.safeParse(form);
    if (!result.success) { setError(result.error.issues[0]?.message ?? "Vui lòng kiểm tra mật khẩu."); return; }
    setError(""); changePassword.mutate(result.data);
  }

  return <Dialog open={mode !== null} onOpenChange={(open) => { if (!open && !busy) onClose(); }}>
    <DialogContent className="agent-account-dialog" showCloseButton={!busy}
      onEscapeKeyDown={(event) => { if (busy) event.preventDefault(); }}
      onPointerDownOutside={(event) => { if (busy) event.preventDefault(); }}
      onCloseAutoFocus={(event) => { event.preventDefault(); onRestoreFocus(); }}>
      <DialogHeader>
        <span className="account-dialog-icon" aria-hidden="true">{mode === "notifications" ? <Bell size={22} /> : <KeyRound size={22} />}</span>
        <DialogTitle>{mode === "notifications" ? "Thông báo" : "Đổi mật khẩu"}</DialogTitle>
        <DialogDescription>{mode === "notifications" ? "Thông báo từ quản trị và cập nhật tài khoản đại lý của bạn." : "Xác minh mật khẩu cũ trước khi đặt mật khẩu mới."}</DialogDescription>
      </DialogHeader>
      {mode === "password" && (success ? <div className="account-password-success" role="status">
        <CheckCircle2 size={30} aria-hidden="true" /><b>Đổi mật khẩu thành công</b>
        <p>Bạn vẫn đăng nhập trên thiết bị này. Các phiên đăng nhập cũ ở thiết bị khác đã được vô hiệu hóa.</p>
        <button className="account-primary-button" type="button" onClick={onClose}>Đóng</button>
      </div> : <form className="account-password-form" onSubmit={submit} noValidate aria-busy={changePassword.isPending}>
        {fields.map((field) => <label key={field.id} htmlFor={`account-${field.id}`}>
          <span>{field.label}</span>
          <input id={`account-${field.id}`} name={field.id} type={showPassword ? "text" : "password"} required maxLength={128}
            minLength={field.id === "newPassword" ? 8 : undefined} autoComplete={field.autoComplete}
            value={form[field.id]} disabled={changePassword.isPending} aria-describedby="account-password-hint"
            onChange={(event) => { setForm((current) => ({ ...current, [field.id]: event.target.value })); setError(""); }} />
        </label>)}
        <p id="account-password-hint" className="account-form-hint">Mật khẩu mới có 8–128 ký tự và phải khác mật khẩu cũ.</p>
        <button className="account-show-password" type="button" aria-pressed={showPassword} disabled={changePassword.isPending} onClick={() => setShowPassword((value) => !value)}>
          {showPassword ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}{showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"}
        </button>
        {error && <p className="account-form-error" role="alert">{error}</p>}
        <button className="account-primary-button" type="submit" disabled={changePassword.isPending}>{changePassword.isPending ? "Đang đổi…" : "Đổi"}</button>
      </form>)}
      {mode === "notifications" && <div className="account-notifications">
        <div className="account-notifications-toolbar"><span>{unreadOnly ? "Thông báo vừa mở" : "Thông báo gần đây"}</span><button type="button" disabled={notifications.isFetching || markRead.isPending} onClick={refreshNotifications}><RefreshCw size={14} aria-hidden="true" /> Làm mới</button></div>
        <button className="account-unread-button" type="button" disabled={notifications.isFetching || markRead.isPending} onClick={openUnreadNotifications}>Xem tin chưa đọc</button>
        {notifications.isLoading && <p className="account-empty" role="status">Đang tải thông báo…</p>}
        {notifications.isError && <p className="account-form-error" role="alert">Không thể tải thông báo. Bấm Làm mới để thử lại.</p>}
        {markRead.isPending && <p className="account-read-pending" role="status">Đang cập nhật trạng thái đã đọc…</p>}
        {readError && <div className="account-read-error"><p className="account-form-error" role="alert">{readError}</p>
          {expandedKey && <button type="button" className="account-unread-button" disabled={markRead.isPending} onClick={() => markNotificationRead(expandedKey)}>Thử lại</button>}
        </div>}
        {!notifications.isLoading && !notifications.isFetching && !notifications.isError && !openedNotifications.length && <p className="account-empty">{unreadOnly ? "Không còn thông báo chưa đọc." : "Chưa có thông báo."}</p>}
        {!notifications.isError && openedNotifications.map((item) => <AgentNotificationItem key={item.eventKey} item={item}
          expanded={expandedKey === item.eventKey} disabled={markRead.isPending && expandedKey !== item.eventKey} onToggle={() => toggleNotification(item)}
          imageData={notificationImage.data?.eventKey === item.eventKey ? notificationImage.data : undefined}
          imageLoading={expandedKey === item.eventKey && notificationImage.isFetching}
          imageError={expandedKey === item.eventKey && notificationImage.isError}
          onRetryImage={() => { void notificationImage.refetch(); }} />)}
      </div>}
    </DialogContent>
  </Dialog>;
}
