import { describe, expect, it, beforeEach, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import type { SQL } from "drizzle-orm";
import { adminRouter } from "./routers/admin";
import type { TrpcContext } from "./_core/context";

const mock = vi.hoisted(() => ({ getDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mock.getDb }));

const dialect = new MySqlDialect();

function context(role: "admin" | "user" = "admin"): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "test",
      email: null,
      name: "Test",
      loginMethod: "password",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

type Query = {
  fields: Record<string, unknown>;
  filters: SQL[];
  locked: boolean;
  ordered: boolean;
};

function fakeDb(resultSets: unknown[][]) {
  const queries: Query[] = [];
  const updates: unknown[] = [];
  const inserts: unknown[] = [];
  const db = {
    select: vi.fn((fields: Record<string, unknown> = {}) => {
      const entry: Query = { fields, filters: [], locked: false, ordered: false };
      queries.push(entry);
      const result = resultSets.shift() ?? [];
      const chain: any = {
        from: () => chain,
        where: (filter: SQL) => {
          entry.filters.push(filter);
          return chain;
        },
        innerJoin: () => chain,
        leftJoin: () => chain,
        groupBy: () => chain,
        orderBy: () => {
          entry.ordered = true;
          return chain;
        },
        limit: () => chain,
        for: () => {
          entry.locked = true;
          return chain;
        },
        then: (resolve: (rows: unknown[]) => unknown) => Promise.resolve(result).then(resolve),
      };
      return chain;
    }),
    update: vi.fn(() => ({
      set: (values: unknown) => {
        updates.push(values);
        return { where: vi.fn(async () => undefined) };
      },
    })),
    insert: vi.fn(() => ({
      values: (values: unknown) => {
        inserts.push(values);
        return {
          $returningId: async () => [{ id: 999 }],
          then: (resolve: (value: undefined) => unknown) => Promise.resolve(undefined).then(resolve),
        };
      },
    })),
    transaction: vi.fn(async (fn: (tx: unknown) => Promise<unknown>) => fn(db)),
  };
  mock.getDb.mockResolvedValue(db);
  return { db, queries, updates, inserts };
}

function sqlQuery(sql: SQL) {
  return dialect.sqlToQuery(sql);
}

beforeEach(() => vi.clearAllMocks());

describe("Admin member account management", () => {
  it.each([
    { label: "another agency", owner: { id: 20, agencyId: 9, deletedAt: null } },
    { label: "the same agency", owner: { id: 20, agencyId: 8, deletedAt: null } },
    { label: "an archived member", owner: { id: 20, agencyId: 9, deletedAt: new Date("2026-10-01T00:00:00Z") } },
  ])("rejects a globally-held username from $label on create", async ({ owner }) => {
    const { inserts } = fakeDb([[{ id: 8, status: "approved" }], [owner]]);
    await expect(adminRouter.createCaller(context()).createMember({ agencyId: 8, username: "taken_name" }))
      .rejects.toMatchObject({ code: "CONFLICT" });
    expect(inserts).toHaveLength(0);
  });

  it("allows an unchanged username during profile update", async () => {
    const member = { id: 4, agencyId: 8, username: "member_old", fullName: "Existing Name", phone: "0000", deletedAt: null };
    const { updates, inserts, queries } = fakeDb([[member], []]);
    await expect(adminRouter.createCaller(context()).updateMember({ memberId: 4, username: "member_old" }))
      .resolves.toEqual({ success: true });
    expect(queries[0].locked).toBe(true);
    expect(updates[0]).toEqual({ username: "member_old", fullName: "Existing Name", phone: "0000" });
    expect(inserts[0]).toMatchObject({ action: "member.updated", entityId: 4 });
  });

  it("archives and restores with locks and audit events, never a hard delete", async () => {
    const archive = fakeDb([[{ id: 4, agencyId: 8, username: "member_old", deletedAt: null }]]);
    await adminRouter.createCaller(context()).setMemberArchived({ memberId: 4, archived: true });
    expect(archive.queries[0].locked).toBe(true);
    expect(archive.updates[0]).toMatchObject({ deletedAt: expect.any(Date) });
    expect(archive.inserts[0]).toMatchObject({ action: "member.archived", entityId: 4 });
    expect(archive.db).not.toHaveProperty("delete");

    const restore = fakeDb([[{ id: 4, agencyId: 8, username: "member_old", deletedAt: new Date("2026-10-01T00:00:00Z") }]]);
    await adminRouter.createCaller(context()).setMemberArchived({ memberId: 4, archived: false });
    expect(restore.updates[0]).toEqual({ deletedAt: null });
    expect(restore.inserts[0]).toMatchObject({ action: "member.restored", entityId: 4 });
  });

  it("lists only the exact member and Vietnam month in descending order, including archived history", async () => {
    const occurredAt = new Date("2026-10-20T03:00:00Z");
    const { queries } = fakeDb([[{
      id: 9,
      memberId: 4,
      kind: "deposit",
      amountVnd: "120000",
      occurredAt,
      note: "history",
      createdBy: 42,
      createdAt: new Date("2026-10-20T03:01:00Z"),
    }]]);
    const rows = await adminRouter.createCaller(context()).memberTransactions({ memberId: 4, month: "2026-10" });
    expect(rows).toEqual([expect.objectContaining({ id: 9, memberId: 4, amountVnd: 120000 })]);
    expect(queries[0].ordered).toBe(true);
    const filter = sqlQuery(queries[0].filters[0]);
    expect(filter.params).toEqual([4, "2026-09-30 17:00:00.000", "2026-10-31 17:00:00.000"]);
    expect(filter.sql).toContain("member_id");
    expect(filter.sql).toContain("occurred_at");
  });

  it("updates only amount, recalculates the transaction month, and audits before/after context", async () => {
    const occurredAt = new Date("2026-10-20T03:00:00Z");
    const { queries, updates, inserts } = fakeDb([
      [{ id: 9, memberId: 4, kind: "deposit", amountVnd: 100, occurredAt, note: "keep", createdBy: 7, createdAt: new Date() }],
      [{ id: 4, agencyId: 8, username: "member_old" }],
      [{ memberId: 4, total: "500" }],
      [{ memberId: 4, total: "100" }],
      [{ memberId: 4, total: "0", promotionTotal: "25", refundTotal: "5" }],
      [],
      [{ id: 99 }],
    ]);
    await adminRouter.createCaller(context()).updateMemberTransaction({ transactionId: 9, amountVnd: 900 });
    expect(queries[0].locked).toBe(true);
    expect(queries[1].locked).toBe(true);
    expect(updates[0]).toEqual({ amountVnd: 900 });
    expect(updates[1]).toMatchObject({ netWinLossVnd: -430, updatedBy: 42 });
    expect(inserts).toHaveLength(1);
    expect(inserts[0]).toMatchObject({ action: "member_transaction.updated", entityId: 9 });
    expect(JSON.parse((inserts[0] as any).details)).toMatchObject({
      memberId: 4,
      agencyId: 8,
      kind: "deposit",
      beforeAmountVnd: 100,
      afterAmountVnd: 900,
      occurredAt: occurredAt.toISOString(),
    });
  });

  it("rejects missing transaction IDs and unsafe amounts before writing", async () => {
    const missing = fakeDb([[]]);
    await expect(adminRouter.createCaller(context()).updateMemberTransaction({ transactionId: 99, amountVnd: 100 }))
      .rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(missing.updates).toHaveLength(0);
    expect(missing.inserts).toHaveLength(0);

    await expect(adminRouter.createCaller(context()).updateMemberTransaction({
      transactionId: 99,
      amountVnd: Number.MAX_SAFE_INTEGER + 1,
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mock.getDb).toHaveBeenCalledTimes(1);
  });
});

describe("Admin agency promotion and refund aggregation", () => {
  it("returns independent per-agency promotion, refund, and combined totals", async () => {
    const { queries } = fakeDb([
      [{ id: 8, username: "agency", fullName: "Agency", status: "approved" }],
      [], [],
      [], [],
      [],
      [{ agencyId: 8, total: "1000", validBetTotal: "800", promotionTotal: "120", refundTotal: "30", winLossTotal: "10" }],
      [], [], [], [], [],
    ]);
    const rows = await adminRouter.createCaller(context()).agencies({ month: "2026-10" });
    expect(rows[0]).toMatchObject({
      monthBetsVnd: 1000,
      monthPromotionVnd: 120,
      monthRefundVnd: 30,
      monthPromotionRefundVnd: 150,
    });
    expect(Object.keys(queries[6].fields).sort()).toEqual([
      "agencyId", "promotionTotal", "refundTotal", "total", "validBetTotal",
    ]);
  });
});
