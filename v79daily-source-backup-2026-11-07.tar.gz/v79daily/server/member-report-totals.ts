import { and, eq, gte, inArray, lt, sum } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { memberMonthlyBets, memberReportAdjustments, memberTransactions } from "../drizzle/schema";
import { calculateMonthlyWinLossVnd, vietnamMonthBounds, type MonthlyTotals } from "../shared/monthly-report";
import type { getDb } from "./db";
import { safeVndTotal } from "./reporting-utils";

type ReportingDb = Pick<NonNullable<Awaited<ReturnType<typeof getDb>>>, "select">;
type WritableReportingDb = Pick<NonNullable<Awaited<ReturnType<typeof getDb>>>, "select" | "insert" | "update">;
export type MemberMonthlyTotals = MonthlyTotals & { totalRefundVnd: number };

export function addExactVnd(left: number, right: number) {
  return safeVndTotal((BigInt(left) + BigInt(right)).toString());
}

export const zeroMonthlyTotals = (): MemberMonthlyTotals => ({
  totalDepositVnd: 0,
  totalWithdrawalVnd: 0,
  totalBetsVnd: 0,
  totalPromotionVnd: 0,
  totalRefundVnd: 0,
});

export async function getTransactionAdjustments(db: ReportingDb, memberIds: number[], month?: string) {
  if (!memberIds.length) return new Map<number, { depositDeltaVnd: number; withdrawalDeltaVnd: number }>();
  const rows = await db.select({
    memberId: memberReportAdjustments.memberId,
    depositDeltaVnd: sum(memberReportAdjustments.depositDeltaVnd),
    withdrawalDeltaVnd: sum(memberReportAdjustments.withdrawalDeltaVnd),
  }).from(memberReportAdjustments).where(and(
    inArray(memberReportAdjustments.memberId, memberIds),
    month ? eq(memberReportAdjustments.monthKey, month) : undefined,
  )).groupBy(memberReportAdjustments.memberId);
  return new Map(rows.map((row) => [row.memberId, {
    depositDeltaVnd: safeVndTotal(row.depositDeltaVnd),
    withdrawalDeltaVnd: safeVndTotal(row.withdrawalDeltaVnd),
  }]));
}

/** The independent aggregates prevent transaction/month joins multiplying money. */
export async function getMemberPeriodTotals(db: ReportingDb, memberIds: number[], month?: string) {
  if (!memberIds.length) return new Map<number, MemberMonthlyTotals>();
  const bounds = month ? vietnamMonthBounds(month) : undefined;
  const [deposits, withdrawals, bets] = await Promise.all([
    db.select({ memberId: memberTransactions.memberId, total: sum(memberTransactions.amountVnd) })
      .from(memberTransactions).where(and(inArray(memberTransactions.memberId, memberIds), eq(memberTransactions.kind, "deposit"),
        bounds ? gte(memberTransactions.occurredAt, bounds.start) : undefined,
        bounds ? lt(memberTransactions.occurredAt, bounds.end) : undefined)).groupBy(memberTransactions.memberId),
    db.select({ memberId: memberTransactions.memberId, total: sum(memberTransactions.amountVnd) })
      .from(memberTransactions).where(and(inArray(memberTransactions.memberId, memberIds), eq(memberTransactions.kind, "withdrawal"),
        bounds ? gte(memberTransactions.occurredAt, bounds.start) : undefined,
        bounds ? lt(memberTransactions.occurredAt, bounds.end) : undefined)).groupBy(memberTransactions.memberId),
    db.select({ memberId: memberMonthlyBets.memberId, total: sum(memberMonthlyBets.amountVnd), promotionTotal: sum(memberMonthlyBets.promotionVnd), refundTotal: sum(memberMonthlyBets.refundVnd) })
      .from(memberMonthlyBets).where(and(inArray(memberMonthlyBets.memberId, memberIds),
        month ? eq(memberMonthlyBets.monthKey, month) : undefined)).groupBy(memberMonthlyBets.memberId),
  ]);
  const adjustments = await getTransactionAdjustments(db, memberIds, month);
  const totals = (rows: Array<{ memberId: number; total: string | number | null }>) =>
    new Map(rows.map((row) => [row.memberId, safeVndTotal(row.total)]));
  const depositMap = totals(deposits), withdrawalMap = totals(withdrawals), betMap = totals(bets);
  const promotionMap = totals(bets.map((row) => ({ memberId: row.memberId, total: row.promotionTotal })));
  const refundMap = totals(bets.map((row) => ({ memberId: row.memberId, total: row.refundTotal })));
  return new Map(memberIds.map((id) => [id, {
    totalDepositVnd: addExactVnd(depositMap.get(id) ?? 0, adjustments.get(id)?.depositDeltaVnd ?? 0),
    totalWithdrawalVnd: addExactVnd(withdrawalMap.get(id) ?? 0, adjustments.get(id)?.withdrawalDeltaVnd ?? 0),
    totalBetsVnd: betMap.get(id) ?? 0,
    totalPromotionVnd: promotionMap.get(id) ?? 0,
    totalRefundVnd: refundMap.get(id) ?? 0,
  }]));
}

/** One money source for the monthly report and performance cards. */
export async function getMemberMonthlyReportTotals(db: ReportingDb, memberIds: number[], month: string) {
  if (!memberIds.length) return new Map<number, {
    totalDepositVnd: number; totalWithdrawalVnd: number; promotionVnd: number; totalRefundVnd: number; totalBetsVnd: number; netWinLossVnd: number;
  }>();
  const totals = await getMemberPeriodTotals(db, memberIds, month);
  return new Map(memberIds.map((id) => {
    const value = totals.get(id) ?? zeroMonthlyTotals();
    const netWinLossVnd = calculateMonthlyWinLossVnd(value);
    if (netWinLossVnd === null) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Tổng tiền vượt phạm vi xử lý chính xác. Vui lòng liên hệ quản trị viên." });
    return [id, {
      totalDepositVnd: value.totalDepositVnd,
      totalWithdrawalVnd: value.totalWithdrawalVnd,
      promotionVnd: value.totalPromotionVnd,
      totalRefundVnd: value.totalRefundVnd,
      totalBetsVnd: value.totalBetsVnd,
      netWinLossVnd,
    }] as const;
  }));
}

/**
 * Rebuild stored monthly net from independent authoritative totals.
 * Callers hold the member row lock; this locks an existing monthly row and
 * preserves valid-bet/refund fields on update.
 */
export async function recalculateMemberMonthlyWinLoss(
  db: WritableReportingDb,
  memberId: number,
  monthKey: string,
  updatedBy: number,
  existingMonthlyBet?: { id: number } | null,
) {
  const totals = (await getMemberPeriodTotals(db, [memberId], monthKey)).get(memberId) ?? zeroMonthlyTotals();
  const netWinLossVnd = calculateMonthlyWinLossVnd({
    totalDepositVnd: totals.totalDepositVnd,
    totalPromotionVnd: totals.totalPromotionVnd,
    totalRefundVnd: totals.totalRefundVnd,
    totalWithdrawalVnd: totals.totalWithdrawalVnd,
  });
  if (netWinLossVnd === null) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Tổng tiền vượt phạm vi xử lý chính xác. Vui lòng liên hệ quản trị viên." });
  }

  const existing = existingMonthlyBet === undefined
    ? (await db.select({ id: memberMonthlyBets.id })
      .from(memberMonthlyBets)
      .where(and(eq(memberMonthlyBets.memberId, memberId), eq(memberMonthlyBets.monthKey, monthKey)))
      .for("update"))[0]
    : existingMonthlyBet;
  if (existing) {
    await db.update(memberMonthlyBets).set({ netWinLossVnd, updatedBy }).where(eq(memberMonthlyBets.id, existing.id));
  } else {
    await db.insert(memberMonthlyBets).values({
      memberId,
      monthKey,
      amountVnd: 0,
      validBetVnd: 0,
      promotionVnd: 0,
      refundVnd: 0,
      netWinLossVnd,
      updatedBy,
    });
  }
  return netWinLossVnd;
}
