import { describe, expect, it } from "vitest";
import { ACTIVITY_POINT_MARKS, ACTIVITY_SERIES, activityChartAxis, createActivityChartRows, formatActivityAxisPoint, getActivityChartColor } from "../shared/activity-chart";
import { pointMoney } from "../shared/money";

const totals = (values = [0, 0, 0, 0, 0, 0]) => ({
  totalDepositVnd: values[0], totalWithdrawalVnd: values[1], totalBetsVnd: values[2],
  totalWinLossVnd: values[3], totalPromotionVnd: values[4] ?? 0, totalRefundVnd: values[5] ?? 0,
});

describe("monthly activity bar chart", () => {
  it("preserves six series order and distinct stable colors", () => {
    expect(ACTIVITY_SERIES.map((series) => series.label)).toEqual(["Nạp", "Rút", "Cược", "Thắng thua", "Khuyến mãi", "Hoàn trả"]);
    expect(new Set(ACTIVITY_SERIES.map((series) => series.color)).size).toBe(6);
  });
  it("colors win/loss by signed value and preserves the other five series colors", () => {
    const rows = createActivityChartRows(totals([1000, 2000, 3000, 4000, 5000, 6000]));
    expect(rows.filter((row) => row.key !== "totalWinLossVnd").map((row) => getActivityChartColor(row))).toEqual(["#16a34a", "#f97316", "#8b5cf6", "#ec4899", "#06b6d4"]);
    expect(getActivityChartColor(createActivityChartRows(totals([0, 0, 0, 5_000_000, 0]))[3])).toBe("#16a34a");
    expect(getActivityChartColor(createActivityChartRows(totals([0, 0, 0, -5_000_000, 0]))[3])).toBe("#dc2626");
    expect(getActivityChartColor(createActivityChartRows(totals())[3])).toBe("#64748b");
  });
  it("formats signed win/loss points without adding a plus sign", () => {
    expect(pointMoney.format(5_000_000)).toBe("5,000 điểm");
    expect(pointMoney.format(-5_000_000)).toBe("-5,000 điểm");
  });
  it("converts coordinates to points without changing exact source VND", () => {
    const values = [500000, 200000, 1234, -1234567, 5678, 9876];
    const rows = createActivityChartRows(totals(values));
    expect(rows.map((row) => row.valueVnd)).toEqual(values);
    expect(rows.map((row) => row.points)).toEqual(values.map((value) => value / 1000));
  });
  it("keeps promotion and refund independent from wagers and extends the axis if needed", () => {
    const rows = createActivityChartRows(totals([500000, 200000, 900000, 0, 150000000, 12345]));
    expect(rows[4]).toMatchObject({ key: "totalPromotionVnd", label: "Khuyến mãi", valueVnd: 150000000, points: 150000 });
    expect(rows[5]).toMatchObject({ key: "totalRefundVnd", label: "Hoàn trả", valueVnd: 12345, points: 12.345 });
    expect(activityChartAxis(rows).domain[1]).toBeGreaterThanOrEqual(rows[4].points);
    expect(() => createActivityChartRows(totals([0, 0, 0, 0, Number.MAX_SAFE_INTEGER + 1]))).toThrow(RangeError);
    expect(() => createActivityChartRows(totals([0, 0, 0, 0, 0, Number.MAX_SAFE_INTEGER + 1]))).toThrow(RangeError);
  });
  it("keeps all requested uneven marks and full 0–100,000 range for zero/small values", () => {
    expect(ACTIVITY_POINT_MARKS).toEqual([0, 5000, 10000, 30000, 50000, 100000]);
    expect(activityChartAxis(createActivityChartRows(totals()))).toEqual({ domain: [0, 100000], ticks: [...ACTIVITY_POINT_MARKS], expanded: false });
    expect(activityChartAxis(createActivityChartRows(totals([500000, 200000, 1234, 0, 0, 0]))).ticks).toEqual([...ACTIVITY_POINT_MARKS]);
  });
  it("does not take absolute win/loss or clip negatives", () => {
    const rows = createActivityChartRows(totals([500000, 200000, 1234, -250000, 0, 0]));
    const axis = activityChartAxis(rows);
    expect(rows[3].points).toBeLessThan(0);
    expect(axis.domain).toEqual([-5000, 100000]);
    expect(axis.ticks).toContain(0);
    expect(axis.ticks).toContain(-5000);
    expect(axis.expanded).toBe(true);
  });
  it("extends the domain for values over 100,000 points without clamping source values", () => {
    const rows = createActivityChartRows(totals([150000000, 200000, 300000000, -250000000, 0, 150000000]));
    const axis = activityChartAxis(rows);
    expect(axis.domain).toEqual([-300000, 300000]);
    expect(axis.expanded).toBe(true);
    for (const row of rows) expect(row.points >= axis.domain[0] && row.points <= axis.domain[1]).toBe(true);
  });
  it("handles safe max values with bounded readable ticks and rejects unsafe source money", () => {
    const axis = activityChartAxis(createActivityChartRows(totals([Number.MAX_SAFE_INTEGER, 0, 0, -Number.MAX_SAFE_INTEGER, 0, 0])));
    expect(axis.ticks).toContain(0);
    expect(axis.ticks.length).toBeLessThan(20);
    expect(axis.domain[1]).toBeGreaterThanOrEqual(Number.MAX_SAFE_INTEGER / 1000);
    for (const value of [NaN, Infinity, 1.1, Number.MAX_SAFE_INTEGER + 1]) {
      expect(() => createActivityChartRows(totals([value, 0, 0, 0]))).toThrow(RangeError);
    }
  });
  it("formats axis points with comma grouping", () => {
    expect(ACTIVITY_POINT_MARKS.map(formatActivityAxisPoint)).toEqual(["0", "5,000", "10,000", "30,000", "50,000", "100,000"]);
  });
});
