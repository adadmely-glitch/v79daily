import { describe, expect, it } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import AgentNotificationItem, { type AgencyNotification } from "../client/src/components/AgentNotificationItem";

const item: AgencyNotification = {
  eventKey: "notice-1", title: "Thông báo từ Admin", message: "Nội dung riêng của thông báo",
  kind: "admin", imageAvailable: true, createdAt: new Date("2026-10-16T10:00:00.000Z"), amountVnd: 1000000, isRead: false,
};
function render(expanded: boolean, overrides: Partial<AgencyNotification> = {}, disabled = false) {
  return renderToStaticMarkup(createElement(AgentNotificationItem, {
    item: { ...item, ...overrides }, expanded, disabled, onToggle: () => undefined,
    imageData: expanded ? { eventKey: item.eventKey, contentType: "image/png", data: "aW1hZ2U=" } : undefined,
  }));
}

describe("notification title/detail rendering", () => {
  it("only renders a title before opening; hides message, date and amount", () => {
    const html = render(false);
    expect(html).toContain(item.title);
    expect(html).toContain('aria-expanded="false"');
    expect(html).not.toContain(item.message);
    expect(html).not.toContain("<time");
    expect(html).not.toContain("1,000 điểm");
    expect(html).not.toContain("account-notification-image");
    expect(html).not.toContain("<section");
    expect(html).not.toContain("Chưa đọc");
  });
  it("opening displays the selected content, date and points, with linked aria controls", () => {
    const html = render(true);
    expect(html).toContain('aria-expanded="true"');
    expect(html).toContain('aria-controls="account-notification-notice-1"');
    expect(html).toContain('id="account-notification-notice-1"');
    expect(html).toContain(item.message);
    expect(html).toMatch(/datetime="2026-10-16T10:00:00\.000Z"/i);
    expect(html).toContain("1,000 điểm");
    expect(html).toContain('class="account-notification-image"');
    expect(html).toContain('src="data:image/png;base64,aW1hZ2U="');
    expect(html).toContain("Chưa đọc");
  });
  it("does not render an image for legacy notices without an attachment", () => {
    const html = render(true, { imageAvailable: false });
    expect(html).not.toContain("account-notification-image");
    expect(html).not.toContain("data:image");
  });
  it("keeps zero-point amounts visible without adding an amount for null", () => {
    expect(render(true, { amountVnd: 0 })).toContain("0 điểm");
    expect(render(true, { amountVnd: null })).not.toContain("<strong");
  });
  it("escapes title/content rather than rendering notice HTML", () => {
    const html = render(true, { title: "<img src=x>", message: "<script>alert(1)</script>" });
    expect(html).toContain("&lt;img src=x&gt;");
    expect(html).toContain("&lt;script&gt;");
    expect(html).not.toContain("<script>");
    expect(html).not.toContain("<img src=x>");
  });
  it("read notices are not styled unread and title buttons can be disabled during saving", () => {
    const html = render(true, { isRead: true }, true);
    expect(html).toContain("Đã đọc");
    expect(html).not.toContain("account-notification-unread");
    expect(html).toContain('disabled=""');
  });
});
