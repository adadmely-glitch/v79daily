import { Redirect } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import AgentDashboard from "@/pages/AgentDashboard";

export default function Dashboard() {
  const auth = useAuth();
  const registration = trpc.registration.status.useQuery(undefined, {
    enabled: auth.isAuthenticated && auth.user?.role !== "admin",
    retry: false,
  });

  if (auth.loading) return <main className="admin-auth-state"><span className="auth-spin">V79</span>Đang xác minh tài khoản…</main>;
  if (!auth.user) return <Redirect to="/" />;
  if (auth.user.role === "admin") return <Redirect to="/admin" />;
  if (registration.isLoading) return <main className="admin-auth-state">Đang kiểm tra trạng thái hồ sơ đại lý…</main>;
  if (registration.error || registration.data?.status !== "approved") return <Redirect to="/" />;
  return <AgentDashboard user={{ name: auth.user.name, email: auth.user.email }} />;
}
